@echo off
chcp 65001 >nul
title TOOL LỌC PROXY - BAO PROXY CHECKER 2026

echo ===================================================
echo            ⚡ TOOL LỌC PROXY VIP 2026 ⚡
echo   Công Cụ Kiểm Tra & Lọc Proxy Đa Luồng Siêu Tốc
echo ===================================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Không tìm thấy Python trong hệ thống PATH!
    pause
    exit /b
)

echo [*] Đang khởi động TOOL LỌC PROXY...
echo.
python "tool lọc proxy\main.py"

if %errorlevel% neq 0 (
    echo.
    echo [!] Tool đã dừng.
    pause
)
