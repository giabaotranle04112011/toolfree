"""
Validation utilities for IP, Port, Domain, and Proxy strings.
"""
import ipaddress
import re
from typing import Tuple, Optional


DOMAIN_REGEX = re.compile(
    r"^(?:[a-zA-Z0-9]"
    r"(?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+"
    r"[a-zA-Z]{2,63}$"
)


def is_valid_ipv4(ip: str) -> bool:
    try:
        ipaddress.IPv4Address(ip.strip())
        return True
    except (ipaddress.AddressValueError, ValueError):
        return False


def is_valid_ipv6(ip: str) -> bool:
    try:
        ipaddress.IPv6Address(ip.strip().strip("[]"))
        return True
    except (ipaddress.AddressValueError, ValueError):
        return False


def is_valid_domain(host: str) -> bool:
    h = host.strip()
    if h.lower() in ("localhost", "local"):
        return True
    return bool(DOMAIN_REGEX.match(h))


def is_valid_host(host: str) -> bool:
    if not host or len(host) > 253:
        return False
    h = host.strip()
    return is_valid_ipv4(h) or is_valid_ipv6(h) or is_valid_domain(h)


def is_valid_port(port: any) -> bool:
    try:
        p = int(port)
        return 1 <= p <= 65535
    except (ValueError, TypeError):
        return False


def validate_proxy_components(host: str, port: any) -> Tuple[bool, Optional[str]]:
    """
    Validates host and port components.
    Returns (is_valid, error_reason).
    """
    if not is_valid_host(host):
        return False, f"Invalid host/IP: '{host}'"
    if not is_valid_port(port):
        return False, f"Invalid port: '{port}' (must be 1-65535)"
    return True, None
