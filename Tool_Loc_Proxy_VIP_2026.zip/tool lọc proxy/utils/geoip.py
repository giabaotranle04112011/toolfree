"""
IP Geolocation & ASN lookup utility with caching.
"""
import asyncio
import aiohttp
from typing import Optional, Dict, Any
from .validator import is_valid_ipv4, is_valid_ipv6


class GeoIPService:
    """Provides async GeoIP lookups with memory cache."""
    _cache: Dict[str, Dict[str, Any]] = {}
    _lock = asyncio.Lock()

    @classmethod
    async def lookup(cls, ip: str, session: Optional[aiohttp.ClientSession] = None, timeout: float = 3.0) -> Dict[str, Any]:
        """
        Looks up country code, country name, city, and ISP for a given IP.
        Returns dict with keys: country_code, country_name, city, org.
        """
        clean_ip = ip.strip()
        if not (is_valid_ipv4(clean_ip) or is_valid_ipv6(clean_ip)):
            return {}

        # Check local cache first
        if clean_ip in cls._cache:
            return cls._cache[clean_ip]

        # Fetch from lightweight IP API (ip-api.com/json/{ip}?fields=status,country,countryCode,city,org,query)
        url = f"http://ip-api.com/json/{clean_ip}?fields=status,country,countryCode,city,org,query"
        try:
            should_close = False
            if session is None:
                session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout))
                should_close = True

            try:
                async with session.get(url) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data.get("status") == "success":
                            result = {
                                "country_code": data.get("countryCode"),
                                "country_name": data.get("country"),
                                "city": data.get("city"),
                                "org": data.get("org"),
                            }
                            async with cls._lock:
                                cls._cache[clean_ip] = result
                            return result
            finally:
                if should_close and session and not session.closed:
                    await session.close()
        except Exception:
            pass

        return {}

    @classmethod
    def parse_from_response(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        """Parses GeoIP if target endpoint (e.g. ip-api.com or ipinfo.io) was used as test target."""
        if not isinstance(data, dict):
            return {}
        country_code = data.get("countryCode") or data.get("country")
        country_name = data.get("country") or data.get("country_name")
        city = data.get("city")
        org = data.get("org") or data.get("isp") or data.get("as")
        ip = data.get("query") or data.get("ip") or data.get("origin")
        
        res = {
            "country_code": country_code if country_code and len(country_code) == 2 else None,
            "country_name": country_name,
            "city": city,
            "org": org,
            "checked_ip": ip,
        }
        if ip and res.get("country_code"):
            cls._cache[ip] = res
        return res
