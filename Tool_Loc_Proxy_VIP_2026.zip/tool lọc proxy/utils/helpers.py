"""
General helper functions for BAO PROXY CHECKER.
"""
import re
from typing import Optional


def mask_credentials(text: str) -> str:
    """
    Masks credentials in proxy string, URL or log text.
    Example: http://user:secret@1.2.3.4:8080 -> http://user:******@1.2.3.4:8080
    Example: 1.2.3.4:8080:user:secret -> 1.2.3.4:8080:user:******
    """
    if not text:
        return ""
    # Mask URL format: user:pass@
    masked = re.sub(r":([^:@\s/]+)@", r":******@", text)
    # Mask 4-part format: ip:port:user:pass
    masked = re.sub(r"^([^:\s]+):(\d+):([^:\s]+):([^\s]+)$", r"\1:\2:\3:******", masked)
    return masked


def format_latency(latency_ms: Optional[float]) -> str:
    """Formats latency for UI display."""
    if latency_ms is None or latency_ms < 0:
        return "--"
    if latency_ms < 1000:
        return f"{latency_ms:.0f} ms"
    return f"{latency_ms / 1000:.2f} s"


def get_country_flag(country_code: Optional[str]) -> str:
    """
    Converts 2-letter ISO country code to Emoji flag.
    Example: 'VN' -> '🇻🇳', 'US' -> '🇺🇸'
    """
    if not country_code or len(country_code) != 2:
        return "🌐"
    code = country_code.upper()
    # Check if characters are A-Z
    if not (code[0].isalpha() and code[1].isalpha()):
        return "🌐"
    offset = 127397
    return chr(ord(code[0]) + offset) + chr(ord(code[1]) + offset)


def sanitize_filename(filename: str) -> str:
    """Removes invalid filesystem characters."""
    return re.sub(r'[\\/*?:"<>|]', "_", filename)
