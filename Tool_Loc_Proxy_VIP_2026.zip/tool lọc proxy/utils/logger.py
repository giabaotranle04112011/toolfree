"""
Secure logging module that prevents accidental credential leakage.
"""
import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from .helpers import mask_credentials


class CredentialMaskingFormatter(logging.Formatter):
    """Logging formatter that intercepts and masks credentials."""
    def format(self, record: logging.LogRecord) -> str:
        msg = super().format(record)
        return mask_credentials(msg)


def setup_logger(name: str = "bao_proxy_checker", level: int = logging.INFO, log_to_file: bool = True) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(level)

    if not logger.handlers:
        formatter = CredentialMaskingFormatter(
            fmt="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )

        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

        if log_to_file:
            log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")
            os.makedirs(log_dir, exist_ok=True)
            log_file = os.path.join(log_dir, "bao_checker.log")
            
            file_handler = RotatingFileHandler(
                log_file,
                maxBytes=5 * 1024 * 1024,  # 5MB
                backupCount=3,
                encoding="utf-8"
            )
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)

    return logger


logger = setup_logger()
