"""
Enhanced Cyber-Modern Theme and UI Design Tokens for BAO PROXY CHECKER.
"""

class Theme:
    # App Backgrounds (Deep Cyber Dark)
    BG_DARK = "#090d16"           # Ultra-deep midnight black
    PANEL_BG = "#10172a"          # Sleek obsidian surface
    PANEL_BG_LIGHT = "#1e293b"    # Secondary surface
    CARD_BG = "#162036"           # Elevated glass card
    CARD_HOVER = "#1c2a47"        # Card hover highlight
    BORDER_COLOR = "#24324f"      # Subtle neon-tinted border
    BORDER_ACCENT = "#3b82f6"     # Active glowing border

    # Neon Status Colors
    COLOR_ALIVE = "#10b981"       # Vibrant emerald green
    COLOR_ALIVE_BG = "#064e3b"    # Dark emerald badge bg
    COLOR_DEAD = "#f43f5e"        # Cyber rose red
    COLOR_DEAD_BG = "#4c0519"
    COLOR_TIMEOUT = "#fbbf24"     # Warm amber
    COLOR_TIMEOUT_BG = "#451a03"
    COLOR_FAST = "#06b6d4"        # Electric cyan
    COLOR_MEDIUM = "#f97316"      # Vivid orange
    COLOR_CHECKING = "#38bdf8"    # Bright sky blue
    COLOR_IDLE = "#64748b"        # Slate grey

    # Action Accent Buttons
    ACCENT_PURPLE = "#8b5cf6"     # Cyber violet
    ACCENT_PURPLE_HOVER = "#7c3aed"
    ACCENT_PRIMARY = "#3b82f6"    # Electric blue
    ACCENT_PRIMARY_HOVER = "#2563eb"
    ACCENT_SUCCESS = "#10b981"    # Neon green
    ACCENT_SUCCESS_HOVER = "#059669"
    ACCENT_WARNING = "#f59e0b"    # Neon yellow
    ACCENT_WARNING_HOVER = "#d97706"
    ACCENT_DANGER = "#ef4444"     # Crimson red
    ACCENT_DANGER_HOVER = "#dc2626"
    ACCENT_CYAN = "#06b6d4"       # Electric cyan
    ACCENT_CYAN_HOVER = "#0891b2"

    # Typography
    TEXT_MAIN = "#f8fafc"         # Crisp white
    TEXT_MUTED = "#94a3b8"        # Soft slate
    TEXT_DIM = "#64748b"          # Dim grey

    FONT_FAMILY = "Segoe UI"
    FONT_MONO = "Consolas"
