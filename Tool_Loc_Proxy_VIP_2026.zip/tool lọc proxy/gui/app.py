"""
Master CustomTkinter Application for BAO PROXY CHECKER.
"""
import os
import sys
import threading
import asyncio
import queue
import tkinter as tk
from tkinter import filedialog, messagebox
import customtkinter as ctk
from typing import List, Optional

from .theme import Theme
from .components.header import HeaderBar
from .components.stats_bar import StatsDashboard
from .components.control_panel import ControlPanel
from .components.filter_bar import FilterBar
from .components.proxy_table import ProxyTable
from .components.paste_dialog import PasteDialog
from .components.history_dialog import HistoryDialog
from .components.settings_dialog import SettingsDialog

from ..checker.models import ProxyItem, CheckResult, CheckerStats, CheckerConfig, FilterCriteria, ProxyStatus, ProxyProtocol
from ..checker.parser import ProxyParser
from ..checker.public_sources import PublicProxyScraper
from ..checker.engine import CheckerEngine, EngineState
from ..storage.history_manager import history_manager
from ..exports.exporter import ProxyExporter
from ..utils.logger import logger


class BaoProxyCheckerApp(ctk.CTk):
    """Main Desktop Window for BAO PROXY CHECKER."""

    def __init__(self):
        super().__init__()

        # Appearance & Window Configuration
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.title("BAO PROXY CHECKER ⚡ PRO VIP 2026")
        self.geometry("1180x820")
        self.minsize(980, 650)
        self.configure(fg_color=Theme.BG_DARK)

        # Core State
        self.config = CheckerConfig()
        self.engine: Optional[CheckerEngine] = None
        self.loaded_proxies: List[ProxyItem] = []
        self.check_results: List[CheckResult] = []
        
        # Concurrency & Asyncio Bridge
        self._async_loop: Optional[asyncio.AbstractEventLoop] = None
        self._worker_thread: Optional[threading.Thread] = None
        self._ui_queue: queue.Queue = queue.Queue()
        self._is_running = False

        self._build_ui()
        self._start_queue_consumer()

    def _build_ui(self):
        # 1. Header Bar
        self.header = HeaderBar(
            self,
            on_open_history=self._open_history_dialog,
            on_open_settings=self._open_settings_dialog,
            on_toggle_theme=self._toggle_theme
        )
        self.header.pack(fill="x", padx=15, pady=(15, 8))

        # 2. Control Panel
        self.control_panel = ControlPanel(
            self,
            on_auto_fetch_check=self._auto_fetch_and_check,
            on_import_file=self._import_file,
            on_paste=self._open_paste_dialog,
            on_start=self._start_check,
            on_pause=self._toggle_pause,
            on_stop=self._stop_check,
            on_clear=self._clear_all
        )
        self.control_panel.pack(fill="x", padx=15, pady=(0, 8))

        # 3. Stats Dashboard
        self.stats_dashboard = StatsDashboard(self)
        self.stats_dashboard.pack(fill="x", padx=15, pady=(0, 8))

        # 4. Filter & Export Bar
        self.filter_bar = FilterBar(
            self,
            on_filter_changed=self._on_filter_changed,
            on_export_alive=lambda fmt: self._export_results("ALIVE", fmt),
            on_export_fast=lambda fmt: self._export_results("FAST", fmt),
            on_export_all=lambda fmt: self._export_results("ALL", fmt)
        )
        self.filter_bar.pack(fill="x", padx=15, pady=(0, 8))

        # 5. Results Proxy Table
        self.table = ProxyTable(self)
        self.table.pack(fill="both", expand=True, padx=15, pady=(0, 15))

    def _toggle_theme(self):
        current = ctk.get_appearance_mode()
        new_mode = "light" if current == "Dark" else "dark"
        ctk.set_appearance_mode(new_mode)

    # ---------------- UI Queue Consumer ----------------
    def _start_queue_consumer(self):
        """Polls messages from the background thread to safely update Tkinter UI."""
        try:
            while True:
                msg_type, payload = self._ui_queue.get_nowait()
                if msg_type == "RESULT":
                    res, stats = payload
                    self.check_results.append(res)
                    self.table.append_result(res)
                    self.stats_dashboard.update_stats(stats)
                elif msg_type == "PROGRESS":
                    stats = payload
                    self.stats_dashboard.update_stats(stats)
                elif msg_type == "STATE":
                    state = payload
                    if state in (EngineState.COMPLETED, EngineState.STOPPED):
                        self._is_running = False
                        self.control_panel.set_running_state(False)
                elif msg_type == "FINISHED":
                    stats = payload
                    self._on_check_finished(stats)
                elif msg_type == "FETCH_DONE":
                    proxies, raw_count = payload
                    self.loaded_proxies = proxies
                    self.check_results = []
                    self.table.clear()
                    self.stats_dashboard.reset(total=len(proxies))
                    # Automatically trigger check immediately!
                    self._start_check()
                elif msg_type == "FETCH_ERROR":
                    err = payload
                    self.control_panel.set_running_state(False)
                    messagebox.showerror("Lỗi cào proxy", f"Không thể lấy proxy từ mạng: {err}", parent=self)
        except queue.Empty:
            pass

        self.after(40, self._start_queue_consumer)

    # ---------------- 1-Click Auto Fetch & Check ----------------
    def _auto_fetch_and_check(self):
        if self._is_running:
            return

        self.control_panel.set_running_state(False, fetching=True)
        self.table.clear()
        self.check_results = []
        self.stats_dashboard.reset(total=0)
        self.stats_dashboard.lbl_speed.configure(text="🌐 Đang cào ~10,000 proxy từ các nguồn công cộng...")

        proto = self.control_panel.selected_protocol

        def worker():
            async def _run():
                try:
                    proxies, raw_count = await PublicProxyScraper.fetch_all(protocol=proto)
                    self._ui_queue.put(("FETCH_DONE", (proxies, raw_count)))
                except Exception as e:
                    self._ui_queue.put(("FETCH_ERROR", str(e)))

            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(_run())
            finally:
                loop.close()

        threading.Thread(target=worker, daemon=True).start()

    # ---------------- Input Handlers ----------------
    def _import_file(self):
        filepath = filedialog.askopenfilename(
            parent=self,
            title="Chọn file danh sách proxy",
            filetypes=[("Text & CSV Files", "*.txt *.csv"), ("Text files", "*.txt"), ("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if not filepath:
            return

        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()

            default_proto = self.control_panel.selected_protocol
            if filepath.lower().endswith(".csv"):
                proxies, dupes, invalid = ProxyParser.parse_csv_file(content, default_protocol=default_proto)
            else:
                proxies, dupes, invalid = ProxyParser.parse_text(content, default_protocol=default_proto)

            if not proxies:
                messagebox.showwarning("Thông báo", "Không tìm thấy proxy hợp lệ nào trong file!", parent=self)
                return

            self.loaded_proxies = proxies
            self.check_results = []
            self.table.clear()
            self.stats_dashboard.reset(total=len(proxies))

            messagebox.showinfo(
                "Nạp thành công",
                f"Đã nạp {len(proxies):,} proxy hợp lệ!\n"
                f"• Bỏ qua {dupes:,} proxy trùng lặp\n"
                f"• Bỏ qua {invalid:,} dòng lỗi",
                parent=self
            )
        except Exception as e:
            messagebox.showerror("Lỗi đọc file", f"Không thể đọc file: {e}", parent=self)

    def _open_paste_dialog(self):
        def on_submit(proxies: List[ProxyItem]):
            self.loaded_proxies = proxies
            self.check_results = []
            self.table.clear()
            self.stats_dashboard.reset(total=len(proxies))

        PasteDialog(self, on_submit=on_submit)

    # ---------------- Execution Lifecycle ----------------
    def _start_check(self):
        if not self.loaded_proxies:
            messagebox.showwarning("Thông báo", "Vui lòng bấm '🚀 TỰ LẤY & LỌC PROXY (1-CLICK)' hoặc nạp file trước!", parent=self)
            return

        if self._is_running:
            return

        # Prepare config
        self.config.workers = self.control_panel.workers
        self.config.timeout_sec = self.control_panel.timeout_sec
        self.config.default_protocol = self.control_panel.selected_protocol
        self.config.target_url = self.control_panel.target_url

        self._is_running = True
        self.control_panel.set_running_state(True, paused=False)
        self.table.clear()
        self.check_results = []
        self.stats_dashboard.reset(total=len(self.loaded_proxies))

        # Start Background Thread
        self._worker_thread = threading.Thread(target=self._run_async_engine, daemon=True)
        self._worker_thread.start()

    def _run_async_engine(self):
        """Worker thread running the asyncio event loop."""
        self._async_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._async_loop)

        self.engine = CheckerEngine(self.config)

        # Connect thread-safe callbacks
        self.engine.on_result = lambda res, stats: self._ui_queue.put(("RESULT", (res, stats)))
        self.engine.on_progress = lambda stats: self._ui_queue.put(("PROGRESS", stats))
        self.engine.on_state_change = lambda state: self._ui_queue.put(("STATE", state))
        self.engine.on_finished = lambda stats: self._ui_queue.put(("FINISHED", stats))

        try:
            self._async_loop.run_until_complete(self.engine.run(self.loaded_proxies))
        finally:
            self._async_loop.close()

    def _toggle_pause(self):
        if not self.engine:
            return

        if self.engine.state == EngineState.RUNNING:
            self.engine.pause()
            self.control_panel.set_running_state(True, paused=True)
        elif self.engine.state == EngineState.PAUSED:
            self.engine.resume()
            self.control_panel.set_running_state(True, paused=False)

    def _stop_check(self):
        if self.engine:
            self.engine.stop()
        self._is_running = False
        self.control_panel.set_running_state(False)

    def _on_check_finished(self, stats: CheckerStats):
        self._is_running = False
        self.control_panel.set_running_state(False)

        # Auto-record session to history SQLite
        if stats.checked > 0:
            try:
                sid = history_manager.record_session(
                    stats=stats,
                    results=self.check_results,
                    target_url=self.config.target_url
                )
                logger.info(f"Session #{sid} persisted automatically.")
            except Exception as e:
                logger.error(f"Failed to auto-save session: {e}")

    def _clear_all(self):
        if self._is_running:
            self._stop_check()
        self.loaded_proxies = []
        self.check_results = []
        self.table.clear()
        self.stats_dashboard.reset(total=0)

    # ---------------- Filter & Export Handlers ----------------
    def _on_filter_changed(self, criteria: FilterCriteria):
        self.table.apply_filter(criteria)

    def _export_results(self, preset: str, format_ext: str):
        if not self.check_results:
            messagebox.showinfo("Thông báo", "Chưa có kết quả kiểm tra nào để xuất!", parent=self)
            return

        file_types = [
            (f"{format_ext.upper()} File", f"*.{format_ext}"),
            ("All Files", "*.*")
        ]
        default_name = f"proxy_{preset.lower()}_{self.config.target_url.split('/')[2] if '/' in self.config.target_url else 'out'}.{format_ext}"

        filepath = filedialog.asksaveasfilename(
            parent=self,
            title=f"Xuất danh sách Proxy ({preset})",
            initialfile=default_name,
            defaultextension=f".{format_ext}",
            filetypes=file_types
        )
        if not filepath:
            return

        try:
            if format_ext == "csv":
                count = ProxyExporter.export_to_csv(self.check_results, filepath, preset=preset)
            elif format_ext == "json":
                count = ProxyExporter.export_to_json(self.check_results, filepath, preset=preset)
            else:
                count = ProxyExporter.export_to_txt(self.check_results, filepath, preset=preset)

            messagebox.showinfo("Xuất file thành công", f"Đã xuất thành công {count:,} proxy ({preset}) vào:\n{filepath}", parent=self)
        except Exception as e:
            messagebox.showerror("Lỗi xuất file", f"Không thể lưu file: {e}", parent=self)

    # ---------------- Dialog Openers ----------------
    def _open_history_dialog(self):
        def on_load_session(results: List[CheckResult]):
            self.check_results = results
            self.table.set_results(results)
            # Reconstruct stats
            stats = CheckerStats(total=len(results))
            for r in results:
                stats.record_result(r)
            self.stats_dashboard.update_stats(stats)

        HistoryDialog(self, on_load_session=on_load_session)

    def _open_settings_dialog(self):
        def on_save(new_config: CheckerConfig):
            self.config = new_config

        SettingsDialog(self, config=self.config, on_save=on_save)
