"""
Enhanced High-Performance Styled Proxy Table with Sorting, Search Filter, and Context Menus.
"""
import tkinter as tk
from tkinter import ttk
import customtkinter as ctk
from typing import List, Optional, Dict, Any
import pyperclip
from ..theme import Theme
from ...checker.models import CheckResult, ProxyStatus, ProxyProtocol, FilterCriteria
from ...utils.helpers import format_latency, get_country_flag


class ProxyTable(ctk.CTkFrame):
    """High-performance results table with sorting and filtering."""

    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color=Theme.PANEL_BG, corner_radius=14, border_width=1, border_color=Theme.BORDER_COLOR, **kwargs)

        self._all_results: List[CheckResult] = []
        self._displayed_results: List[CheckResult] = []
        self._sort_col: str = "id"
        self._sort_reverse: bool = False
        self._active_filter = FilterCriteria()

        self._build_ui()

    def _build_ui(self):
        # Configure Table Header and Body Style
        style = ttk.Style()
        style.theme_use("clam")

        style.configure(
            "Custom.Treeview",
            background="#0d1424",
            foreground="#f8fafc",
            fieldbackground="#0d1424",
            rowheight=30,
            font=(Theme.FONT_FAMILY, 10),
            borderwidth=0
        )
        style.configure(
            "Custom.Treeview.Heading",
            background="#1e293b",
            foreground="#cbd5e1",
            font=(Theme.FONT_FAMILY, 10, "bold"),
            relief="flat",
            padding=(6, 8)
        )
        style.map(
            "Custom.Treeview.Heading",
            background=[("active", "#334155")]
        )
        style.map(
            "Custom.Treeview",
            background=[("selected", "#1e3a8a")],
            foreground=[("selected", "#ffffff")]
        )

        table_box = ctk.CTkFrame(self, fg_color="transparent")
        table_box.pack(fill="both", expand=True, padx=14, pady=12)

        # Columns definition
        self.columns = ("idx", "host", "port", "protocol", "status", "latency", "country", "details")

        self.tree = ttk.Treeview(
            table_box,
            columns=self.columns,
            show="headings",
            style="Custom.Treeview",
            selectmode="extended"
        )

        # Headings and column widths
        self.tree.heading("idx", text="#", command=lambda: self._sort_column("idx"))
        self.tree.heading("host", text="🌐 IP / Host", command=lambda: self._sort_column("host"))
        self.tree.heading("port", text="Port", command=lambda: self._sort_column("port"))
        self.tree.heading("protocol", text="Giao Thức (Type)", command=lambda: self._sort_column("protocol"))
        self.tree.heading("status", text="Trạng Thái (Status)", command=lambda: self._sort_column("status"))
        self.tree.heading("latency", text="Độ Trễ (Latency)", command=lambda: self._sort_column("latency"))
        self.tree.heading("country", text="Quốc Gia (Geo)", command=lambda: self._sort_column("country"))
        self.tree.heading("details", text="Ghi Chú / Chi Tiết", command=lambda: self._sort_column("details"))

        self.tree.column("idx", width=50, minwidth=40, anchor="center")
        self.tree.column("host", width=145, minwidth=110, anchor="w")
        self.tree.column("port", width=70, minwidth=60, anchor="center")
        self.tree.column("protocol", width=115, minwidth=90, anchor="center")
        self.tree.column("status", width=115, minwidth=90, anchor="center")
        self.tree.column("latency", width=105, minwidth=85, anchor="e")
        self.tree.column("country", width=155, minwidth=120, anchor="w")
        self.tree.column("details", width=220, minwidth=140, anchor="w")

        # Scrollbars
        v_scroll = ctk.CTkScrollbar(table_box, orientation="vertical", command=self.tree.yview, button_color="#334155", button_hover_color="#475569")
        self.tree.configure(yscrollcommand=v_scroll.set)

        self.tree.pack(side="left", fill="both", expand=True)
        v_scroll.pack(side="right", fill="y", padx=(2, 0))

        # Row Color Tags
        self.tree.tag_configure("ALIVE_FAST", foreground="#10b981", background="#062e24")
        self.tree.tag_configure("ALIVE_MED", foreground="#38bdf8", background="#082845")
        self.tree.tag_configure("ALIVE_SLOW", foreground="#f59e0b", background="#332408")
        self.tree.tag_configure("DEAD", foreground="#f43f5e", background="#1a0c14")
        self.tree.tag_configure("TIMEOUT", foreground="#fbbf24", background="#1a1408")
        self.tree.tag_configure("IDLE", foreground="#94a3b8")

        # Right-click context menu
        self.context_menu = tk.Menu(self, tearoff=0, bg="#1e293b", fg="#f8fafc", activebackground="#3b82f6", activeforeground="#ffffff", font=(Theme.FONT_FAMILY, 10))
        self.context_menu.add_command(label="📋 Sao chép IP:PORT", command=self._copy_selected_ipport)
        self.context_menu.add_command(label="📋 Sao chép IP", command=self._copy_selected_ip)
        self.context_menu.add_command(label="📋 Sao chép đầy đủ URI", command=self._copy_selected_uri)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="📦 Sao chép tất cả proxy sống", command=self._copy_all_alive)

        self.tree.bind("<Button-3>", self._show_context_menu)

    def _show_context_menu(self, event):
        item_id = self.tree.identify_row(event.y)
        if item_id:
            if item_id not in self.tree.selection():
                self.tree.selection_set(item_id)
            self.context_menu.post(event.x_root, event.y_root)

    def _copy_selected_ipport(self):
        sel = self.tree.selection()
        if not sel:
            return
        lines = []
        for item_id in sel:
            vals = self.tree.item(item_id, "values")
            if vals:
                lines.append(f"{vals[1]}:{vals[2]}")
        if lines:
            pyperclip.copy("\n".join(lines))

    def _copy_selected_ip(self):
        sel = self.tree.selection()
        if not sel:
            return
        lines = []
        for item_id in sel:
            vals = self.tree.item(item_id, "values")
            if vals:
                lines.append(vals[1])
        if lines:
            pyperclip.copy("\n".join(lines))

    def _copy_selected_uri(self):
        sel = self.tree.selection()
        if not sel:
            return
        lines = []
        for item_id in sel:
            idx = int(self.tree.item(item_id, "values")[0]) - 1
            if 0 <= idx < len(self._displayed_results):
                r = self._displayed_results[idx]
                lines.append(r.proxy.clean_uri)
        if lines:
            pyperclip.copy("\n".join(lines))

    def _copy_all_alive(self):
        alive_proxies = [f"{r.proxy.host}:{r.proxy.port}" for r in self._all_results if r.status == ProxyStatus.ALIVE]
        if alive_proxies:
            pyperclip.copy("\n".join(alive_proxies))

    def set_results(self, results: List[CheckResult]):
        """Sets the master result list and refreshes the table."""
        self._all_results = list(results)
        self.apply_filter(self._active_filter)

    def append_result(self, result: CheckResult):
        """Appends a single check result in real-time."""
        self._all_results.append(result)
        if self._active_filter.matches(result):
            self._insert_single_row(len(self._displayed_results) + 1, result)
            self._displayed_results.append(result)

    def _insert_single_row(self, idx: int, r: CheckResult):
        proto = r.protocol_detected.value if r.protocol_detected != ProxyProtocol.AUTO else r.proxy.protocol.value
        status_txt = r.status.display_name
        latency_txt = format_latency(r.latency_ms)
        
        flag = get_country_flag(r.country_code)
        country_txt = f"{flag} {r.country_name or r.country_code or '--'}"

        details = r.error_message or (r.org or "")

        # Tag determination
        if r.status == ProxyStatus.ALIVE:
            if r.latency_ms and r.latency_ms < 500:
                tag = "ALIVE_FAST"
            elif r.latency_ms and r.latency_ms <= 1500:
                tag = "ALIVE_MED"
            else:
                tag = "ALIVE_SLOW"
        elif r.status == ProxyStatus.TIMEOUT:
            tag = "TIMEOUT"
        elif r.status == ProxyStatus.DEAD:
            tag = "DEAD"
        else:
            tag = "IDLE"

        self.tree.insert(
            "",
            "end",
            values=(idx, r.proxy.host, r.proxy.port, proto, status_txt, latency_txt, country_txt, details),
            tags=(tag,)
        )

    def apply_filter(self, criteria: FilterCriteria):
        self._active_filter = criteria
        self._displayed_results = [r for r in self._all_results if criteria.matches(r)]
        self._refresh_view()

    def _refresh_view(self):
        # Clear existing items
        for item in self.tree.get_children():
            self.tree.delete(item)

        for i, r in enumerate(self._displayed_results, 1):
            self._insert_single_row(i, r)

    def _sort_column(self, col: str):
        if self._sort_col == col:
            self._sort_reverse = not self._sort_reverse
        else:
            self._sort_col = col
            self._sort_reverse = False

        def get_sort_key(item: CheckResult):
            if col == "idx":
                return self._displayed_results.index(item)
            elif col == "host":
                return item.proxy.host
            elif col == "port":
                return item.proxy.port
            elif col == "protocol":
                return item.protocol_detected.value
            elif col == "status":
                return item.status.value
            elif col == "latency":
                return item.latency_ms if item.latency_ms is not None else 999999
            elif col == "country":
                return item.country_name or ""
            elif col == "details":
                return item.error_message or ""
            return 0

        self._displayed_results.sort(key=get_sort_key, reverse=self._sort_reverse)
        self._refresh_view()

    def clear(self):
        self._all_results = []
        self._displayed_results = []
        for item in self.tree.get_children():
            self.tree.delete(item)
