"""
History Dialog component for viewing past test sessions, loading, and exporting historical records.
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import customtkinter as ctk
from typing import Callable, Optional, List, Dict, Any
from ..theme import Theme
from ...storage.history_manager import history_manager
from ...checker.models import CheckResult
from ...exports.exporter import ProxyExporter


class HistoryDialog(ctk.CTkToplevel):
    def __init__(self, parent, on_load_session: Optional[Callable[[List[CheckResult]], None]] = None, **kwargs):
        super().__init__(parent, **kwargs)

        self.on_load_session = on_load_session
        self.title("📖 Lịch sử kiểm tra - BAO PROXY CHECKER")
        self.geometry("850x550")
        self.minsize(700, 450)
        self.configure(fg_color=Theme.BG_DARK)

        self.transient(parent)
        self.grab_set()

        self._build_ui()
        self._load_sessions()

    def _build_ui(self):
        # Header
        top_box = ctk.CTkFrame(self, fg_color="transparent")
        top_box.pack(fill="x", padx=20, pady=(15, 10))

        lbl_title = ctk.CTkLabel(
            top_box,
            text="📖 Lịch sử các phiên kiểm tra Proxy",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=18, weight="bold"),
            text_color=Theme.TEXT_MAIN
        )
        lbl_title.pack(side="left")

        btn_refresh = ctk.CTkButton(
            top_box,
            text="🔄 Làm mới",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            fg_color="#334155",
            hover_color="#475569",
            text_color="#f8fafc",
            width=90,
            height=30,
            command=self._load_sessions
        )
        btn_refresh.pack(side="right")

        # Treeview Container
        table_box = ctk.CTkFrame(self, fg_color=Theme.PANEL_BG, corner_radius=10)
        table_box.pack(fill="both", expand=True, padx=20, pady=(0, 15))

        columns = ("id", "started", "total", "alive", "dead", "timeout", "fast", "avg_lat", "fastest")
        self.tree = ttk.Treeview(
            table_box,
            columns=columns,
            show="headings",
            style="Custom.Treeview",
            selectmode="browse"
        )

        self.tree.heading("id", text="ID")
        self.tree.heading("started", text="Thời gian")
        self.tree.heading("total", text="Tổng")
        self.tree.heading("alive", text="🟢 Sống")
        self.tree.heading("dead", text="🔴 Chết")
        self.tree.heading("timeout", text="⚠️ Timeout")
        self.tree.heading("fast", text="⚡ Nhanh")
        self.tree.heading("avg_lat", text="Độ trễ TB")
        self.tree.heading("fastest", text="Nhanh nhất")

        self.tree.column("id", width=45, anchor="center")
        self.tree.column("started", width=140, anchor="w")
        self.tree.column("total", width=65, anchor="center")
        self.tree.column("alive", width=65, anchor="center")
        self.tree.column("dead", width=65, anchor="center")
        self.tree.column("timeout", width=65, anchor="center")
        self.tree.column("fast", width=65, anchor="center")
        self.tree.column("avg_lat", width=85, anchor="e")
        self.tree.column("fastest", width=160, anchor="w")

        v_scroll = ctk.CTkScrollbar(table_box, orientation="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=v_scroll.set)

        self.tree.pack(side="left", fill="both", expand=True, padx=8, pady=8)
        v_scroll.pack(side="right", fill="y", pady=8, padx=(0, 8))

        # Bottom Actions
        btn_row = ctk.CTkFrame(self, fg_color="transparent")
        btn_row.pack(fill="x", padx=20, pady=(0, 20))

        self.btn_load = ctk.CTkButton(
            btn_row,
            text="📂 Tải vào bảng chính",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=13, weight="bold"),
            fg_color="#3b82f6",
            hover_color="#2563eb",
            text_color="#ffffff",
            height=36,
            command=self._load_selected_into_main
        )
        self.btn_load.pack(side="left", padx=(0, 8))

        self.btn_export = ctk.CTkButton(
            btn_row,
            text="📥 Xuất phiên này (.txt)",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            fg_color="#10b981",
            hover_color="#059669",
            text_color="#ffffff",
            height=36,
            command=self._export_selected_session
        )
        self.btn_export.pack(side="left", padx=4)

        self.btn_delete = ctk.CTkButton(
            btn_row,
            text="🗑️ Xóa phiên",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            fg_color="#ef4444",
            hover_color="#dc2626",
            text_color="#ffffff",
            height=36,
            command=self._delete_selected_session
        )
        self.btn_delete.pack(side="left", padx=4)

        self.btn_clear_all = ctk.CTkButton(
            btn_row,
            text="🔥 Xóa toàn bộ lịch sử",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            fg_color="#1e293b",
            hover_color="#334155",
            text_color=Theme.TEXT_MUTED,
            height=36,
            command=self._clear_all_history
        )
        self.btn_clear_all.pack(side="right")

    def _load_sessions(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        sessions = history_manager.list_recent_sessions(limit=100)
        for s in sessions:
            avg_txt = f"{s['avg_latency']:.0f} ms" if s.get("avg_latency") is not None else "--"
            fastest_txt = f"{s.get('fastest_proxy') or '--'}"
            if s.get("fastest_latency"):
                fastest_txt += f" ({s['fastest_latency']:.0f}ms)"

            self.tree.insert(
                "",
                "end",
                values=(
                    s["id"],
                    s["started_at"],
                    f"{s['total']:,}",
                    f"{s['alive']:,}",
                    f"{s['dead']:,}",
                    f"{s['timeout']:,}",
                    f"{s['fast']:,}",
                    avg_txt,
                    fastest_txt
                )
            )

    def _get_selected_session_id(self) -> Optional[int]:
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Thông báo", "Vui lòng chọn một phiên từ bảng trước!", parent=self)
            return None
        values = self.tree.item(sel[0], "values")
        return int(values[0])

    def _load_selected_into_main(self):
        sid = self._get_selected_session_id()
        if not sid:
            return
        results = history_manager.load_session_results(sid)
        if self.on_load_session:
            self.on_load_session(results)
        self.destroy()

    def _export_selected_session(self):
        sid = self._get_selected_session_id()
        if not sid:
            return
        results = history_manager.load_session_results(sid)
        if not results:
            messagebox.showinfo("Thông báo", "Phiên này không có dữ liệu để xuất.", parent=self)
            return

        filepath = filedialog.asksaveasfilename(
            parent=self,
            title="Lưu danh sách Proxy Alive",
            defaultextension=".txt",
            filetypes=[("Text file", "*.txt"), ("CSV file", "*.csv"), ("JSON file", "*.json")]
        )
        if not filepath:
            return

        if filepath.endswith(".csv"):
            ProxyExporter.export_to_csv(results, filepath, preset="ALIVE")
        elif filepath.endswith(".json"):
            ProxyExporter.export_to_json(results, filepath, preset="ALIVE")
        else:
            ProxyExporter.export_to_txt(results, filepath, preset="ALIVE")

        messagebox.showinfo("Thành công", f"Đã xuất proxy sống vào:\n{filepath}", parent=self)

    def _delete_selected_session(self):
        sid = self._get_selected_session_id()
        if not sid:
            return
        if messagebox.askyesno("Xác nhận", f"Bạn có chắc muốn xóa phiên #{sid}?", parent=self):
            history_manager.delete_session(sid)
            self._load_sessions()

    def _clear_all_history(self):
        if messagebox.askyesno("Xác nhận", "Bạn có chắc muốn xóa TOÀN BỘ lịch sử kiểm tra?", parent=self):
            history_manager.clear_history()
            self._load_sessions()
