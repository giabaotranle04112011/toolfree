"""
Enhanced Filter Bar Component with Quick Filter Chips, Search Input, and Multi-Format Export Triggers.
"""
import customtkinter as ctk
from typing import Callable, Optional
from ..theme import Theme
from ...checker.models import FilterCriteria


class FilterBar(ctk.CTkFrame):
    """Filter toolbar and quick-export controls."""

    def __init__(
        self,
        master,
        on_filter_changed: Optional[Callable[[FilterCriteria], None]] = None,
        on_export_alive: Optional[Callable[[str], None]] = None,
        on_export_fast: Optional[Callable[[str], None]] = None,
        on_export_all: Optional[Callable[[str], None]] = None,
        **kwargs
    ):
        super().__init__(master, fg_color=Theme.PANEL_BG, corner_radius=14, border_width=1, border_color=Theme.BORDER_COLOR, **kwargs)

        self.on_filter_changed = on_filter_changed
        self.on_export_alive = on_export_alive
        self.on_export_fast = on_export_fast
        self.on_export_all = on_export_all

        self._active_preset = "ALL"

        self._build_ui()

    def _build_ui(self):
        main_box = ctk.CTkFrame(self, fg_color="transparent")
        main_box.pack(fill="x", padx=16, pady=12)

        # Top line: Filter Chips & Search
        top_line = ctk.CTkFrame(main_box, fg_color="transparent")
        top_line.pack(fill="x", pady=(0, 10))

        lbl_filter = ctk.CTkLabel(
            top_line,
            text="🔍 LỌC:",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"),
            text_color=Theme.TEXT_MAIN
        )
        lbl_filter.pack(side="left", padx=(0, 8))

        # Filter Segmented Button
        self.seg_filter = ctk.CTkSegmentedButton(
            top_line,
            values=["Tất cả", "🟢 Sống", "⚡ Nhanh", "🌐 HTTP", "🧦 SOCKS4", "🧦 SOCKS5", "🔴 Chết", "⚠️ Timeout"],
            command=self._on_segment_change,
            selected_color="#3b82f6",
            selected_hover_color="#2563eb",
            unselected_color="#1e293b",
            unselected_hover_color="#334155",
            text_color="#f8fafc",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=11, weight="bold"),
            height=32,
            corner_radius=8
        )
        self.seg_filter.set("Tất cả")
        self.seg_filter.pack(side="left", padx=4)

        # Live Search Entry
        self.entry_search = ctk.CTkEntry(
            top_line,
            placeholder_text="🔍 Tìm IP, Port, Quốc gia, ISP...",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            height=32,
            width=230,
            corner_radius=8,
            fg_color="#1e293b",
            border_color=Theme.BORDER_COLOR
        )
        self.entry_search.pack(side="right", padx=(8, 0))
        self.entry_search.bind("<KeyRelease>", lambda e: self._trigger_filter())

        # Bottom line: Export options
        bottom_line = ctk.CTkFrame(main_box, fg_color="transparent")
        bottom_line.pack(fill="x")

        lbl_export = ctk.CTkLabel(
            bottom_line,
            text="💾 XUẤT FILE:",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"),
            text_color=Theme.TEXT_MAIN
        )
        lbl_export.pack(side="left", padx=(0, 8))

        # Format selector
        self.combo_format = ctk.CTkComboBox(
            bottom_line,
            values=[".txt (IP:Port)", ".csv (Đầy đủ bảng)", ".json (Dữ liệu chuẩn)"],
            width=165,
            height=30,
            corner_radius=6,
            fg_color="#1e293b",
            border_color=Theme.BORDER_COLOR
        )
        self.combo_format.set(".txt (IP:Port)")
        self.combo_format.pack(side="left", padx=(0, 10))

        # Export Alive
        self.btn_exp_alive = ctk.CTkButton(
            bottom_line,
            text="📥 Xuất Proxy Sống",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"),
            fg_color=Theme.ACCENT_SUCCESS,
            hover_color=Theme.ACCENT_SUCCESS_HOVER,
            text_color="#ffffff",
            height=30,
            corner_radius=6,
            command=self._handle_export_alive
        )
        self.btn_exp_alive.pack(side="left", padx=4)

        # Export Fast
        self.btn_exp_fast = ctk.CTkButton(
            bottom_line,
            text="⚡ Xuất Nhanh (<500ms)",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"),
            fg_color=Theme.ACCENT_CYAN,
            hover_color=Theme.ACCENT_CYAN_HOVER,
            text_color="#ffffff",
            height=30,
            corner_radius=6,
            command=self._handle_export_fast
        )
        self.btn_exp_fast.pack(side="left", padx=4)

        # Export All
        self.btn_exp_all = ctk.CTkButton(
            bottom_line,
            text="📦 Xuất Tất Cả",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            fg_color="#1e293b",
            hover_color="#334155",
            border_width=1,
            border_color=Theme.BORDER_COLOR,
            text_color="#f8fafc",
            height=30,
            corner_radius=6,
            command=self._handle_export_all
        )
        self.btn_exp_all.pack(side="left", padx=4)

    def _on_segment_change(self, val):
        mapping = {
            "Tất cả": "ALL",
            "🟢 Sống": "ALIVE",
            "⚡ Nhanh": "FAST",
            "🌐 HTTP": "HTTP",
            "🧦 SOCKS4": "SOCKS4",
            "🧦 SOCKS5": "SOCKS5",
            "🔴 Chết": "DEAD",
            "⚠️ Timeout": "TIMEOUT",
        }
        self._active_preset = mapping.get(val, "ALL")
        self._trigger_filter()

    def _trigger_filter(self):
        query = self.entry_search.get().strip()
        criteria = FilterCriteria(search_query=query if query else None)

        if self._active_preset in ("ALIVE", "DEAD", "TIMEOUT", "FAST"):
            criteria.status = self._active_preset
        elif self._active_preset in ("HTTP", "SOCKS4", "SOCKS5"):
            criteria.protocol = self._active_preset

        if self.on_filter_changed:
            self.on_filter_changed(criteria)

    def _get_format_ext(self) -> str:
        fmt = self.combo_format.get()
        if ".csv" in fmt:
            return "csv"
        elif ".json" in fmt:
            return "json"
        return "txt"

    def _handle_export_alive(self):
        if self.on_export_alive:
            self.on_export_alive(self._get_format_ext())

    def _handle_export_fast(self):
        if self.on_export_fast:
            self.on_export_fast(self._get_format_ext())

    def _handle_export_all(self):
        if self.on_export_all:
            self.on_export_all(self._get_format_ext())
