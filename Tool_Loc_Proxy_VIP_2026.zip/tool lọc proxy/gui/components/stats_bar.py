"""
Enhanced Real-time Statistics Bar, Glassmorphic Metric Cards, and Progress Indicator.
"""
import customtkinter as ctk
from typing import Dict, Any, Optional
from ..theme import Theme
from ...checker.models import CheckerStats


class StatCard(ctk.CTkFrame):
    """A glassmorphic card displaying a single numeric metric with top accent color."""

    def __init__(self, master, title: str, initial_value: str = "0", value_color: str = Theme.TEXT_MAIN, icon: str = "", top_accent: str = "#3b82f6", **kwargs):
        super().__init__(master, fg_color=Theme.CARD_BG, corner_radius=12, border_width=1, border_color=Theme.BORDER_COLOR, height=78, **kwargs)
        self.pack_propagate(False)

        # Top Accent Strip
        accent_strip = ctk.CTkFrame(self, fg_color=top_accent, height=3, corner_radius=2)
        accent_strip.pack(side="top", fill="x")

        # Title container with icon
        top_box = ctk.CTkFrame(self, fg_color="transparent")
        top_box.pack(side="top", fill="x", padx=12, pady=(6, 2))

        lbl_title = ctk.CTkLabel(
            top_box,
            text=f"{icon} {title}".strip(),
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=11, weight="bold"),
            text_color=Theme.TEXT_MUTED
        )
        lbl_title.pack(side="left")

        # Value display
        self.lbl_value = ctk.CTkLabel(
            self,
            text=initial_value,
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=21, weight="bold"),
            text_color=value_color
        )
        self.lbl_value.pack(side="top", anchor="w", padx=12, pady=(0, 4))

    def set_value(self, val: any):
        self.lbl_value.configure(text=str(val))


class StatsDashboard(ctk.CTkFrame):
    """Container holding all 6 metric cards and the master progress bar."""

    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color=Theme.PANEL_BG, corner_radius=14, border_width=1, border_color=Theme.BORDER_COLOR, **kwargs)

        self._build_ui()

    def _build_ui(self):
        # Cards Grid Frame
        self.cards_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.cards_frame.pack(fill="x", padx=16, pady=(12, 10))

        # 6 Column Grid
        for i in range(6):
            self.cards_frame.columnconfigure(i, weight=1, uniform="stat_col")

        self.card_total = StatCard(self.cards_frame, title="TỔNG SỐ", initial_value="0", icon="📊", value_color="#ffffff", top_accent="#64748b")
        self.card_total.grid(row=0, column=0, padx=4, sticky="ew")

        self.card_checked = StatCard(self.cards_frame, title="ĐÃ CHECK", initial_value="0", icon="⏳", value_color="#38bdf8", top_accent="#0284c7")
        self.card_checked.grid(row=0, column=1, padx=4, sticky="ew")

        self.card_alive = StatCard(self.cards_frame, title="SỐNG (ALIVE)", initial_value="0", icon="🟢", value_color=Theme.COLOR_ALIVE, top_accent=Theme.COLOR_ALIVE)
        self.card_alive.grid(row=0, column=2, padx=4, sticky="ew")

        self.card_dead = StatCard(self.cards_frame, title="CHẾT (DEAD)", initial_value="0", icon="🔴", value_color=Theme.COLOR_DEAD, top_accent=Theme.COLOR_DEAD)
        self.card_dead.grid(row=0, column=3, padx=4, sticky="ew")

        self.card_timeout = StatCard(self.cards_frame, title="TIMEOUT", initial_value="0", icon="⚠️", value_color=Theme.COLOR_TIMEOUT, top_accent=Theme.COLOR_TIMEOUT)
        self.card_timeout.grid(row=0, column=4, padx=4, sticky="ew")

        self.card_fast = StatCard(self.cards_frame, title="SIÊU NHANH (<500ms)", initial_value="0", icon="⚡", value_color=Theme.COLOR_FAST, top_accent=Theme.COLOR_FAST)
        self.card_fast.grid(row=0, column=5, padx=4, sticky="ew")

        # Progress bar container (Glass Box)
        progress_box = ctk.CTkFrame(self, fg_color=Theme.CARD_BG, corner_radius=10, border_width=1, border_color=Theme.BORDER_COLOR)
        progress_box.pack(fill="x", padx=16, pady=(2, 14))

        # Bar
        self.progress_bar = ctk.CTkProgressBar(
            progress_box,
            height=12,
            corner_radius=6,
            progress_color=Theme.ACCENT_PRIMARY,
            fg_color="#0f172a"
        )
        self.progress_bar.pack(fill="x", padx=12, pady=(10, 6))
        self.progress_bar.set(0.0)

        # Progress Details Sub-row
        sub_row = ctk.CTkFrame(progress_box, fg_color="transparent")
        sub_row.pack(fill="x", padx=12, pady=(0, 10))

        self.lbl_percent = ctk.CTkLabel(
            sub_row,
            text="Tiến độ: 0% (0/0)",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"),
            text_color=Theme.TEXT_MAIN
        )
        self.lbl_percent.pack(side="left")

        self.lbl_speed = ctk.CTkLabel(
            sub_row,
            text="Tốc độ: 0 proxy/s",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            text_color="#38bdf8"
        )
        self.lbl_speed.pack(side="left", padx=20)

        self.lbl_avg_latency = ctk.CTkLabel(
            sub_row,
            text="Độ trễ TB: -- ms",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"),
            text_color=Theme.COLOR_FAST
        )
        self.lbl_avg_latency.pack(side="left", padx=10)

        self.lbl_fastest = ctk.CTkLabel(
            sub_row,
            text="Nhanh nhất: --",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            text_color=Theme.TEXT_MUTED
        )
        self.lbl_fastest.pack(side="right")

    def update_stats(self, stats: CheckerStats):
        """Updates all dashboard cards and progress bar from CheckerStats."""
        self.card_total.set_value(f"{stats.total:,}")
        self.card_checked.set_value(f"{stats.checked:,}")
        self.card_alive.set_value(f"{stats.alive:,}")
        self.card_dead.set_value(f"{stats.dead:,}")
        self.card_timeout.set_value(f"{stats.timeout:,}")
        self.card_fast.set_value(f"{stats.fast:,}")

        pct = stats.progress_percent
        self.progress_bar.set(pct / 100.0)

        self.lbl_percent.configure(text=f"Tiến độ: {pct:.1f}% ({stats.checked:,}/{stats.total:,})")
        self.lbl_speed.configure(text=f"Tốc độ: {stats.speed_rate:.1f} proxy/s")

        if stats.avg_latency is not None:
            self.lbl_avg_latency.configure(text=f"Độ trễ TB: {stats.avg_latency:.0f} ms")
        else:
            self.lbl_avg_latency.configure(text="Độ trễ TB: -- ms")

        if stats.fastest_latency is not None:
            self.lbl_fastest.configure(text=f"⚡ Nhanh nhất: {stats.fastest_proxy} ({stats.fastest_latency:.0f}ms)")
        else:
            self.lbl_fastest.configure(text="Nhanh nhất: --")

    def reset(self, total: int = 0):
        self.card_total.set_value(f"{total:,}")
        self.card_checked.set_value("0")
        self.card_alive.set_value("0")
        self.card_dead.set_value("0")
        self.card_timeout.set_value("0")
        self.card_fast.set_value("0")
        self.progress_bar.set(0.0)
        self.lbl_percent.configure(text=f"Tiến độ: 0% (0/{total:,})")
        self.lbl_speed.configure(text="Tốc độ: 0 proxy/s")
        self.lbl_avg_latency.configure(text="Độ trễ TB: -- ms")
        self.lbl_fastest.configure(text="Nhanh nhất: --")
