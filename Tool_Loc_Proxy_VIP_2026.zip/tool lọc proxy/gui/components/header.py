"""
Enhanced Header component with Branding, Status badge, and top actions.
"""
import customtkinter as ctk
from typing import Callable, Optional
from ..theme import Theme


class HeaderBar(ctk.CTkFrame):
    def __init__(
        self,
        master,
        on_open_history: Optional[Callable] = None,
        on_open_settings: Optional[Callable] = None,
        on_toggle_theme: Optional[Callable] = None,
        **kwargs
    ):
        super().__init__(master, fg_color=Theme.PANEL_BG, corner_radius=14, border_width=1, border_color=Theme.BORDER_COLOR, height=76, **kwargs)
        self.pack_propagate(False)

        self.on_open_history = on_open_history
        self.on_open_settings = on_open_settings
        self.on_toggle_theme = on_toggle_theme

        self._build_ui()

    def _build_ui(self):
        # Left branding container
        left_box = ctk.CTkFrame(self, fg_color="transparent")
        left_box.pack(side="left", padx=20, pady=10)

        # Title
        title_box = ctk.CTkFrame(left_box, fg_color="transparent")
        title_box.pack(side="top", anchor="w")

        icon_lbl = ctk.CTkLabel(
            title_box,
            text="⚡",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=24, weight="bold"),
            text_color="#38bdf8"
        )
        icon_lbl.pack(side="left", padx=(0, 6))

        title_lbl = ctk.CTkLabel(
            title_box,
            text="BAO PROXY CHECKER",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=22, weight="bold"),
            text_color=Theme.TEXT_MAIN
        )
        title_lbl.pack(side="left")

        badge = ctk.CTkLabel(
            title_box,
            text=" 👑 VIP PRO 2026 ",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=11, weight="bold"),
            text_color="#ffffff",
            fg_color="#8b5cf6",
            corner_radius=6
        )
        badge.pack(side="left", padx=10)

        subtitle_lbl = ctk.CTkLabel(
            left_box,
            text="🚀 Siêu Đa Luồng Asyncio  •  🌐 Tự Động Cào 15+ Nguồn Quốc Tế  •  ⚡ Nhận Diện HTTP/SOCKS4/SOCKS5",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            text_color=Theme.TEXT_MUTED
        )
        subtitle_lbl.pack(side="top", anchor="w", pady=(2, 0))

        # Right Action Buttons
        right_box = ctk.CTkFrame(self, fg_color="transparent")
        right_box.pack(side="right", padx=20, pady=14)

        self.btn_history = ctk.CTkButton(
            right_box,
            text="📖 Lịch Sử",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=13, weight="bold"),
            fg_color="#1e293b",
            hover_color="#334155",
            border_width=1,
            border_color=Theme.BORDER_COLOR,
            text_color=Theme.TEXT_MAIN,
            width=105,
            height=36,
            corner_radius=8,
            command=self.on_open_history
        )
        self.btn_history.pack(side="left", padx=6)

        self.btn_settings = ctk.CTkButton(
            right_box,
            text="⚙️ Cài Đặt",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=13, weight="bold"),
            fg_color="#1e293b",
            hover_color="#334155",
            border_width=1,
            border_color=Theme.BORDER_COLOR,
            text_color=Theme.TEXT_MAIN,
            width=105,
            height=36,
            corner_radius=8,
            command=self.on_open_settings
        )
        self.btn_settings.pack(side="left", padx=6)
