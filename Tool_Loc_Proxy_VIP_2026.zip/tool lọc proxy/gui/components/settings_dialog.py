"""
Settings Dialog component for configuring checker engine preferences and test endpoints.
"""
import customtkinter as ctk
from typing import Callable, Optional
from ..theme import Theme
from ...checker.models import CheckerConfig


class SettingsDialog(ctk.CTkToplevel):
    def __init__(self, parent, config: CheckerConfig, on_save: Callable[[CheckerConfig], None], **kwargs):
        super().__init__(parent, **kwargs)

        self.config = config
        self.on_save = on_save

        self.title("⚙️ Cài đặt hệ thống - BAO PROXY CHECKER")
        self.geometry("560x480")
        self.minsize(500, 400)
        self.configure(fg_color=Theme.BG_DARK)

        self.transient(parent)
        self.grab_set()

        self._build_ui()

    def _build_ui(self):
        # Header
        top_box = ctk.CTkFrame(self, fg_color="transparent")
        top_box.pack(fill="x", padx=20, pady=(15, 10))

        lbl_title = ctk.CTkLabel(
            top_box,
            text="⚙️ Cấu hình Checker & Kết nối",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=18, weight="bold"),
            text_color=Theme.TEXT_MAIN
        )
        lbl_title.pack(anchor="w")

        # Form panel
        panel = ctk.CTkFrame(self, fg_color=Theme.PANEL_BG, corner_radius=10)
        panel.pack(fill="both", expand=True, padx=20, pady=(0, 15))

        # Target URL HTTP
        lbl_http = ctk.CTkLabel(panel, text="Mục tiêu kiểm tra HTTP (Target URL):", font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"), text_color=Theme.TEXT_MAIN)
        lbl_http.pack(anchor="w", padx=15, pady=(12, 2))

        self.entry_http = ctk.CTkEntry(panel, height=32, corner_radius=6)
        self.entry_http.insert(0, self.config.target_url)
        self.entry_http.pack(fill="x", padx=15, pady=(0, 10))

        # Target URL HTTPS
        lbl_https = ctk.CTkLabel(panel, text="Mục tiêu kiểm tra HTTPS:", font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"), text_color=Theme.TEXT_MAIN)
        lbl_https.pack(anchor="w", padx=15, pady=(2, 2))

        self.entry_https = ctk.CTkEntry(panel, height=32, corner_radius=6)
        self.entry_https.insert(0, self.config.target_url_https)
        self.entry_https.pack(fill="x", padx=15, pady=(0, 10))

        # Retries
        lbl_retries = ctk.CTkLabel(panel, text="Số lần thử lại khi lỗi (Retries):", font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"), text_color=Theme.TEXT_MAIN)
        lbl_retries.pack(anchor="w", padx=15, pady=(2, 2))

        self.combo_retries = ctk.CTkComboBox(panel, values=["0 (Nhanh nhất)", "1 lần", "2 lần"], height=30, corner_radius=6)
        self.combo_retries.set(f"{self.config.retries} lần" if self.config.retries > 0 else "0 (Nhanh nhất)")
        self.combo_retries.pack(anchor="w", padx=15, pady=(0, 10))

        # GeoIP Toggle
        self.switch_geoip = ctk.CTkSwitch(
            panel,
            text="Tự động tra cứu Quốc gia & Nhà mạng (GeoIP / ISP)",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"),
            text_color=Theme.TEXT_MAIN,
            progress_color=Theme.ACCENT_PRIMARY
        )
        if self.config.enable_geoip:
            self.switch_geoip.select()
        else:
            self.switch_geoip.deselect()
        self.switch_geoip.pack(anchor="w", padx=15, pady=(8, 10))

        # User Agent
        lbl_ua = ctk.CTkLabel(panel, text="Custom User-Agent Header:", font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"), text_color=Theme.TEXT_MAIN)
        lbl_ua.pack(anchor="w", padx=15, pady=(2, 2))

        self.entry_ua = ctk.CTkEntry(panel, height=32, corner_radius=6)
        self.entry_ua.insert(0, self.config.user_agent)
        self.entry_ua.pack(fill="x", padx=15, pady=(0, 12))

        # Actions
        btn_row = ctk.CTkFrame(self, fg_color="transparent")
        btn_row.pack(fill="x", padx=20, pady=(0, 15))

        btn_cancel = ctk.CTkButton(
            btn_row,
            text="Hủy",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            fg_color="#334155",
            hover_color="#475569",
            text_color="#f8fafc",
            width=100,
            height=34,
            command=self.destroy
        )
        btn_cancel.pack(side="left")

        btn_save = ctk.CTkButton(
            btn_row,
            text="💾 Lưu cấu hình",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=13, weight="bold"),
            fg_color="#10b981",
            hover_color="#059669",
            text_color="#ffffff",
            width=130,
            height=34,
            command=self._save
        )
        btn_save.pack(side="right")

    def _save(self):
        self.config.target_url = self.entry_http.get().strip() or "http://httpbin.org/ip"
        self.config.target_url_https = self.entry_https.get().strip() or "https://httpbin.org/ip"
        
        retries_txt = self.combo_retries.get()
        if "1" in retries_txt:
            self.config.retries = 1
        elif "2" in retries_txt:
            self.config.retries = 2
        else:
            self.config.retries = 0

        self.config.enable_geoip = bool(self.switch_geoip.get())
        self.config.user_agent = self.entry_ua.get().strip() or "Mozilla/5.0"

        if self.on_save:
            self.on_save(self.config)

        self.destroy()
