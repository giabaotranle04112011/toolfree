"""
Modal Dialog for pasting proxy lists with real-time format validation.
"""
import customtkinter as ctk
import pyperclip
from typing import Callable, Optional, List
from ..theme import Theme
from ...checker.parser import ProxyParser
from ...checker.models import ProxyItem, ProxyProtocol


class PasteDialog(ctk.CTkToplevel):
    def __init__(self, parent, on_submit: Callable[[List[ProxyItem]], None], **kwargs):
        super().__init__(parent, **kwargs)

        self.on_submit = on_submit
        self.title("📋 Dán danh sách Proxy - BAO PROXY CHECKER")
        self.geometry("620x540")
        self.minsize(500, 420)
        self.configure(fg_color=Theme.BG_DARK)

        # Center on parent
        self.transient(parent)
        self.grab_set()

        self._build_ui()

    def _build_ui(self):
        # Header
        top_box = ctk.CTkFrame(self, fg_color="transparent")
        top_box.pack(fill="x", padx=20, pady=(15, 8))

        lbl_title = ctk.CTkLabel(
            top_box,
            text="📋 Dán trực tiếp danh sách Proxy",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=18, weight="bold"),
            text_color=Theme.TEXT_MAIN
        )
        lbl_title.pack(anchor="w")

        lbl_desc = ctk.CTkLabel(
            top_box,
            text="Hỗ trợ format: IP:PORT, IP:PORT:USER:PASS, USER:PASS@IP:PORT hoặc protocol://...",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=11),
            text_color=Theme.TEXT_MUTED
        )
        lbl_desc.pack(anchor="w", pady=(2, 0))

        # Textarea
        self.textbox = ctk.CTkTextbox(
            self,
            font=ctk.CTkFont(family="Consolas", size=12),
            fg_color=Theme.PANEL_BG,
            text_color="#f8fafc",
            border_width=1,
            border_color=Theme.BORDER_COLOR,
            corner_radius=8
        )
        self.textbox.pack(fill="both", expand=True, padx=20, pady=10)
        self.textbox.bind("<KeyRelease>", lambda e: self._update_preview_count())

        # Live stats indicator
        info_row = ctk.CTkFrame(self, fg_color="transparent")
        info_row.pack(fill="x", padx=20, pady=(0, 10))

        self.lbl_count = ctk.CTkLabel(
            info_row,
            text="📊 Đã nhận diện: 0 proxy hợp lệ (0 trùng lặp, 0 lỗi)",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"),
            text_color=Theme.COLOR_FAST
        )
        self.lbl_count.pack(side="left")

        # Bottom Actions
        btn_row = ctk.CTkFrame(self, fg_color="transparent")
        btn_row.pack(fill="x", padx=20, pady=(0, 20))

        btn_paste_clip = ctk.CTkButton(
            btn_row,
            text="📋 Dán từ Clipboard",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            fg_color="#334155",
            hover_color="#475569",
            text_color="#f8fafc",
            height=36,
            corner_radius=6,
            command=self._paste_from_clipboard
        )
        btn_paste_clip.pack(side="left", padx=(0, 8))

        btn_clear = ctk.CTkButton(
            btn_row,
            text="🗑️ Xóa trắng",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            fg_color="#1e293b",
            hover_color="#334155",
            text_color=Theme.TEXT_MUTED,
            height=36,
            corner_radius=6,
            command=self._clear_text
        )
        btn_clear.pack(side="left")

        btn_confirm = ctk.CTkButton(
            btn_row,
            text="✅ Nạp Danh Sách",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=13, weight="bold"),
            fg_color="#10b981",
            hover_color="#059669",
            text_color="#ffffff",
            width=140,
            height=36,
            corner_radius=6,
            command=self._submit
        )
        btn_confirm.pack(side="right")

    def _paste_from_clipboard(self):
        try:
            clip_text = pyperclip.paste()
            if clip_text:
                self.textbox.insert("end", clip_text)
                self._update_preview_count()
        except Exception:
            pass

    def _clear_text(self):
        self.textbox.delete("1.0", "end")
        self._update_preview_count()

    def _update_preview_count(self):
        text = self.textbox.get("1.0", "end")
        valid, dupes, invalid = ProxyParser.parse_text(text)
        self.lbl_count.configure(
            text=f"📊 Đã nhận diện: {len(valid):,} proxy hợp lệ ({dupes:,} trùng lặp, {invalid:,} lỗi)"
        )

    def _submit(self):
        text = self.textbox.get("1.0", "end")
        valid, _, _ = ProxyParser.parse_text(text)
        if valid:
            self.on_submit(valid)
        self.destroy()
