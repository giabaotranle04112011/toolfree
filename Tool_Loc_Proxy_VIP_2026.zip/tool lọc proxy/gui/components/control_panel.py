"""
Enhanced Control Panel with Cyber Glass UI, 1-Click Hero Button, and Concurrency Controls.
"""
import customtkinter as ctk
from typing import Callable, Optional
from ..theme import Theme
from ...checker.models import ProxyProtocol


class ControlPanel(ctk.CTkFrame):
    """Action bar with 1-Click Auto Fetch & Check and manual controls."""

    def __init__(
        self,
        master,
        on_auto_fetch_check: Optional[Callable] = None,
        on_import_file: Optional[Callable] = None,
        on_paste: Optional[Callable] = None,
        on_start: Optional[Callable] = None,
        on_pause: Optional[Callable] = None,
        on_stop: Optional[Callable] = None,
        on_clear: Optional[Callable] = None,
        **kwargs
    ):
        super().__init__(master, fg_color=Theme.PANEL_BG, corner_radius=14, border_width=1, border_color=Theme.BORDER_COLOR, **kwargs)

        self.on_auto_fetch_check = on_auto_fetch_check
        self.on_import_file = on_import_file
        self.on_paste = on_paste
        self.on_start = on_start
        self.on_pause = on_pause
        self.on_stop = on_stop
        self.on_clear = on_clear

        self._build_ui()

    def _build_ui(self):
        # 1. Top Row: Primary Action Buttons
        top_row = ctk.CTkFrame(self, fg_color="transparent")
        top_row.pack(fill="x", padx=16, pady=(14, 10))

        # Hero 1-Click Button (Glowing Purple)
        self.btn_auto = ctk.CTkButton(
            top_row,
            text="🚀 TỰ LẤY & LỌC PROXY (1-CLICK)",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=14, weight="bold"),
            fg_color=Theme.ACCENT_PURPLE,
            hover_color=Theme.ACCENT_PURPLE_HOVER,
            text_color="#ffffff",
            height=42,
            corner_radius=10,
            command=self.on_auto_fetch_check
        )
        self.btn_auto.pack(side="left", padx=(0, 10))

        # Start Button (Emerald Green)
        self.btn_start = ctk.CTkButton(
            top_row,
            text="▶️ Bắt Đầu Check",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=13, weight="bold"),
            fg_color=Theme.ACCENT_SUCCESS,
            hover_color=Theme.ACCENT_SUCCESS_HOVER,
            text_color="#ffffff",
            width=135,
            height=42,
            corner_radius=10,
            command=self.on_start
        )
        self.btn_start.pack(side="left", padx=5)

        # Pause Button (Amber)
        self.btn_pause = ctk.CTkButton(
            top_row,
            text="⏸️ Tạm Dừng",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=13, weight="bold"),
            fg_color=Theme.ACCENT_WARNING,
            hover_color=Theme.ACCENT_WARNING_HOVER,
            text_color="#ffffff",
            width=110,
            height=42,
            corner_radius=10,
            state="disabled",
            command=self.on_pause
        )
        self.btn_pause.pack(side="left", padx=5)

        # Stop Button (Crimson)
        self.btn_stop = ctk.CTkButton(
            top_row,
            text="⏹️ Dừng Lại",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=13, weight="bold"),
            fg_color=Theme.ACCENT_DANGER,
            hover_color=Theme.ACCENT_DANGER_HOVER,
            text_color="#ffffff",
            width=105,
            height=42,
            corner_radius=10,
            state="disabled",
            command=self.on_stop
        )
        self.btn_stop.pack(side="left", padx=5)

        # Manual File Inputs
        self.btn_import = ctk.CTkButton(
            top_row,
            text="📁 Nhập File",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            fg_color="#1e293b",
            hover_color="#334155",
            border_width=1,
            border_color=Theme.BORDER_COLOR,
            text_color="#f8fafc",
            height=42,
            corner_radius=10,
            command=self.on_import_file
        )
        self.btn_import.pack(side="left", padx=5)

        self.btn_paste = ctk.CTkButton(
            top_row,
            text="📋 Dán",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            fg_color="#1e293b",
            hover_color="#334155",
            border_width=1,
            border_color=Theme.BORDER_COLOR,
            text_color="#f8fafc",
            height=42,
            corner_radius=10,
            command=self.on_paste
        )
        self.btn_paste.pack(side="left", padx=5)

        # Clear
        self.btn_clear = ctk.CTkButton(
            top_row,
            text="🗑️ Xóa",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12),
            fg_color="#1e293b",
            hover_color="#334155",
            border_width=1,
            border_color=Theme.BORDER_COLOR,
            text_color=Theme.TEXT_MUTED,
            height=42,
            width=65,
            corner_radius=10,
            command=self.on_clear
        )
        self.btn_clear.pack(side="right")

        # 2. Bottom Row: Configuration Panel (Glass Card)
        config_row = ctk.CTkFrame(self, fg_color=Theme.CARD_BG, corner_radius=10, border_width=1, border_color=Theme.BORDER_COLOR, height=48)
        config_row.pack(fill="x", padx=16, pady=(0, 14))

        # Workers Slider
        lbl_workers = ctk.CTkLabel(
            config_row,
            text="⚡ Luồng (Workers):",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"),
            text_color=Theme.TEXT_MAIN
        )
        lbl_workers.pack(side="left", padx=(14, 6))

        self.slider_workers = ctk.CTkSlider(
            config_row,
            from_=10,
            to=300,
            number_of_steps=290,
            width=115,
            progress_color=Theme.ACCENT_PRIMARY,
            command=self._on_worker_slider_change
        )
        self.slider_workers.set(100)
        self.slider_workers.pack(side="left", padx=4)

        self.lbl_worker_val = ctk.CTkLabel(
            config_row,
            text="100",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"),
            text_color=Theme.COLOR_FAST,
            width=30
        )
        self.lbl_worker_val.pack(side="left", padx=(0, 15))

        # Timeout Dropdown
        lbl_timeout = ctk.CTkLabel(
            config_row,
            text="⏱️ Timeout:",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"),
            text_color=Theme.TEXT_MAIN
        )
        lbl_timeout.pack(side="left", padx=(0, 6))

        self.combo_timeout = ctk.CTkComboBox(
            config_row,
            values=["2s", "3s", "4s", "5s", "8s", "10s"],
            width=75,
            height=28,
            corner_radius=6,
            fg_color="#1e293b",
            border_color=Theme.BORDER_COLOR
        )
        self.combo_timeout.set("4s")
        self.combo_timeout.pack(side="left", padx=(0, 15))

        # Protocol Selector
        lbl_protocol = ctk.CTkLabel(
            config_row,
            text="🌐 Giao thức:",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"),
            text_color=Theme.TEXT_MAIN
        )
        lbl_protocol.pack(side="left", padx=(0, 6))

        self.combo_protocol = ctk.CTkComboBox(
            config_row,
            values=["AUTO (Tự nhận)", "HTTP / HTTPS", "SOCKS4", "SOCKS5"],
            width=135,
            height=28,
            corner_radius=6,
            fg_color="#1e293b",
            border_color=Theme.BORDER_COLOR
        )
        self.combo_protocol.set("AUTO (Tự nhận)")
        self.combo_protocol.pack(side="left", padx=(0, 15))

        # Target Endpoint
        lbl_target = ctk.CTkLabel(
            config_row,
            text="🎯 Mục tiêu:",
            font=ctk.CTkFont(family=Theme.FONT_FAMILY, size=12, weight="bold"),
            text_color=Theme.TEXT_MAIN
        )
        lbl_target.pack(side="left", padx=(0, 6))

        self.combo_target = ctk.CTkComboBox(
            config_row,
            values=[
                "http://httpbin.org/ip",
                "http://ip-api.com/json",
                "https://cloudflare.com/cdn-cgi/trace",
                "https://www.google.com/generate_204",
            ],
            width=230,
            height=28,
            corner_radius=6,
            fg_color="#1e293b",
            border_color=Theme.BORDER_COLOR
        )
        self.combo_target.set("http://httpbin.org/ip")
        self.combo_target.pack(side="left", fill="x", expand=True, padx=(0, 14))

    def _on_worker_slider_change(self, val):
        self.lbl_worker_val.configure(text=str(int(val)))

    @property
    def workers(self) -> int:
        return int(self.slider_workers.get())

    @property
    def timeout_sec(self) -> float:
        val_str = self.combo_timeout.get().replace("s", "").strip()
        try:
            return float(val_str)
        except ValueError:
            return 4.0

    @property
    def selected_protocol(self) -> ProxyProtocol:
        txt = self.combo_protocol.get()
        if "HTTP" in txt:
            return ProxyProtocol.HTTP
        elif "SOCKS4" in txt:
            return ProxyProtocol.SOCKS4
        elif "SOCKS5" in txt:
            return ProxyProtocol.SOCKS5
        return ProxyProtocol.AUTO

    @property
    def target_url(self) -> str:
        return self.combo_target.get().strip()

    def set_running_state(self, running: bool, paused: bool = False, fetching: bool = False):
        if fetching:
            self.btn_auto.configure(state="disabled", text="⏳ Đang cào proxy từ mạng...")
            self.btn_start.configure(state="disabled")
            self.btn_import.configure(state="disabled")
            self.btn_paste.configure(state="disabled")
            self.btn_pause.configure(state="disabled")
            self.btn_stop.configure(state="normal")
        elif running:
            self.btn_auto.configure(state="disabled", text="🚀 Đang lọc tự động...")
            self.btn_start.configure(state="disabled")
            self.btn_import.configure(state="disabled")
            self.btn_paste.configure(state="disabled")
            self.btn_pause.configure(state="normal")
            self.btn_stop.configure(state="normal")
            if paused:
                self.btn_pause.configure(text="▶️ Tiếp Tục", fg_color=Theme.ACCENT_SUCCESS, hover_color=Theme.ACCENT_SUCCESS_HOVER)
            else:
                self.btn_pause.configure(text="⏸️ Tạm Dừng", fg_color=Theme.ACCENT_WARNING, hover_color=Theme.ACCENT_WARNING_HOVER)
        else:
            self.btn_auto.configure(state="normal", text="🚀 TỰ LẤY & LỌC PROXY (1-CLICK)")
            self.btn_start.configure(state="normal")
            self.btn_import.configure(state="normal")
            self.btn_paste.configure(state="normal")
            self.btn_pause.configure(state="disabled", text="⏸️ Tạm Dừng", fg_color=Theme.ACCENT_WARNING)
            self.btn_stop.configure(state="disabled")
