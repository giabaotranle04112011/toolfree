"""
Command-Line Interface (CLI) for BAO PROXY CHECKER with Rich styling and Auto-Scraping.
"""
import argparse
import asyncio
import sys
import os
import time
from typing import List, Optional

# Ensure UTF-8 output encoding across Windows consoles
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeRemainingColumn
from rich.panel import Panel
from rich.text import Text

from .checker.models import ProxyItem, CheckResult, CheckerStats, CheckerConfig, ProxyProtocol, ProxyStatus
from .checker.parser import ProxyParser
from .checker.public_sources import PublicProxyScraper
from .checker.engine import CheckerEngine
from .exports.exporter import ProxyExporter
from .storage.history_manager import history_manager
from .utils.helpers import format_latency, get_country_flag


console = Console(force_terminal=True, legacy_windows=False)


def render_banner():
    banner = Text(
        "===============================================================\n"
        "                ⚡ BAO PROXY CHECKER ⚡\n"
        "     [ PRO VIP 2026 EDITION • ASYNC HIGH-SPEED ENGINE ]\n"
        "===============================================================",
        style="bold cyan"
    )
    console.print(Panel(banner, border_style="bright_blue"))


def run_cli_checker(args):
    render_banner()

    # History display command
    if args.history:
        sessions = history_manager.list_recent_sessions(limit=15)
        if not sessions:
            console.print("[yellow]Chưa có lịch sử kiểm tra nào trong cơ sở dữ liệu.[/yellow]")
            return

        table = Table(title="📖 Lịch Sử Các Phiên Kiểm Tra Gần Đây", style="cyan")
        table.add_column("ID", justify="center", style="bold")
        table.add_column("Thời gian", style="magenta")
        table.add_column("Tổng", justify="right")
        table.add_column("🟢 Sống", justify="right", style="green")
        table.add_column("🔴 Chết", justify="right", style="red")
        table.add_column("⚡ Nhanh", justify="right", style="cyan")
        table.add_column("Độ trễ TB", justify="right")
        table.add_column("Nhanh nhất", style="yellow")

        for s in sessions:
            avg_lat = f"{s['avg_latency']:.0f} ms" if s.get("avg_latency") is not None else "--"
            table.add_row(
                str(s["id"]),
                str(s["started_at"]),
                f"{s['total']:,}",
                f"{s['alive']:,}",
                f"{s['dead']:,}",
                f"{s['fast']:,}",
                avg_lat,
                str(s.get("fastest_proxy") or "--")
            )
        console.print(table)
        return

    # Parse input proxies or Auto-Scrape
    proxies: List[ProxyItem] = []
    default_proto = ProxyProtocol.from_string(args.protocol)

    if args.scrape or args.auto_fetch:
        console.print("[bold cyan]🌐 Đang tự động cào proxy từ các nguồn công cộng uy tín...[/bold cyan]")
        async def _fetch():
            return await PublicProxyScraper.fetch_all(protocol=default_proto)
        
        fetched, raw_count = asyncio.run(_fetch())
        proxies = fetched
        console.print(f"[green]✓[/green] Đã tải về [bold]{raw_count:,}[/bold] proxy thô -> Lọc thành [bold cyan]{len(proxies):,}[/bold cyan] proxy độc nhất!")
    elif args.file:
        if not os.path.isfile(args.file):
            console.print(f"[bold red]Lỗi:[/bold red] Không tìm thấy file: {args.file}")
            sys.exit(1)
        with open(args.file, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
        
        if args.file.lower().endswith(".csv"):
            proxies, dupes, invalid = ProxyParser.parse_csv_file(content, default_protocol=default_proto)
        else:
            proxies, dupes, invalid = ProxyParser.parse_text(content, default_protocol=default_proto)
        
        console.print(f"[green]✓[/green] Đã nạp [bold]{len(proxies):,}[/bold] proxy hợp lệ từ [cyan]{args.file}[/cyan] (Bỏ qua {dupes:,} trùng lặp, {invalid:,} lỗi)")
    elif args.paste:
        proxies, dupes, invalid = ProxyParser.parse_text(args.paste, default_protocol=default_proto)
        console.print(f"[green]✓[/green] Đã nạp [bold]{len(proxies):,}[/bold] proxy hợp lệ từ dòng lệnh.")
    else:
        console.print("[bold yellow]Vui lòng cung cấp: --file <path>, --scrape (tải proxy công cộng), hoặc --paste <string>[/bold yellow]")
        console.print("Xem trợ giúp: python main.py --help")
        sys.exit(1)

    if not proxies:
        console.print("[bold red]Không có proxy hợp lệ nào để kiểm tra.[/bold red]")
        sys.exit(1)

    # Configure engine
    config = CheckerConfig(
        workers=args.workers,
        timeout_sec=args.timeout,
        retries=args.retries,
        target_url=args.target,
        default_protocol=default_proto,
        enable_geoip=not args.no_geoip
    )

    console.print(f"[bold]Cấu hình:[/bold] Luồng: [cyan]{config.workers}[/cyan] | Timeout: [cyan]{config.timeout_sec}s[/cyan] | Mục tiêu: [cyan]{config.target_url}[/cyan]\n")

    # Execution with Rich Progress
    engine = CheckerEngine(config)
    alive_results: List[CheckResult] = []

    async def _execute():
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=35, style="bright_black", complete_style="green"),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("• [cyan]{task.completed}/{task.total}[/cyan] checked"),
            TimeRemainingColumn(),
            console=console
        ) as progress:
            task_id = progress.add_task("[bold cyan]Đang kiểm tra...", total=len(proxies))

            def on_res(r: CheckResult, stats: CheckerStats):
                progress.update(task_id, completed=stats.checked)
                if r.is_alive:
                    alive_results.append(r)
                    flag = get_country_flag(r.country_code)
                    console.print(
                        f"  [bold green]ALIVE[/bold green] [white]{r.proxy.host}:{r.proxy.port}[/white] "
                        f"[{r.protocol_detected.value}] "
                        f"[yellow]{format_latency(r.latency_ms)}[/yellow] "
                        f"{flag} {r.country_name or ''}"
                    )

            engine.on_result = on_res
            return await engine.run(proxies)

    results = asyncio.run(_execute())

    # Summary Table
    stats = engine.stats
    summary_table = Table(title="\n📊 KẾT QUẢ KIỂM TRA PROXY", style="bright_blue")
    summary_table.add_column("Chỉ Số", style="bold white")
    summary_table.add_column("Số Lượng / Giá Trị", justify="right", style="bold")

    summary_table.add_row("Tổng Số Proxy", f"{stats.total:,}")
    summary_table.add_row("🟢 Sống (Alive)", f"[green]{stats.alive:,}[/green]")
    summary_table.add_row("🔴 Chết (Dead)", f"[red]{stats.dead:,}[/red]")
    summary_table.add_row("⚠️ Timeout", f"[yellow]{stats.timeout:,}[/yellow]")
    summary_table.add_row("⚡ Nhanh (<500ms)", f"[cyan]{stats.fast:,}[/cyan]")
    summary_table.add_row("Độ Trễ Trung Bình", f"{stats.avg_latency:.0f} ms" if stats.avg_latency else "--")
    summary_table.add_row("Proxy Nhanh Nhất", f"{stats.fastest_proxy or '--'} ({stats.fastest_latency:.0f}ms)" if stats.fastest_latency else "--")
    summary_table.add_row("Thời Gian Thực Thi", f"{stats.elapsed_time:.1f} s ({stats.speed_rate:.1f} proxy/s)")

    console.print(summary_table)

    # Save to history SQLite
    if stats.checked > 0:
        history_manager.record_session(stats, results, target_url=config.target_url)

    # Export if requested
    if args.export:
        preset = (args.export_preset or "ALIVE").upper()
        fmt = (args.export_format or "txt").lower()
        if fmt == "csv" or args.export.endswith(".csv"):
            count = ProxyExporter.export_to_csv(results, args.export, preset=preset)
        elif fmt == "json" or args.export.endswith(".json"):
            count = ProxyExporter.export_to_json(results, args.export, preset=preset)
        else:
            count = ProxyExporter.export_to_txt(results, args.export, preset=preset)
        
        console.print(f"\n[bold green]✓[/bold green] Đã xuất [bold]{count:,}[/bold] proxy ({preset}) vào: [underline cyan]{args.export}[/underline cyan]")


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="BAO PROXY CHECKER - High Speed Multi-Protocol Proxy Verifier")
    parser.add_argument("--cli", action="store_true", help="Chạy ở chế độ dòng lệnh (CLI)")
    parser.add_argument("-s", "--scrape", "--auto-fetch", dest="scrape", action="store_true", help="Tự động cào tải proxy mới nhất từ các nguồn công cộng")
    parser.add_argument("-f", "--file", type=str, help="Đường dẫn file proxy (.txt hoặc .csv)")
    parser.add_argument("-p", "--paste", type=str, help="Chuỗi proxy dán trực tiếp")
    parser.add_argument("-w", "--workers", type=int, default=50, help="Số luồng đồng thời (mặc định 50)")
    parser.add_argument("-t", "--timeout", type=float, default=5.0, help="Thời gian chờ tối đa (giây, mặc định 5.0)")
    parser.add_argument("-r", "--retries", type=int, default=0, help="Số lần thử lại khi proxy lỗi (mặc định 0)")
    parser.add_argument("--protocol", type=str, default="AUTO", choices=["AUTO", "HTTP", "HTTPS", "SOCKS4", "SOCKS5"], help="Giao thức kiểm tra")
    parser.add_argument("--target", type=str, default="http://httpbin.org/ip", help="URL mục tiêu để kiểm tra proxy")
    parser.add_argument("-o", "--export", type=str, help="Đường dẫn file xuất kết quả (VD: alive.txt, alive.csv)")
    parser.add_argument("--export-preset", type=str, default="ALIVE", choices=["ALIVE", "FAST", "ALL", "HTTP", "SOCKS4", "SOCKS5"], help="Bộ lọc khi xuất")
    parser.add_argument("--export-format", type=str, default="txt", choices=["txt", "csv", "json"], help="Định dạng xuất")
    parser.add_argument("--no-geoip", action="store_true", help="Tắt tra cứu quốc gia GeoIP để tăng tốc tối đa")
    parser.add_argument("--history", action="store_true", help="Xem lịch sử các phiên kiểm tra trước đó")
    return parser
