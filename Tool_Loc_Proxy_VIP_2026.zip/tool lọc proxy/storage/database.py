"""
SQLite Database schema and manager for Session History tracking.
"""
import sqlite3
import os
from contextlib import contextmanager
from datetime import datetime
from typing import List, Dict, Any, Optional
from ..checker.models import CheckerStats, CheckResult, ProxyStatus, ProxyProtocol, ProxyItem
from ..utils.logger import logger


class HistoryDatabase:
    """Manages persistent SQLite storage of check sessions and results."""

    def __init__(self, db_path: Optional[str] = None):
        if not db_path:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            data_dir = os.path.join(base_dir, "data")
            os.makedirs(data_dir, exist_ok=True)
            self.db_path = os.path.join(data_dir, "history.db")
        else:
            self.db_path = db_path

        self._init_db()

    @contextmanager
    def _get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()

    def _init_db(self):
        """Initializes database tables if they do not exist."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    started_at TEXT NOT NULL,
                    finished_at TEXT NOT NULL,
                    total INTEGER NOT NULL,
                    alive INTEGER NOT NULL,
                    dead INTEGER NOT NULL,
                    timeout INTEGER NOT NULL,
                    fast INTEGER NOT NULL,
                    avg_latency REAL,
                    fastest_proxy TEXT,
                    fastest_latency REAL,
                    elapsed_sec REAL,
                    target_url TEXT,
                    note TEXT
                )
            """)

            cursor.execute("""
                CREATE TABLE IF NOT EXISTS session_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id INTEGER NOT NULL,
                    host TEXT NOT NULL,
                    port INTEGER NOT NULL,
                    username TEXT,
                    protocol TEXT NOT NULL,
                    status TEXT NOT NULL,
                    latency_ms REAL,
                    country_code TEXT,
                    country_name TEXT,
                    city TEXT,
                    org TEXT,
                    error_message TEXT,
                    raw_proxy TEXT,
                    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
                )
            """)

            cursor.execute("CREATE INDEX IF NOT EXISTS idx_results_session ON session_results(session_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_results_status ON session_results(status)")
            conn.commit()

    def save_session(
        self,
        stats: CheckerStats,
        results: List[CheckResult],
        target_url: str = "",
        note: str = ""
    ) -> int:
        """Saves a completed check session and all its individual results."""
        started_str = datetime.fromtimestamp(stats.start_time).strftime("%Y-%m-%d %H:%M:%S") if stats.start_time else datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        finished_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO sessions (
                    started_at, finished_at, total, alive, dead, timeout, fast,
                    avg_latency, fastest_proxy, fastest_latency, elapsed_sec, target_url, note
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                started_str,
                finished_str,
                stats.total,
                stats.alive,
                stats.dead,
                stats.timeout,
                stats.fast,
                stats.avg_latency,
                stats.fastest_proxy,
                stats.fastest_latency,
                stats.elapsed_time,
                target_url,
                note
            ))
            session_id = cursor.lastrowid

            # Insert batch results
            result_rows = []
            for r in results:
                result_rows.append((
                    session_id,
                    r.proxy.host,
                    r.proxy.port,
                    r.proxy.username,
                    r.protocol_detected.value if r.protocol_detected != ProxyProtocol.AUTO else r.proxy.protocol.value,
                    r.status.value,
                    r.latency_ms,
                    r.country_code,
                    r.country_name,
                    r.city,
                    r.org,
                    r.error_message,
                    r.proxy.raw
                ))

            cursor.executemany("""
                INSERT INTO session_results (
                    session_id, host, port, username, protocol, status,
                    latency_ms, country_code, country_name, city, org, error_message, raw_proxy
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, result_rows)

            conn.commit()
            logger.info(f"Saved session #{session_id} with {len(results)} proxy results to database.")
            return session_id

    def get_sessions(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Retrieves recent session summaries."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM sessions ORDER BY id DESC LIMIT ?
            """, (limit,))
            return [dict(row) for row in cursor.fetchall()]

    def get_session_results(self, session_id: int) -> List[CheckResult]:
        """Loads results of a past session as CheckResult objects."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM session_results WHERE session_id = ? ORDER BY id ASC
            """, (session_id,))
            rows = cursor.fetchall()

            results: List[CheckResult] = []
            for r in rows:
                proxy = ProxyItem(
                    raw=r["raw_proxy"] or f"{r['host']}:{r['port']}",
                    host=r["host"],
                    port=r["port"],
                    username=r["username"],
                    protocol=ProxyProtocol.from_string(r["protocol"])
                )
                res = CheckResult(
                    proxy=proxy,
                    status=ProxyStatus(r["status"]) if r["status"] in ProxyStatus._value2member_map_ else ProxyStatus.DEAD,
                    latency_ms=r["latency_ms"],
                    protocol_detected=ProxyProtocol.from_string(r["protocol"]),
                    country_code=r["country_code"],
                    country_name=r["country_name"],
                    city=r["city"],
                    org=r["org"],
                    error_message=r["error_message"]
                )
                results.append(res)
            return results

    def delete_session(self, session_id: int):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM session_results WHERE session_id = ?", (session_id,))
            cursor.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
            conn.commit()

    def clear_all(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM session_results")
            cursor.execute("DELETE FROM sessions")
            conn.commit()


# Default singleton instance
history_db = HistoryDatabase()
