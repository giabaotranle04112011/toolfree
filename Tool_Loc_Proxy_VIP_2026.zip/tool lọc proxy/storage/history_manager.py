"""
High-level History Manager.
"""
from typing import List, Dict, Any, Optional
from .database import history_db, HistoryDatabase
from ..checker.models import CheckerStats, CheckResult


class HistoryManager:
    """Manages check history operations."""

    def __init__(self, db: Optional[HistoryDatabase] = None):
        self.db = db or history_db

    def record_session(
        self,
        stats: CheckerStats,
        results: List[CheckResult],
        target_url: str = "",
        note: str = ""
    ) -> int:
        return self.db.save_session(stats, results, target_url, note)

    def list_recent_sessions(self, limit: int = 50) -> List[Dict[str, Any]]:
        return self.db.get_sessions(limit=limit)

    def load_session_results(self, session_id: int) -> List[CheckResult]:
        return self.db.get_session_results(session_id)

    def delete_session(self, session_id: int):
        self.db.delete_session(session_id)

    def clear_history(self):
        self.db.clear_all()


history_manager = HistoryManager()
