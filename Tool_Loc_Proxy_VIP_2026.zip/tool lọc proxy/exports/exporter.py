"""
Flexible Exporter for proxy results to .txt, .csv, and .json formats.
"""
import csv
import json
import os
from typing import List, Optional
from datetime import datetime
from ..checker.models import CheckResult, ProxyStatus, ProxyProtocol, FilterCriteria
from ..utils.logger import logger


class ProxyExporter:
    """Handles exporting check results into multiple formats with custom filters."""

    @staticmethod
    def filter_results(
        results: List[CheckResult],
        preset: str = "ALL",  # "ALL", "ALIVE", "FAST", "HTTP", "SOCKS4", "SOCKS5"
        custom_filter: Optional[FilterCriteria] = None
    ) -> List[CheckResult]:
        filtered = results

        if preset == "ALIVE":
            filtered = [r for r in filtered if r.status == ProxyStatus.ALIVE]
        elif preset == "FAST":
            filtered = [r for r in filtered if r.is_fast]
        elif preset == "HTTP":
            filtered = [r for r in filtered if r.status == ProxyStatus.ALIVE and (r.protocol_detected in (ProxyProtocol.HTTP, ProxyProtocol.HTTPS) or r.proxy.protocol in (ProxyProtocol.HTTP, ProxyProtocol.HTTPS))]
        elif preset == "SOCKS4":
            filtered = [r for r in filtered if r.status == ProxyStatus.ALIVE and (r.protocol_detected == ProxyProtocol.SOCKS4 or r.proxy.protocol == ProxyProtocol.SOCKS4)]
        elif preset == "SOCKS5":
            filtered = [r for r in filtered if r.status == ProxyStatus.ALIVE and (r.protocol_detected == ProxyProtocol.SOCKS5 or r.proxy.protocol == ProxyProtocol.SOCKS5)]

        if custom_filter:
            filtered = [r for r in filtered if custom_filter.matches(r)]

        return filtered

    @classmethod
    def export_to_txt(
        cls,
        results: List[CheckResult],
        filepath: str,
        preset: str = "ALIVE",
        include_protocol: bool = False,
        include_auth: bool = True
    ) -> int:
        """Exports filtered proxies to a clean text file (one proxy per line)."""
        filtered = cls.filter_results(results, preset=preset)
        os.makedirs(os.path.dirname(os.path.abspath(filepath)), exist_ok=True)

        lines = []
        for r in filtered:
            proto_to_use = r.protocol_detected if r.protocol_detected != ProxyProtocol.AUTO else r.proxy.protocol
            line = r.proxy.to_export_string(include_protocol=False, include_auth=include_auth)
            if include_protocol and proto_to_use != ProxyProtocol.AUTO:
                line = f"{proto_to_use.value.lower()}://{line}"
            lines.append(line)

        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
            if lines:
                f.write("\n")

        logger.info(f"Exported {len(lines)} proxies ({preset}) to TXT: {filepath}")
        return len(lines)

    @classmethod
    def export_to_csv(
        cls,
        results: List[CheckResult],
        filepath: str,
        preset: str = "ALL"
    ) -> int:
        """Exports full metadata of proxies to CSV."""
        filtered = cls.filter_results(results, preset=preset)
        os.makedirs(os.path.dirname(os.path.abspath(filepath)), exist_ok=True)

        fieldnames = [
            "host", "port", "protocol", "status", "latency_ms",
            "speed_tier", "country_code", "country_name", "city",
            "org", "error", "username", "raw_proxy"
        ]

        with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for r in filtered:
                proto = r.protocol_detected.value if r.protocol_detected != ProxyProtocol.AUTO else r.proxy.protocol.value
                writer.writerow({
                    "host": r.proxy.host,
                    "port": r.proxy.port,
                    "protocol": proto,
                    "status": r.status.value,
                    "latency_ms": round(r.latency_ms, 1) if r.latency_ms is not None else "",
                    "speed_tier": r.speed_tier.value,
                    "country_code": r.country_code or "",
                    "country_name": r.country_name or "",
                    "city": r.city or "",
                    "org": r.org or "",
                    "error": r.error_message or "",
                    "username": r.proxy.username or "",
                    "raw_proxy": r.proxy.raw
                })

        logger.info(f"Exported {len(filtered)} proxies ({preset}) to CSV: {filepath}")
        return len(filtered)

    @classmethod
    def export_to_json(
        cls,
        results: List[CheckResult],
        filepath: str,
        preset: str = "ALL"
    ) -> int:
        """Exports results to structured JSON."""
        filtered = cls.filter_results(results, preset=preset)
        os.makedirs(os.path.dirname(os.path.abspath(filepath)), exist_ok=True)

        data = [r.to_dict() for r in filtered]
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        logger.info(f"Exported {len(filtered)} proxies ({preset}) to JSON: {filepath}")
        return len(filtered)
