"""
Comprehensive Unit & Integration Test Suite for BAO PROXY CHECKER.
"""
import unittest
import os
import tempfile
import json
import csv
from bao_proxy_checker.checker.models import ProxyItem, CheckResult, ProxyStatus, ProxyProtocol, CheckerStats, FilterCriteria, CheckerConfig
from bao_proxy_checker.checker.parser import ProxyParser
from bao_proxy_checker.storage.database import HistoryDatabase
from bao_proxy_checker.exports.exporter import ProxyExporter
from bao_proxy_checker.utils.validator import is_valid_host, is_valid_port, validate_proxy_components
from bao_proxy_checker.utils.helpers import mask_credentials, get_country_flag, format_latency


class TestProxyValidator(unittest.TestCase):
    def test_valid_hosts(self):
        self.assertTrue(is_valid_host("1.1.1.1"))
        self.assertTrue(is_valid_host("192.168.1.1"))
        self.assertTrue(is_valid_host("proxy.example.com"))
        self.assertTrue(is_valid_host("localhost"))
        self.assertFalse(is_valid_host(""))
        self.assertFalse(is_valid_host("999.999.999.999"))
        self.assertFalse(is_valid_host("invalid host with spaces"))

    def test_valid_ports(self):
        self.assertTrue(is_valid_port(80))
        self.assertTrue(is_valid_port("8080"))
        self.assertTrue(is_valid_port(65535))
        self.assertFalse(is_valid_port(0))
        self.assertFalse(is_valid_port(65536))
        self.assertFalse(is_valid_port("abc"))
        self.assertFalse(is_valid_port(None))


class TestProxyParser(unittest.TestCase):
    def test_parse_formats(self):
        # Format 1: IP:PORT
        p1 = ProxyParser.parse_line("1.2.3.4:8080")
        self.assertIsNotNone(p1)
        self.assertEqual(p1.host, "1.2.3.4")
        self.assertEqual(p1.port, 8080)
        self.assertIsNone(p1.username)

        # Format 2: IP:PORT:USER:PASS
        p2 = ProxyParser.parse_line("10.0.0.1:1080:admin:secret123")
        self.assertIsNotNone(p2)
        self.assertEqual(p2.host, "10.0.0.1")
        self.assertEqual(p2.port, 1080)
        self.assertEqual(p2.username, "admin")
        self.assertEqual(p2.password, "secret123")
        self.assertTrue(p2.has_auth)
        self.assertIn("******", p2.masked_representation)

        # Format 3: USER:PASS@IP:PORT
        p3 = ProxyParser.parse_line("myuser:mypass@proxy.corp.net:3128")
        self.assertIsNotNone(p3)
        self.assertEqual(p3.host, "proxy.corp.net")
        self.assertEqual(p3.port, 3128)
        self.assertEqual(p3.username, "myuser")
        self.assertEqual(p3.password, "mypass")

        # Format 4: URL scheme
        p4 = ProxyParser.parse_line("socks5://user:pass@127.0.0.1:9050")
        self.assertIsNotNone(p4)
        self.assertEqual(p4.protocol, ProxyProtocol.SOCKS5)
        self.assertEqual(p4.host, "127.0.0.1")
        self.assertEqual(p4.port, 9050)
        self.assertEqual(p4.username, "user")
        self.assertEqual(p4.password, "pass")

    def test_parse_text_with_dupes_and_invalid(self):
        sample_text = """
        # Comment line
        1.1.1.1:80
        1.1.1.1:80  # Duplicate
        
        2.2.2.2:8080
        invalid_line_without_port
        3.3.3.3:99999
        4.4.4.4:1080:user:pass
        """
        valid, dupes, invalid = ProxyParser.parse_text(sample_text)
        self.assertEqual(len(valid), 3)
        self.assertEqual(dupes, 1)
        self.assertGreaterEqual(invalid, 2)

    def test_parse_csv(self):
        csv_data = """ip,port,username,password,protocol
1.2.3.4,8080,admin,pass,http
5.6.7.8,1080,,,socks5
"""
        valid, dupes, invalid = ProxyParser.parse_csv_file(csv_data)
        self.assertEqual(len(valid), 2)
        self.assertEqual(valid[0].host, "1.2.3.4")
        self.assertEqual(valid[0].port, 8080)
        self.assertEqual(valid[0].protocol, ProxyProtocol.HTTP)
        self.assertEqual(valid[1].host, "5.6.7.8")
        self.assertEqual(valid[1].protocol, ProxyProtocol.SOCKS5)


class TestStatsAndFiltering(unittest.TestCase):
    def test_stats_recording(self):
        stats = CheckerStats(total=3)
        p1 = ProxyItem(raw="1.1.1.1:80", host="1.1.1.1", port=80)
        r1 = CheckResult(proxy=p1, status=ProxyStatus.ALIVE, latency_ms=150.0)
        stats.record_result(r1)

        p2 = ProxyItem(raw="2.2.2.2:80", host="2.2.2.2", port=80)
        r2 = CheckResult(proxy=p2, status=ProxyStatus.DEAD)
        stats.record_result(r2)

        p3 = ProxyItem(raw="3.3.3.3:80", host="3.3.3.3", port=80)
        r3 = CheckResult(proxy=p3, status=ProxyStatus.TIMEOUT)
        stats.record_result(r3)

        self.assertEqual(stats.checked, 3)
        self.assertEqual(stats.alive, 1)
        self.assertEqual(stats.dead, 1)
        self.assertEqual(stats.timeout, 1)
        self.assertEqual(stats.fast, 1)
        self.assertEqual(stats.avg_latency, 150.0)
        self.assertEqual(stats.fastest_proxy, "1.1.1.1:80")

    def test_filtering(self):
        p1 = ProxyItem(raw="1.1.1.1:80", host="1.1.1.1", port=80, protocol=ProxyProtocol.HTTP)
        r1 = CheckResult(proxy=p1, status=ProxyStatus.ALIVE, latency_ms=200.0, country_code="VN", country_name="Vietnam")

        p2 = ProxyItem(raw="2.2.2.2:1080", host="2.2.2.2", port=1080, protocol=ProxyProtocol.SOCKS5)
        r2 = CheckResult(proxy=p2, status=ProxyStatus.ALIVE, latency_ms=800.0, country_code="US", country_name="United States")

        p3 = ProxyItem(raw="3.3.3.3:80", host="3.3.3.3", port=80, protocol=ProxyProtocol.HTTP)
        r3 = CheckResult(proxy=p3, status=ProxyStatus.DEAD)

        # Filter by status
        crit_alive = FilterCriteria(status="ALIVE")
        self.assertTrue(crit_alive.matches(r1))
        self.assertTrue(crit_alive.matches(r2))
        self.assertFalse(crit_alive.matches(r3))

        # Filter by fast (<500ms)
        crit_fast = FilterCriteria(status="FAST")
        self.assertTrue(crit_fast.matches(r1))
        self.assertFalse(crit_fast.matches(r2))

        # Filter by search
        crit_search = FilterCriteria(search_query="vietnam")
        self.assertTrue(crit_search.matches(r1))
        self.assertFalse(crit_search.matches(r2))


class TestDatabaseAndExport(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.temp_dir.name, "test_history.db")
        self.db = HistoryDatabase(db_path=self.db_path)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_save_and_retrieve_session(self):
        stats = CheckerStats(total=2, alive=1, dead=1, start_time=100.0, elapsed_time=5.0)
        p1 = ProxyItem(raw="1.2.3.4:80", host="1.2.3.4", port=80)
        r1 = CheckResult(proxy=p1, status=ProxyStatus.ALIVE, latency_ms=120.0, country_code="VN")
        p2 = ProxyItem(raw="5.6.7.8:80", host="5.6.7.8", port=80)
        r2 = CheckResult(proxy=p2, status=ProxyStatus.DEAD, error_message="Refused")

        sid = self.db.save_session(stats, [r1, r2], target_url="http://httpbin.org/ip")
        self.assertGreater(sid, 0)

        sessions = self.db.get_sessions()
        self.assertEqual(len(sessions), 1)
        self.assertEqual(sessions[0]["total"], 2)
        self.assertEqual(sessions[0]["alive"], 1)

        results = self.db.get_session_results(sid)
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0].proxy.host, "1.2.3.4")
        self.assertEqual(results[0].status, ProxyStatus.ALIVE)

    def test_export_formats(self):
        p1 = ProxyItem(raw="1.2.3.4:80", host="1.2.3.4", port=80)
        r1 = CheckResult(proxy=p1, status=ProxyStatus.ALIVE, latency_ms=120.0)
        results = [r1]

        # TXT
        txt_path = os.path.join(self.temp_dir.name, "out.txt")
        count_txt = ProxyExporter.export_to_txt(results, txt_path, preset="ALIVE")
        self.assertEqual(count_txt, 1)
        with open(txt_path, "r") as f:
            self.assertIn("1.2.3.4:80", f.read())

        # CSV
        csv_path = os.path.join(self.temp_dir.name, "out.csv")
        count_csv = ProxyExporter.export_to_csv(results, csv_path, preset="ALIVE")
        self.assertEqual(count_csv, 1)
        with open(csv_path, "r", encoding="utf-8-sig") as f:
            self.assertIn("1.2.3.4", f.read())

        # JSON
        json_path = os.path.join(self.temp_dir.name, "out.json")
        count_json = ProxyExporter.export_to_json(results, json_path, preset="ALIVE")
        self.assertEqual(count_json, 1)
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            self.assertEqual(data[0]["host"], "1.2.3.4")


if __name__ == "__main__":
    unittest.main()
