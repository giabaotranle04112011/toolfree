"""
Entry point for BAO PROXY CHECKER.
Launches Modern CustomTkinter GUI by default or CLI mode when specified.
"""
import sys
import os

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from bao_proxy_checker.cli import build_arg_parser, run_cli_checker


def main():
    parser = build_arg_parser()
    
    # Check if CLI flags were passed or if user explicitly requested CLI mode
    args, unknown = parser.parse_known_args()

    # If any CLI arguments are passed or explicitly --cli
    cli_flags = ("--cli", "-f", "--file", "-p", "--paste", "--history", "-h", "--help")
    is_cli_run = any(flag in sys.argv for flag in cli_flags)

    if is_cli_run:
        full_args = parser.parse_args()
        run_cli_checker(full_args)
    else:
        # Launch GUI
        try:
            from bao_proxy_checker.gui.app import BaoProxyCheckerApp
            app = BaoProxyCheckerApp()
            app.mainloop()
        except ImportError as e:
            print(f"[!] Warning: GUI requirements not met ({e}). Falling back to CLI help...")
            parser.print_help()
        except Exception as e:
            print(f"[!] Error launching GUI: {e}")
            import traceback
            traceback.print_exc()


if __name__ == "__main__":
    main()
