# ⚡ BAO PROXY CHECKER (PRO VIP 2026)

**BAO PROXY CHECKER** là công cụ lọc và kiểm tra danh sách proxy đa luồng siêu tốc, chuyên nghiệp với giao diện người dùng hiện đại (**CustomTkinter**) và chế độ dòng lệnh (**CLI Mode**). 

Hỗ trợ kiểm tra độ sống, đo tốc độ/độ trễ (latency), tự động nhận diện giao thức (**HTTP, HTTPS, SOCKS4, SOCKS5**), tra cứu thông tin địa lý (**GeoIP / ISP**), lưu trữ lịch sử SQLite và xuất file đa định dạng.

---

## 🌟 Tính Năng Nổi Bật

| Tính năng | Mô tả chi tiết |
| :--- | :--- |
| 🚀 **Asyncio Engine Siêu Tốc** | Tùy chỉnh 1 - 300 luồng (workers), kiểm tra hàng nghìn proxy trong vài giây không đơ lag UI |
| 🎯 **Đa Giao Thức & Auto Detect** | Tự động thử và phân loại chính xác **HTTP, HTTPS, SOCKS4, SOCKS5** |
| 📥 **Nhập Liệu Linh Hoạt** | Hỗ trợ nhập file `.txt`, `.csv`, dán trực tiếp (`IP:PORT`, `IP:PORT:USER:PASS`, `USER:PASS@IP:PORT`) |
| 🧹 **Làm Sạch Dữ Liệu Tự Động** | Tự động loại bỏ dòng trống, lọc comment, deduplicate trùng lặp, chuẩn hóa IP & Port |
| ⚡ **Speed Test & Đo Độ Trễ** | Phân loại tốc độ: **Fast (<500ms)**, **Medium (500-1500ms)**, **Slow (>1500ms)** |
| 🔍 **Bộ Lọc Đa Năng** | Lọc theo trạng thái (*Alive, Dead, Timeout*), giao thức, độ trễ tối đa, tìm kiếm IP/Quốc gia |
| 🌐 **GeoIP & Quốc Kỳ** | Hiển thị quốc kỳ emoji, tên quốc gia, thành phố và nhà mạng (ISP) |
| 💾 **Xuất Dữ Liệu Chuyên Nghiệp** | Xuất nhanh Proxy Sống, Proxy Nhanh, Tất cả ra định dạng `.txt`, `.csv`, `.json` |
| 📖 **Lịch Sử Phiên SQLite** | Tự động lưu trữ các phiên kiểm tra để xem lại, phân tích hoặc xuất lại bất cứ lúc nào |
| 🔒 **Bảo Mật An Toàn** | Tự động ẩn mật khẩu (`user:******`) trên giao diện và log, không gửi proxy ra ngoài |

---

## 📂 Cấu Trúc Thư Mục

```text
bao_proxy_checker/
├── main.py                     # Entry point chính (chạy GUI hoặc CLI)
├── cli.py                      # Chế độ dòng lệnh với Rich Dashboard
├── requirements.txt            # Danh sách thư viện phụ thuộc
├── README.md                   # Hướng dẫn chi tiết
├── gui/
│   ├── app.py                  # Cửa sổ chính CustomTkinter
│   ├── theme.py                # Bảng màu Dark/Light & phong cách
│   └── components/
│       ├── header.py           # Thanh tiêu đề & nút tiện ích
│       ├── stats_bar.py        # 6 thẻ thống kê & thanh tiến trình
│       ├── control_panel.py    # Thanh điều khiển & nút Start/Pause/Stop
│       ├── filter_bar.py       # Bộ lọc nhanh & xuất file
│       ├── proxy_table.py      # Bảng kết quả hiệu năng cao + context menu
│       ├── paste_dialog.py     # Hộp thoại dán proxy trực tiếp
│       ├── history_dialog.py   # Hộp thoại quản lý lịch sử kiểm tra
│       └── settings_dialog.py  # Hộp thoại cấu hình mục tiêu & kết nối
├── checker/
│   ├── engine.py               # Concurrency Engine (Asyncio Worker Pool)
│   ├── parser.py               # Parser chuẩn hóa, lọc trùng & validate
│   └── models.py               # ProxyItem, CheckResult, Stats, Config
├── protocols/
│   ├── base.py                 # Lớp cơ sở & phân loại mã lỗi
│   ├── http_checker.py         # Kiểm tra HTTP / HTTPS
│   ├── socks4_checker.py       # Kiểm tra SOCKS4 / SOCKS4a
│   ├── socks5_checker.py       # Kiểm tra SOCKS5 (hỗ trợ User/Pass)
│   └── detector.py             # Bộ nhận diện giao thức tự động
├── utils/
│   ├── geoip.py                # Tra cứu IP, quốc gia, ISP
│   ├── validator.py            # Kiểm tra định dạng IP, Port, Domain
│   ├── helpers.py              # Xử lý format độ trễ, cờ quốc gia, ẩn pass
│   └── logger.py               # Logger bảo mật chống rò rỉ credential
├── storage/
│   ├── database.py             # SQLite lưu trữ lịch sử kiểm tra
│   └── history_manager.py      # Quản lý truy vấn và xóa lịch sử
└── exports/
    └── exporter.py             # Xuất danh sách ra .txt, .csv, .json
```

---

## 🚀 Hướng Dẫn Cài Đặt & Chạy Ứng Dụng

### 1. Cài đặt môi trường

Yêu cầu **Python 3.10+**. Cài đặt các thư viện phụ thuộc:

```bash
pip install -r bao_proxy_checker/requirements.txt
```

### 2. Khởi chạy Giao diện đồ họa (GUI)

**Cách 1:** Double-click vào file `Chay_Bao_Proxy_Checker.bat` trên Windows.

**Cách 2:** Chạy lệnh terminal:
```bash
python bao_proxy_checker/main.py
```

### 3. Khởi chạy Chế độ dòng lệnh (CLI)

Chạy kiểm tra file proxy trực tiếp qua terminal:
```bash
# Kiểm tra file proxy với 50 workers, timeout 5s và tự động xuất proxy sống ra alive.txt
python bao_proxy_checker/main.py --file proxies.txt --workers 50 --timeout 5 --export alive.txt

# Kiểm tra proxy SOCKS5 với định dạng CSV
python bao_proxy_checker/main.py --file proxies.txt --protocol SOCKS5 --export socks5_alive.csv --export-format csv

# Xem lịch sử các lần check trước
python bao_proxy_checker/main.py --history
```

---

## 📋 Hướng Dẫn Định Dạng Proxy Đầu Vào

Tool hỗ trợ linh hoạt tất cả các định dạng proxy phổ biến:
1. `IP:PORT` (VD: `103.107.117.242:8080`)
2. `IP:PORT:USERNAME:PASSWORD` (VD: `1.2.3.4:8080:user:pass123`)
3. `USERNAME:PASSWORD@IP:PORT` (VD: `admin:secret@1.2.3.4:1080`)
4. `http://IP:PORT` hoặc `socks5://user:pass@IP:PORT`
5. File CSV có hoặc không có tiêu đề cột (`ip,port,username,password,protocol`).

---

## 🛡️ Cam Kết An Toàn & Bảo Mật

* **Không lưu trữ mật khẩu plaintext ngoài ý muốn**: Mật khẩu được mã hóa/ẩn (`******`) khi hiển thị trên giao diện và log file.
* **Không gửi dữ liệu ra bên ngoài**: Proxy chỉ kết nối trực tiếp đến điểm kiểm tra (Target URL) mà bạn cấu hình.
* **Chỉ sử dụng cho mục đích hợp pháp**: Dành cho quản trị mạng, kiểm thử bảo mật và hệ thống được phép truy cập.

---
© 2026 **BAO PROXY CHECKER Team**. All rights reserved.
