"""
High-performance parser for proxy lists from files, text, and CSVs.
"""
import csv
import io
import re
from typing import List, Tuple, Set, Optional
from urllib.parse import urlparse
from .models import ProxyItem, ProxyProtocol
from ..utils.validator import validate_proxy_components, is_valid_host, is_valid_port


class ProxyParser:
    """Parser & normalizer for proxy strings in various formats."""

    @staticmethod
    def parse_line(line: str, default_protocol: ProxyProtocol = ProxyProtocol.AUTO) -> Optional[ProxyItem]:
        """
        Parses a single line into a ProxyItem.
        Supported formats:
          - IP:PORT
          - IP:PORT:USER:PASS
          - USER:PASS@IP:PORT
          - protocol://IP:PORT
          - protocol://USER:PASS@IP:PORT
          - protocol://IP:PORT:USER:PASS
        """
        if not line:
            return None

        raw = line.strip()
        if not raw or raw.startswith("#") or raw.startswith("//"):
            return None

        # Strip inline comments
        if " #" in raw:
            raw = raw.split(" #", 1)[0].strip()
        elif " //" in raw:
            raw = raw.split(" //", 1)[0].strip()
        elif "\t#" in raw:
            raw = raw.split("\t#", 1)[0].strip()

        protocol = default_protocol
        host = ""
        port = 0
        username: Optional[str] = None
        password: Optional[str] = None

        # Check if line starts with protocol://
        if "://" in raw:
            try:
                parsed_url = urlparse(raw)
                proto_str = parsed_url.scheme.upper()
                protocol = ProxyProtocol.from_string(proto_str)
                
                host = parsed_url.hostname or ""
                port = parsed_url.port or 0
                username = parsed_url.username
                password = parsed_url.password
                
                # Check if rest was formatted as host:port:user:pass
                if not username and parsed_url.netloc and parsed_url.netloc.count(":") >= 3:
                    parts = parsed_url.netloc.split(":")
                    if len(parts) >= 4 and is_valid_port(parts[1]):
                        host = parts[0]
                        port = int(parts[1])
                        username = parts[2]
                        password = parts[3]
            except Exception:
                pass

        # If not parsed via URL scheme or URL parsing didn't yield host/port
        if not host or not port:
            # Strip protocol prefix if present without full URL structure
            clean_str = re.sub(r"^(https?|socks[45]h?|socks4a?)://", "", raw, flags=re.IGNORECASE)
            
            # Detect protocol from prefix if present
            proto_match = re.match(r"^(https?|socks[45]h?|socks4a?)://", raw, flags=re.IGNORECASE)
            if proto_match:
                protocol = ProxyProtocol.from_string(proto_match.group(1))

            # Format 1: USER:PASS@HOST:PORT
            if "@" in clean_str:
                auth_part, net_part = clean_str.rsplit("@", 1)
                if ":" in auth_part:
                    username, password = auth_part.split(":", 1)
                else:
                    username = auth_part
                    password = None
                
                if ":" in net_part:
                    h, p = net_part.split(":", 1)
                    host = h.strip()
                    try:
                        port = int(p.strip())
                    except ValueError:
                        return None
            else:
                # Delimited by ':'
                parts = [p.strip() for p in clean_str.split(":")]
                if len(parts) == 2:
                    # HOST:PORT
                    host = parts[0]
                    try:
                        port = int(parts[1])
                    except ValueError:
                        return None
                elif len(parts) == 4:
                    # HOST:PORT:USER:PASS or USER:PASS:HOST:PORT
                    if is_valid_port(parts[1]):
                        host = parts[0]
                        port = int(parts[1])
                        username = parts[2]
                        password = parts[3]
                    elif is_valid_port(parts[3]):
                        username = parts[0]
                        password = parts[1]
                        host = parts[2]
                        port = int(parts[3])
                    else:
                        return None
                elif len(parts) == 3:
                    # HOST:PORT:USER (empty password)
                    if is_valid_port(parts[1]):
                        host = parts[0]
                        port = int(parts[1])
                        username = parts[2]
                        password = ""
                else:
                    # Try tab or space separation
                    tokens = re.split(r"[\s\t,;]+", clean_str)
                    if len(tokens) >= 2 and is_valid_port(tokens[1]):
                        host = tokens[0]
                        port = int(tokens[1])
                        if len(tokens) >= 4:
                            username = tokens[2]
                            password = tokens[3]
                    else:
                        return None

        # Validate extracted host and port
        valid, _ = validate_proxy_components(host, port)
        if not valid:
            return None

        return ProxyItem(
            raw=raw,
            host=host,
            port=port,
            username=username if username else None,
            password=password if password else None,
            protocol=protocol
        )

    @classmethod
    def parse_text(
        cls, 
        text: str, 
        default_protocol: ProxyProtocol = ProxyProtocol.AUTO,
        deduplicate: bool = True
    ) -> Tuple[List[ProxyItem], int, int]:
        """
        Parses multi-line text into a list of ProxyItems.
        Returns (valid_proxies, duplicate_count, invalid_count).
        """
        valid_proxies: List[ProxyItem] = []
        seen_keys: Set[str] = set()
        duplicates = 0
        invalid = 0

        lines = text.splitlines()
        for line in lines:
            line_str = line.strip()
            if not line_str or line_str.startswith("#") or line_str.startswith("//"):
                continue

            item = cls.parse_line(line_str, default_protocol=default_protocol)
            if not item:
                invalid += 1
                continue

            # Deduplication key based on host, port, username, protocol
            dedup_key = f"{item.protocol.value}:{item.host}:{item.port}:{item.username or ''}"
            if deduplicate and dedup_key in seen_keys:
                duplicates += 1
                continue

            seen_keys.add(dedup_key)
            valid_proxies.append(item)

        return valid_proxies, duplicates, invalid

    @classmethod
    def parse_csv_file(
        cls, 
        content: str, 
        default_protocol: ProxyProtocol = ProxyProtocol.AUTO,
        deduplicate: bool = True
    ) -> Tuple[List[ProxyItem], int, int]:
        """
        Parses CSV data with automatic column detection (ip, port, username, password, type).
        """
        valid_proxies: List[ProxyItem] = []
        seen_keys: Set[str] = set()
        duplicates = 0
        invalid = 0

        try:
            sample = content[:4096]
            try:
                dialect = csv.Sniffer().sniff(sample)
                delimiter = dialect.delimiter
            except Exception:
                delimiter = ","

            reader = csv.reader(io.StringIO(content), delimiter=delimiter)
            rows = list(reader)
            if not rows:
                return [], 0, 0

            first_row = [c.strip().lower() for c in rows[0]]
            has_header = any(k in first_row for k in ("ip", "host", "port", "proxy", "protocol", "type"))
            
            ip_idx = -1
            port_idx = -1
            user_idx = -1
            pass_idx = -1
            proto_idx = -1

            if has_header:
                for idx, col in enumerate(first_row):
                    if col in ("ip", "host", "address", "server"):
                        ip_idx = idx
                    elif col in ("port", "port_number"):
                        port_idx = idx
                    elif col in ("user", "username", "login", "auth_user"):
                        user_idx = idx
                    elif col in ("pass", "password", "pwd", "auth_pass"):
                        pass_idx = idx
                    elif col in ("type", "protocol", "scheme", "proto"):
                        proto_idx = idx
                data_rows = rows[1:]
            else:
                data_rows = rows

            for row in data_rows:
                if not row or not any(row):
                    continue

                if has_header and ip_idx != -1 and port_idx != -1:
                    host = row[ip_idx].strip() if len(row) > ip_idx else ""
                    port_val = row[port_idx].strip() if len(row) > port_idx else ""
                    user = row[user_idx].strip() if user_idx != -1 and len(row) > user_idx else None
                    pwd = row[pass_idx].strip() if pass_idx != -1 and len(row) > pass_idx else None
                    proto_val = row[proto_idx].strip() if proto_idx != -1 and len(row) > proto_idx else None

                    proto = ProxyProtocol.from_string(proto_val) if proto_val else default_protocol
                    
                    if not is_valid_host(host) or not is_valid_port(port_val):
                        invalid += 1
                        continue

                    item = ProxyItem(
                        raw=",".join(row),
                        host=host,
                        port=int(port_val),
                        username=user if user else None,
                        password=pwd if pwd else None,
                        protocol=proto
                    )
                else:
                    line_joined = ":".join([c.strip() for c in row if c.strip()])
                    item = cls.parse_line(line_joined, default_protocol=default_protocol)

                if not item:
                    invalid += 1
                    continue

                dedup_key = f"{item.protocol.value}:{item.host}:{item.port}:{item.username or ''}"
                if deduplicate and dedup_key in seen_keys:
                    duplicates += 1
                    continue

                seen_keys.add(dedup_key)
                valid_proxies.append(item)

        except Exception:
            return cls.parse_text(content, default_protocol=default_protocol, deduplicate=deduplicate)

        return valid_proxies, duplicates, invalid
