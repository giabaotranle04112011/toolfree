"""
Public Proxy Scraper & Aggregator.
Fetches fresh public proxies from high-reputation open-source repositories and public APIs.
"""
import asyncio
import aiohttp
from typing import List, Tuple, Dict, Optional, Callable
from .models import ProxyItem, ProxyProtocol
from .parser import ProxyParser
from ..utils.logger import logger


PUBLIC_SOURCES = {
    ProxyProtocol.HTTP: [
        "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=8000&country=all&ssl=all&anonymity=all",
        "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
        "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt",
        "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
    ],
    ProxyProtocol.SOCKS4: [
        "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=8000&country=all",
        "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks4.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt",
        "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS4_RAW.txt",
    ],
    ProxyProtocol.SOCKS5: [
        "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=8000&country=all",
        "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
        "https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt",
        "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt",
    ]
}


class PublicProxyScraper:
    """Async scraper that downloads and aggregates proxies from public repositories."""

    @classmethod
    async def _fetch_single_source(cls, session: aiohttp.ClientSession, url: str, protocol: ProxyProtocol) -> Tuple[List[ProxyItem], str]:
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=8.0)) as resp:
                if resp.status == 200:
                    text = await resp.text(errors="ignore")
                    items, _, _ = ProxyParser.parse_text(text, default_protocol=protocol, deduplicate=False)
                    return items, url
        except Exception as e:
            logger.debug(f"Failed to fetch {url}: {e}")
        return [], url

    @classmethod
    async def fetch_all(
        cls,
        protocol: ProxyProtocol = ProxyProtocol.AUTO,
        on_source_done: Optional[Callable[[str, int], None]] = None
    ) -> Tuple[List[ProxyItem], int]:
        """
        Asynchronously fetches public proxies across all configured public sources.
        Returns (unique_proxies_list, total_raw_count).
        """
        urls_to_fetch = []
        if protocol == ProxyProtocol.HTTP:
            urls_to_fetch = [(u, ProxyProtocol.HTTP) for u in PUBLIC_SOURCES[ProxyProtocol.HTTP]]
        elif protocol == ProxyProtocol.SOCKS4:
            urls_to_fetch = [(u, ProxyProtocol.SOCKS4) for u in PUBLIC_SOURCES[ProxyProtocol.SOCKS4]]
        elif protocol == ProxyProtocol.SOCKS5:
            urls_to_fetch = [(u, ProxyProtocol.SOCKS5) for u in PUBLIC_SOURCES[ProxyProtocol.SOCKS5]]
        else:
            # AUTO: fetch all protocols
            for proto, urls in PUBLIC_SOURCES.items():
                for u in urls:
                    urls_to_fetch.append((u, proto))

        connector = aiohttp.TCPConnector(ssl=False, limit=30)
        async with aiohttp.ClientSession(connector=connector) as session:
            tasks = [cls._fetch_single_source(session, url, proto) for url, proto in urls_to_fetch]
            results = await asyncio.gather(*tasks)

        all_items: List[ProxyItem] = []
        seen_keys = set()
        unique_items: List[ProxyItem] = []

        for items, url in results:
            if on_source_done:
                on_source_done(url, len(items))
            for item in items:
                all_items.append(item)
                dedup_key = f"{item.protocol.value}:{item.host}:{item.port}"
                if dedup_key not in seen_keys:
                    seen_keys.add(dedup_key)
                    unique_items.append(item)

        logger.info(f"Public Scraper fetched {len(all_items)} raw proxies -> {len(unique_items)} unique proxies.")
        return unique_items, len(all_items)
