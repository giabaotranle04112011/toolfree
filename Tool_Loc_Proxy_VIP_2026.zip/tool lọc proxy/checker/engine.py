"""
Asynchronous Engine for multi-worker proxy checking with pause/resume/stop state management.
"""
import asyncio
import time
from typing import List, Optional, Callable, Dict, Any
from enum import Enum

from .models import ProxyItem, CheckResult, CheckerStats, CheckerConfig, ProxyStatus, ProxyProtocol
from ..protocols.detector import SmartProxyChecker
from ..utils.geoip import GeoIPService
from ..utils.logger import logger


class EngineState(str, Enum):
    IDLE = "IDLE"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    STOPPED = "STOPPED"
    COMPLETED = "COMPLETED"


class CheckerEngine:
    """Core concurrency engine orchestrating asynchronous proxy checks."""

    def __init__(self, config: Optional[CheckerConfig] = None):
        self.config = config or CheckerConfig()
        self.stats = CheckerStats()
        self.state = EngineState.IDLE
        self._smart_checker = SmartProxyChecker()

        # Concurrency controls
        self._pause_event = asyncio.Event()
        self._pause_event.set()  # Not paused by default
        self._stop_requested = False
        self._active_tasks: List[asyncio.Task] = []
        self._queue: Optional[asyncio.Queue] = None

        # Callbacks
        self.on_result: Optional[Callable[[CheckResult, CheckerStats], None]] = None
        self.on_progress: Optional[Callable[[CheckerStats], None]] = None
        self.on_state_change: Optional[Callable[[EngineState], None]] = None
        self.on_finished: Optional[Callable[[CheckerStats], None]] = None

        # In-memory results
        self.results: List[CheckResult] = []

    def _set_state(self, new_state: EngineState):
        self.state = new_state
        if self.on_state_change:
            try:
                self.on_state_change(new_state)
            except Exception as e:
                logger.error(f"Error in on_state_change callback: {e}")

    def pause(self):
        """Pauses the running check engine."""
        if self.state == EngineState.RUNNING:
            self._pause_event.clear()
            self._set_state(EngineState.PAUSED)
            logger.info("Checker engine PAUSED.")

    def resume(self):
        """Resumes the paused check engine."""
        if self.state == EngineState.PAUSED:
            self._pause_event.set()
            self._set_state(EngineState.RUNNING)
            logger.info("Checker engine RESUMED.")

    def stop(self):
        """Signals the engine to stop checking remaining proxies."""
        if self.state in (EngineState.RUNNING, EngineState.PAUSED):
            self._stop_requested = True
            self._pause_event.set()  # Unblock if paused so workers can exit
            self._set_state(EngineState.STOPPED)
            logger.info("Checker engine STOP requested.")

    async def _worker(self, queue: asyncio.Queue, semaphore: asyncio.Semaphore):
        while not self._stop_requested:
            # Wait if paused
            await self._pause_event.wait()

            if self._stop_requested:
                break

            try:
                proxy: ProxyItem = await asyncio.wait_for(queue.get(), timeout=0.2)
            except asyncio.TimeoutError:
                if queue.empty():
                    break
                continue

            async with semaphore:
                # Perform check with retry logic
                res = await self._check_single_proxy(proxy)

                # GeoIP enrichment if alive and missing country
                if res.is_alive and self.config.enable_geoip and not res.country_code:
                    try:
                        geo = await GeoIPService.lookup(res.proxy.host, timeout=2.0)
                        if geo.get("country_code"):
                            res.country_code = geo.get("country_code")
                            res.country_name = geo.get("country_name")
                            res.city = geo.get("city")
                            res.org = geo.get("org")
                    except Exception:
                        pass

                self.results.append(res)
                self.stats.elapsed_time = max(0.001, time.time() - self.stats.start_time)
                self.stats.record_result(res)

                # Notify callbacks
                if self.on_result:
                    try:
                        self.on_result(res, self.stats)
                    except Exception as e:
                        logger.error(f"Error in on_result callback: {e}")

                if self.on_progress:
                    try:
                        self.on_progress(self.stats)
                    except Exception as e:
                        logger.error(f"Error in on_progress callback: {e}")

                queue.task_done()

    async def _check_single_proxy(self, proxy: ProxyItem) -> CheckResult:
        retries_left = max(0, self.config.retries)
        last_result: Optional[CheckResult] = None

        while retries_left >= 0:
            if self._stop_requested:
                break

            # Pick target URL (HTTP vs HTTPS)
            target = self.config.target_url
            if proxy.protocol == ProxyProtocol.HTTPS or (proxy.protocol == ProxyProtocol.AUTO and "https" in self.config.target_url):
                target = self.config.target_url_https

            res = await self._smart_checker.check(
                proxy=proxy,
                target_url=target,
                timeout_sec=self.config.timeout_sec,
                user_agent=self.config.user_agent
            )

            if res.is_alive:
                return res

            last_result = res
            retries_left -= 1
            if retries_left >= 0:
                await asyncio.sleep(0.5)

        return last_result or CheckResult(proxy=proxy, status=ProxyStatus.DEAD)

    async def run(self, proxies: List[ProxyItem]) -> List[CheckResult]:
        """
        Runs the proxy checking process on the provided list of proxies.
        """
        self._stop_requested = False
        self._pause_event.set()
        self.results = []
        self.stats = CheckerStats(
            total=len(proxies),
            start_time=time.time()
        )
        self._set_state(EngineState.RUNNING)

        if not proxies:
            self._set_state(EngineState.COMPLETED)
            if self.on_finished:
                self.on_finished(self.stats)
            return []

        # Populate queue
        queue: asyncio.Queue = asyncio.Queue()
        for p in proxies:
            queue.put_nowait(p)

        worker_count = max(1, min(self.config.workers, len(proxies), 500))
        semaphore = asyncio.Semaphore(worker_count)

        logger.info(f"Starting check for {len(proxies)} proxies with {worker_count} concurrent workers.")

        tasks = [
            asyncio.create_task(self._worker(queue, semaphore))
            for _ in range(worker_count)
        ]
        self._active_tasks = tasks

        try:
            await asyncio.gather(*tasks, return_exceptions=True)
        finally:
            self._active_tasks = []

        self.stats.elapsed_time = max(0.001, time.time() - self.stats.start_time)
        if not self._stop_requested:
            self._set_state(EngineState.COMPLETED)
        else:
            self._set_state(EngineState.STOPPED)

        logger.info(
            f"Check finished: Total={self.stats.total}, Alive={self.stats.alive}, "
            f"Dead={self.stats.dead}, Timeout={self.stats.timeout}, "
            f"AvgLatency={self.stats.avg_latency}ms, Time={self.stats.elapsed_time:.1f}s"
        )

        if self.on_finished:
            try:
                self.on_finished(self.stats)
            except Exception as e:
                logger.error(f"Error in on_finished callback: {e}")

        return self.results
