"""
Data models and Enums for BAO PROXY CHECKER.
"""
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict, Any
import time


class ProxyStatus(str, Enum):
    IDLE = "IDLE"
    CHECKING = "CHECKING"
    ALIVE = "ALIVE"
    DEAD = "DEAD"
    TIMEOUT = "TIMEOUT"
    INVALID = "INVALID"

    @property
    def display_name(self) -> str:
        icons = {
            ProxyStatus.IDLE: "⚪ Chờ",
            ProxyStatus.CHECKING: "⏳ Đang kiểm tra",
            ProxyStatus.ALIVE: "🟢 Alive",
            ProxyStatus.DEAD: "🔴 Dead",
            ProxyStatus.TIMEOUT: "⚠️ Timeout",
            ProxyStatus.INVALID: "❓ Invalid",
        }
        return icons.get(self, self.value)

    @property
    def badge_color(self) -> str:
        colors = {
            ProxyStatus.IDLE: "#6c757d",
            ProxyStatus.CHECKING: "#0dcaf0",
            ProxyStatus.ALIVE: "#10b981",     # vibrant green
            ProxyStatus.DEAD: "#ef4444",      # bright red
            ProxyStatus.TIMEOUT: "#f59e0b",   # amber
            ProxyStatus.INVALID: "#8b5cf6",   # purple
        }
        return colors.get(self, "#6c757d")


class ProxyProtocol(str, Enum):
    AUTO = "AUTO"
    HTTP = "HTTP"
    HTTPS = "HTTPS"
    SOCKS4 = "SOCKS4"
    SOCKS5 = "SOCKS5"

    @classmethod
    def from_string(cls, val: str) -> "ProxyProtocol":
        val_upper = (val or "").strip().upper()
        if val_upper in ("SOCKS5", "SOCKS5H"):
            return cls.SOCKS5
        elif val_upper in ("SOCKS4", "SOCKS4A"):
            return cls.SOCKS4
        elif val_upper == "HTTPS":
            return cls.HTTPS
        elif val_upper == "HTTP":
            return cls.HTTP
        return cls.AUTO


class SpeedTier(str, Enum):
    FAST = "FAST"        # < 500ms
    MEDIUM = "MEDIUM"    # 500ms - 1500ms
    SLOW = "SLOW"        # > 1500ms
    UNKNOWN = "UNKNOWN"

    @classmethod
    def from_latency(cls, latency_ms: Optional[float]) -> "SpeedTier":
        if latency_ms is None or latency_ms < 0:
            return cls.UNKNOWN
        if latency_ms < 500:
            return cls.FAST
        elif latency_ms <= 1500:
            return cls.MEDIUM
        return cls.SLOW

    @property
    def color(self) -> str:
        colors = {
            SpeedTier.FAST: "#10b981",     # green
            SpeedTier.MEDIUM: "#f59e0b",   # yellow/orange
            SpeedTier.SLOW: "#ef4444",     # red
            SpeedTier.UNKNOWN: "#6b7280",
        }
        return colors.get(self, "#6b7280")


@dataclass
class ProxyItem:
    raw: str
    host: str
    port: int
    username: Optional[str] = None
    password: Optional[str] = None
    protocol: ProxyProtocol = ProxyProtocol.AUTO
    id: str = ""

    def __post_init__(self):
        if not self.id:
            auth_part = f"{self.username}:{self.password}@" if self.username else ""
            self.id = f"{self.protocol.value}://{auth_part}{self.host}:{self.port}"

    @property
    def has_auth(self) -> bool:
        return bool(self.username or self.password)

    @property
    def masked_representation(self) -> str:
        """Returns string representation with masked password for security."""
        if self.has_auth:
            user = self.username or ""
            return f"{self.host}:{self.port}:{user}:******"
        return f"{self.host}:{self.port}"

    @property
    def clean_uri(self) -> str:
        proto = self.protocol.value.lower() if self.protocol != ProxyProtocol.AUTO else "http"
        if self.has_auth:
            return f"{proto}://{self.username}:{self.password}@{self.host}:{self.port}"
        return f"{proto}://{self.host}:{self.port}"

    def to_export_string(self, include_protocol: bool = False, include_auth: bool = True) -> str:
        if include_auth and self.has_auth:
            base = f"{self.host}:{self.port}:{self.username}:{self.password or ''}"
        else:
            base = f"{self.host}:{self.port}"
        if include_protocol and self.protocol != ProxyProtocol.AUTO:
            return f"{self.protocol.value.lower()}://{base}"
        return base


@dataclass
class CheckResult:
    proxy: ProxyItem
    status: ProxyStatus = ProxyStatus.IDLE
    latency_ms: Optional[float] = None
    protocol_detected: ProxyProtocol = ProxyProtocol.AUTO
    error_message: Optional[str] = None
    country_code: Optional[str] = None
    country_name: Optional[str] = None
    city: Optional[str] = None
    org: Optional[str] = None
    checked_ip: Optional[str] = None
    status_code: Optional[int] = None
    timestamp: float = field(default_factory=time.time)

    @property
    def speed_tier(self) -> SpeedTier:
        return SpeedTier.from_latency(self.latency_ms)

    @property
    def is_alive(self) -> bool:
        return self.status == ProxyStatus.ALIVE

    @property
    def is_fast(self) -> bool:
        return self.is_alive and self.latency_ms is not None and self.latency_ms < 500

    def to_dict(self) -> Dict[str, Any]:
        return {
            "host": self.proxy.host,
            "port": self.proxy.port,
            "username": self.proxy.username,
            "has_auth": self.proxy.has_auth,
            "protocol": self.protocol_detected.value if self.protocol_detected != ProxyProtocol.AUTO else self.proxy.protocol.value,
            "status": self.status.value,
            "latency_ms": round(self.latency_ms, 2) if self.latency_ms is not None else None,
            "speed_tier": self.speed_tier.value,
            "error": self.error_message,
            "country_code": self.country_code,
            "country_name": self.country_name,
            "city": self.city,
            "org": self.org,
            "checked_ip": self.checked_ip,
            "status_code": self.status_code,
            "timestamp": self.timestamp,
            "raw": self.proxy.raw,
        }


@dataclass
class CheckerStats:
    total: int = 0
    checked: int = 0
    alive: int = 0
    dead: int = 0
    timeout: int = 0
    invalid: int = 0
    fast: int = 0         # < 500ms
    medium: int = 0       # 500 - 1500ms
    slow: int = 0         # > 1500ms
    total_latency: float = 0.0
    fastest_latency: Optional[float] = None
    fastest_proxy: Optional[str] = None
    start_time: float = 0.0
    elapsed_time: float = 0.0

    @property
    def progress_percent(self) -> float:
        if self.total <= 0:
            return 0.0
        return min(100.0, (self.checked / self.total) * 100.0)

    @property
    def avg_latency(self) -> Optional[float]:
        if self.alive <= 0:
            return None
        return round(self.total_latency / self.alive, 1)

    @property
    def speed_rate(self) -> float:
        """Proxies checked per second."""
        if self.elapsed_time <= 0:
            return 0.0
        return round(self.checked / self.elapsed_time, 1)

    def record_result(self, result: CheckResult):
        self.checked += 1
        if result.status == ProxyStatus.ALIVE:
            self.alive += 1
            if result.latency_ms is not None:
                self.total_latency += result.latency_ms
                if self.fastest_latency is None or result.latency_ms < self.fastest_latency:
                    self.fastest_latency = result.latency_ms
                    self.fastest_proxy = f"{result.proxy.host}:{result.proxy.port}"
                if result.latency_ms < 500:
                    self.fast += 1
                elif result.latency_ms <= 1500:
                    self.medium += 1
                else:
                    self.slow += 1
        elif result.status == ProxyStatus.TIMEOUT:
            self.timeout += 1
        elif result.status == ProxyStatus.INVALID:
            self.invalid += 1
        else:
            self.dead += 1


@dataclass
class FilterCriteria:
    status: Optional[str] = "ALL"          # "ALL", "ALIVE", "DEAD", "TIMEOUT", "FAST"
    protocol: Optional[str] = "ALL"        # "ALL", "HTTP", "HTTPS", "SOCKS4", "SOCKS5"
    max_latency: Optional[float] = None    # in ms
    search_query: Optional[str] = None     # IP or country or port or custom text
    country: Optional[str] = None
    port: Optional[int] = None

    def matches(self, result: CheckResult) -> bool:
        # Status Filter
        if self.status and self.status != "ALL":
            status_upper = self.status.upper()
            if status_upper == "FAST":
                if not (result.status == ProxyStatus.ALIVE and result.latency_ms is not None and result.latency_ms < 500):
                    return False
            elif status_upper != result.status.value:
                return False

        # Protocol Filter
        if self.protocol and self.protocol != "ALL":
            res_proto = result.protocol_detected.value if result.protocol_detected != ProxyProtocol.AUTO else result.proxy.protocol.value
            if self.protocol.upper() != res_proto.upper():
                return False

        # Max Latency Filter
        if self.max_latency is not None and self.max_latency > 0:
            if result.latency_ms is None or result.latency_ms > self.max_latency:
                return False

        # Port Filter
        if self.port is not None and result.proxy.port != self.port:
            return False

        # Country Filter
        if self.country:
            c_query = self.country.lower()
            code_match = (result.country_code or "").lower() == c_query
            name_match = c_query in (result.country_name or "").lower()
            if not (code_match or name_match):
                return False

        # General Search Query
        if self.search_query:
            q = self.search_query.strip().lower()
            target_str = f"{result.proxy.host}:{result.proxy.port} {result.country_code or ''} {result.country_name or ''} {result.error_message or ''}".lower()
            if q not in target_str:
                return False

        return True


@dataclass
class CheckerConfig:
    workers: int = 50
    timeout_sec: float = 5.0
    retries: int = 0
    target_url: str = "http://httpbin.org/ip"
    target_url_https: str = "https://httpbin.org/ip"
    default_protocol: ProxyProtocol = ProxyProtocol.AUTO
    enable_geoip: bool = True
    auto_detect_protocol: bool = True
    user_agent: str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    test_endpoints: List[str] = field(default_factory=lambda: [
        "http://httpbin.org/ip",
        "https://httpbin.org/ip",
        "http://ip-api.com/json",
        "https://cloudflare.com/cdn-cgi/trace",
        "https://www.google.com/generate_204",
    ])
