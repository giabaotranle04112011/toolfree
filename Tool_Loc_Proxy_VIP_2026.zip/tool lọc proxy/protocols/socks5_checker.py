"""
SOCKS5 Proxy Checker with authentication support using aiohttp-socks.
"""
import time
import asyncio
import aiohttp
from typing import Optional
from aiohttp_socks import ProxyConnector, ProxyType
from .base import BaseProxyChecker, classify_error
from ..checker.models import ProxyItem, CheckResult, ProxyStatus, ProxyProtocol
from ..utils.geoip import GeoIPService


class Socks5Checker(BaseProxyChecker):
    """Checker for SOCKS5 proxies with optional authentication."""

    async def check(
        self,
        proxy: ProxyItem,
        target_url: str,
        timeout_sec: float = 5.0,
        user_agent: Optional[str] = None
    ) -> CheckResult:
        result = CheckResult(proxy=proxy, protocol_detected=ProxyProtocol.SOCKS5)

        headers = {
            "User-Agent": user_agent or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "*/*",
            "Connection": "close"
        }

        client_timeout = aiohttp.ClientTimeout(
            total=timeout_sec,
            connect=timeout_sec * 0.7,
            sock_connect=timeout_sec * 0.7,
            sock_read=timeout_sec
        )

        start_time = time.perf_counter()

        try:
            connector = ProxyConnector(
                proxy_type=ProxyType.SOCKS5,
                host=proxy.host,
                port=proxy.port,
                username=proxy.username,
                password=proxy.password,
                ssl=False
            )

            async with aiohttp.ClientSession(timeout=client_timeout, connector=connector) as session:
                async with session.get(target_url, headers=headers) as resp:
                    elapsed = (time.perf_counter() - start_time) * 1000.0
                    status_code = resp.status
                    result.status_code = status_code
                    result.latency_ms = max(1.0, elapsed)

                    if 200 <= status_code < 400 or status_code == 404:
                        result.status = ProxyStatus.ALIVE
                        result.protocol_detected = ProxyProtocol.SOCKS5

                        try:
                            if "json" in resp.headers.get("Content-Type", "").lower() or "httpbin" in target_url or "ip-api" in target_url:
                                data = await resp.json(content_type=None)
                                parsed_geo = GeoIPService.parse_from_response(data)
                                if parsed_geo.get("country_code"):
                                    result.country_code = parsed_geo.get("country_code")
                                    result.country_name = parsed_geo.get("country_name")
                                    result.city = parsed_geo.get("city")
                                    result.org = parsed_geo.get("org")
                                    result.checked_ip = parsed_geo.get("checked_ip")
                        except Exception:
                            pass
                    else:
                        result.status = ProxyStatus.DEAD
                        result.error_message = f"SOCKS5 target HTTP status: {status_code}"

        except Exception as exc:
            status, err_msg = classify_error(exc)
            result.status = status
            result.error_message = err_msg

        return result
