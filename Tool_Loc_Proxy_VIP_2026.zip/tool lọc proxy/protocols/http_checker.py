"""
HTTP and HTTPS Proxy Checker using aiohttp.
"""
import time
import asyncio
import aiohttp
from typing import Optional
from .base import BaseProxyChecker, classify_error
from ..checker.models import ProxyItem, CheckResult, ProxyStatus, ProxyProtocol
from ..utils.geoip import GeoIPService


class HttpChecker(BaseProxyChecker):
    """Checker for HTTP and HTTPS forward proxies."""

    async def check(
        self,
        proxy: ProxyItem,
        target_url: str,
        timeout_sec: float = 5.0,
        user_agent: Optional[str] = None
    ) -> CheckResult:
        result = CheckResult(proxy=proxy, protocol_detected=ProxyProtocol.HTTP)
        
        # Build proxy URL for aiohttp
        if proxy.has_auth:
            proxy_url = f"http://{proxy.username}:{proxy.password or ''}@{proxy.host}:{proxy.port}"
        else:
            proxy_url = f"http://{proxy.host}:{proxy.port}"

        headers = {
            "User-Agent": user_agent or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "*/*",
            "Connection": "close"
        }

        client_timeout = aiohttp.ClientTimeout(
            total=timeout_sec,
            connect=timeout_sec * 0.7,
            sock_connect=timeout_sec * 0.7,
            sock_read=timeout_sec
        )

        start_time = time.perf_counter()

        try:
            connector = aiohttp.TCPConnector(ssl=False)
            async with aiohttp.ClientSession(timeout=client_timeout, connector=connector) as session:
                async with session.get(target_url, proxy=proxy_url, headers=headers) as resp:
                    elapsed = (time.perf_counter() - start_time) * 1000.0  # in ms
                    status_code = resp.status
                    result.status_code = status_code
                    result.latency_ms = max(1.0, elapsed)

                    # Successful status codes
                    if 200 <= status_code < 400 or status_code == 404:
                        result.status = ProxyStatus.ALIVE
                        result.protocol_detected = ProxyProtocol.HTTP if not target_url.startswith("https") else ProxyProtocol.HTTPS

                        # Try to extract JSON if available for IP info
                        try:
                            if "json" in resp.headers.get("Content-Type", "").lower() or "httpbin" in target_url or "ip-api" in target_url:
                                data = await resp.json(content_type=None)
                                parsed_geo = GeoIPService.parse_from_response(data)
                                if parsed_geo.get("country_code"):
                                    result.country_code = parsed_geo.get("country_code")
                                    result.country_name = parsed_geo.get("country_name")
                                    result.city = parsed_geo.get("city")
                                    result.org = parsed_geo.get("org")
                                    result.checked_ip = parsed_geo.get("checked_ip")
                        except Exception:
                            pass
                    elif status_code == 407:
                        result.status = ProxyStatus.DEAD
                        result.error_message = "Proxy Authentication Required (407)"
                    else:
                        result.status = ProxyStatus.DEAD
                        result.error_message = f"HTTP status error: {status_code}"

        except Exception as exc:
            status, err_msg = classify_error(exc)
            result.status = status
            result.error_message = err_msg

        return result
