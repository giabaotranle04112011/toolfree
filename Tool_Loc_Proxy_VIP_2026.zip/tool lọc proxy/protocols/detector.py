"""
Smart Multi-Protocol Checker and Auto-Detection engine.
"""
from typing import Optional, Dict
from .base import BaseProxyChecker
from .http_checker import HttpChecker
from .socks4_checker import Socks4Checker
from .socks5_checker import Socks5Checker
from ..checker.models import ProxyItem, CheckResult, ProxyStatus, ProxyProtocol


class SmartProxyChecker:
    """Dispatches to protocol-specific checker or auto-detects protocol."""

    def __init__(self):
        self._http_checker = HttpChecker()
        self._socks4_checker = Socks4Checker()
        self._socks5_checker = Socks5Checker()

    def get_checker(self, protocol: ProxyProtocol) -> BaseProxyChecker:
        if protocol in (ProxyProtocol.HTTP, ProxyProtocol.HTTPS):
            return self._http_checker
        elif protocol == ProxyProtocol.SOCKS4:
            return self._socks4_checker
        elif protocol == ProxyProtocol.SOCKS5:
            return self._socks5_checker
        return self._http_checker

    async def check(
        self,
        proxy: ProxyItem,
        target_url: str,
        timeout_sec: float = 5.0,
        user_agent: Optional[str] = None
    ) -> CheckResult:
        # If protocol is specified explicitly
        if proxy.protocol != ProxyProtocol.AUTO:
            checker = self.get_checker(proxy.protocol)
            return await checker.check(proxy, target_url, timeout_sec, user_agent)

        # Port-based heuristic for test order
        port = proxy.port
        if port in (1080, 1081, 9050, 9150):
            test_order = [ProxyProtocol.SOCKS5, ProxyProtocol.SOCKS4, ProxyProtocol.HTTP]
        else:
            test_order = [ProxyProtocol.HTTP, ProxyProtocol.SOCKS5, ProxyProtocol.SOCKS4]

        last_result: Optional[CheckResult] = None

        for proto in test_order:
            checker = self.get_checker(proto)
            res = await checker.check(proxy, target_url, timeout_sec, user_agent)
            if res.status == ProxyStatus.ALIVE:
                res.protocol_detected = proto
                return res
            last_result = res
            # If timeout occurred on first attempt, don't waste time trying other protocols on a dead/unreachable IP
            if res.status == ProxyStatus.TIMEOUT:
                break

        return last_result or CheckResult(proxy=proxy, status=ProxyStatus.DEAD, error_message="Unknown failure")
