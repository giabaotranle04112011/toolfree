"""
Base protocol checker interface and exception mapping.
"""
from abc import ABC, abstractmethod
import time
import asyncio
from typing import Optional, Tuple
from ..checker.models import ProxyItem, CheckResult, ProxyStatus, ProxyProtocol


def classify_error(exc: Exception) -> Tuple[ProxyStatus, str]:
    """
    Classifies a Python/asyncio network exception into ProxyStatus and friendly error message.
    """
    if isinstance(exc, (asyncio.TimeoutError, TimeoutError)):
        return ProxyStatus.TIMEOUT, "Connection timed out"
    
    exc_str = str(exc).lower()
    exc_name = exc.__class__.__name__

    if "timeout" in exc_str or "timed out" in exc_str:
        return ProxyStatus.TIMEOUT, "Connection timed out"
    
    if "connection refused" in exc_str or "winerror 10061" in exc_str or "err_connection_refused" in exc_str:
        return ProxyStatus.DEAD, "Connection refused (target port closed or refusing)"
    
    if "reset by peer" in exc_str or "winerror 10054" in exc_str:
        return ProxyStatus.DEAD, "Connection reset by peer"
    
    if "407" in exc_str or "proxy authentication" in exc_str or "auth failed" in exc_str:
        return ProxyStatus.DEAD, "Proxy authentication failed (407)"
    
    if "getaddrinfo failed" in exc_str or "name or service not known" in exc_str or "dns" in exc_str:
        return ProxyStatus.DEAD, "DNS resolution failed for proxy host"
    
    if "ssl" in exc_str or "certificate" in exc_str:
        return ProxyStatus.DEAD, f"SSL/TLS handshake error: {exc_name}"
    
    if "socks" in exc_str:
        return ProxyStatus.DEAD, f"SOCKS handshake error: {exc_str[:60]}"
    
    return ProxyStatus.DEAD, f"{exc_name}: {str(exc)[:60]}" if str(exc) else exc_name


class BaseProxyChecker(ABC):
    """Abstract base class for all protocol checkers."""

    @abstractmethod
    async def check(
        self, 
        proxy: ProxyItem, 
        target_url: str, 
        timeout_sec: float = 5.0,
        user_agent: Optional[str] = None
    ) -> CheckResult:
        """
        Executes a proxy check and returns a CheckResult.
        """
        pass
