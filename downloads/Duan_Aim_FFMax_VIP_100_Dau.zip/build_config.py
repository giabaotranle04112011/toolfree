#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AIM FFMAX Config Generator & Packager (Root) - ULTRA VITAMIN EDITION
Tu dong sinh metadata, config.ini va dong bo cau hinh.
"""

import os
import shutil

METADATA_TEMPLATE = """# =================================================================
# DỰ ÁN AIM FFMAX VIP ULTRA - FULL 100% HEADSHOT & MÁU ĐỎ TOÀN BỘ
# Phiên bản Nâng Cấp: Offset Ghim Đầu + Fix Rung + Nhẹ Tâm + Gói Vitamin Hỗ Trợ
# Package Support: com.dts.freefiremax, com.dts.freefireth
# Platform Support: iOS (17.0+), Android (10 - 15, Samsung/Xiaomi/OPPO/Realme...)
# =================================================================

# [1] GÓI VITAMIN KHÓA ĐẦU & TÂM TỪ TÍNH (AIMBOT & MAGNET VITAMIN)
AimbotTarget=Head
TargetBoneIndex=8
HeadBoneOffset_Y=1.75
AutoLockHead=1
AutoLockHeadOnFire=1
InstantHeadLockOnShoot=1
ShootStateLockHead=1
DynamicAimMagnet=1
MagnetPullForce=2.50
AimSnapSpeed=25.0
AimLockSensitivity=2.50
HeadshotAimAssist=2.50
AimPrecisionOnFire=1.00
FOVRadius=360
SilentAimHead=1
AimLock=1
AimTracking=1.00
HeadshotMultiplier=2.50
HeadshotLockPrecision=1.00
AutoAimHeadTrack=1
DynamicOffsetScaling=1

# [2] GÓI VITAMIN FIX RUNG TÂM & CHỐNG GIẬT (ANTI-SHAKE & ZERO RECOIL)
WeaponsRecoil=0.00
VerticalRecoil=0.00
HorizontalRecoil=0.00
NoRecoilValue=0.00
RecoilControl=1.00
CrosshairStability=1.00
CrosshairJitterReduction=1.00
AimSlerpDamping=18.5
KalmanFilterAim=1
ZeroRecoilOnFire=1
CameraShakeReduction=1.00
NoShakeCamera=1
GyroscopeSmoothing=1.00
AntiFlickerCrosshair=1

# [3] GÓI VITAMIN NHẸ TÂM & CẢM ỨNG SIÊU NHẠY (LIGHTWEIGHT FLICK & TOUCH BOOST)
TouchLatencyReduction=1.00
TouchSamplingRate=360Hz
TouchResponseSystem=1
SwipeAssistDPI=480
AimSensitivityMultiplier=2.50
SwipeResponseBoost=1.50
InstantFlickHead=1
SmoothInterpolation=1
FastTouchResponse=1
MicroFlickSensitivity=2.00

# [4] GÓI VITAMIN MÁU ĐỎ TOÀN BỘ (100% RED DAMAGE & HITBOX OVERRIDE)
HitBoxRedirect=Head
BodyToHeadDamage=1
LimbsToHeadDamage=1
HitRegOverride=Head
RedDamage100=1
AllHitHeadshot=1
ForceHeadDamage=1
DamageMultiplierHead=1.50
ChestToHeadRedirect=1
FootToHeadRedirect=1
CriticalHitRate=1.00

# [5] GÓI VITAMIN ĐẠN THẲNG & KHÔNG NỞ TÂM (MAGIC BULLET & NO SPREAD)
StraightBulletPath=1
BulletSpread=0.00
BulletDeviation=0.00
BulletTrajectoryFix=1
ZeroBulletDrop=1
MagicBullet=1
MagicBulletTrajectory=1
CrosshairSpread=0.00
CrosshairBloom=0
NoBloomOnFire=1
CrosshairExpansion=0.00
FixedCrosshairSize=1
AccuracyMultiplier=2.50
WeaponAccuracy=100

# [6] GÓI VITAMIN MỞ KHÓA 120 FPS & ĐỒ HỌA MƯỢT ULTRA
FrameRateLimit=120
FPS=120
MaxFPS=120
TargetFPS=120
HighFPSMode=1
UnlockFPS=1
SmoothMode=1
VSync=0
ThreadedRendering=1
GPUOptimization=1
ShaderCache=1
GraphicsQuality=Low
TextureQuality=Low
ShadowQuality=Disabled
ShadowsEnabled=false
AntiAliasingEnabled=false
BloomEnabled=false
EffectQuality=Low
ResolutionWidth=720
ResolutionHeight=1280
ResolutionScale=0.85
MotionBlur=false
DepthOfField=false
ParticleEffects=Low
PostProcessing=0

# [7] GÓI VITAMIN TỐI ƯU PING, RAM & CHỐNG DROP FPS
LagFix=1
AntiLag=1
MemoryOptimize=1
BatterySave=0
RAMCleaner=1
CPUGovernor=Performance
PingStabilizer=1
PacketOptimize=1
NetworkJitterBuffer=0
DataPacketAcceleration=1

# [8] GÓI VITAMIN ẨN DANH & BẢO VỆ TÀI KHOẢN (STEALTH & ANTI-BAN)
AntiBan=1
BypassDetection=1
AntiCheatBypass=1
HideModSignature=1
EncryptedDataFlow=1
DeviceIDMask=1
SafeMode=1
AccountProtection=1
AntiReport=1
LogCleaner=1
CheckBypass=1
SecurityTokenVerification=1
MemoryMasking=1

# [9] TỐI ƯU HÓA ĐA NỀN TẢNG (IOS 17+ & SAMSUNG/ANDROID)
OSPlatform=iOS,Android
TargetOSVersion=17.0+,Android10+
iOSOptimization=1
AndroidOptimization=1
MetalAPI=1
VulkanAPI=1
OpenGLPerformance=1
SnapdragonExynosOptimize=1
CoreAnimationOptimize=1
ProMotionSupport=1
ThermalThrottleReduction=1
"""

def generate_files():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    metadata_path = os.path.join(base_dir, "metadata")
    
    with open(metadata_path, "w", encoding="utf-8") as f:
        f.write(METADATA_TEMPLATE.strip())
        
    print("[SUCCESS] Root config file generated.")

    # Copy to aim folder
    aim_folder = os.path.join(base_dir, "aim đầu 100%")
    if os.path.exists(aim_folder):
        aim_metadata = os.path.join(aim_folder, "metadata")
        shutil.copy2(metadata_path, aim_metadata)
        print("[SUCCESS] Synced to aim folder.")

    # Dong bo sang thu muc Downloads neu ton tai
    dl_paths = [
        r"C:\Users\tranl\Downloads\my game bansung\my game bansung\metadata",
        r"C:\Users\tranl\Downloads\my game bansung\my game bansung\files\contentcache\Temp\android\MultiThread\CompulsoryRes\gameassetbundles\metadata"
    ]
    for p in dl_paths:
        try:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            shutil.copy2(metadata_path, p)
            print("[SUCCESS] Copied to download folder.")
        except Exception:
            pass

if __name__ == "__main__":
    generate_files()
