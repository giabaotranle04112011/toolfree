#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cmath>
#include <unordered_map>
#include <algorithm>

// =================================================================
// DỰ ÁN GAME C++ - HỆ THỐNG QUẢN LÝ CẤU HÌNH & XỬ LÝ GAMEPLAY VIP ULTRA
// Tích hợp: Offset Ghim Đầu + Fix Rung + Nhẹ Tâm + Gói Vitamin Hỗ Trợ
// =================================================================

struct GameSettings {
    // 1. Aim & Offset
    std::string aimbotTarget = "Head";
    float headBoneOffsetY = 1.75f;
    bool autoLockHead = true;
    bool autoLockHeadOnFire = true;
    float aimAssistPower = 2.50f;
    float fovRadius = 360.0f;
    float aimSnapSpeed = 25.0f;

    // 2. Anti-Shake & Stability
    float aimSlerpDamping = 18.5f;
    float weaponsRecoil = 0.0f;
    float verticalRecoil = 0.0f;
    float horizontalRecoil = 0.0f;

    // 3. Bullet & Spread
    bool straightBulletPath = true;
    float bulletSpread = 0.0f;
    bool noBloomOnFire = true;
    float weaponAccuracy = 100.0f;

    // 4. Damage & HitBox
    bool hitBoxRedirectHead = true;
    float headDamageMultiplier = 2.5f;

    // 5. Performance & Touch
    float aimSensitivityMultiplier = 2.5f;
    int maxFPS = 120;
    bool antiLag = true;
};

class ConfigParser {
private:
    std::unordered_map<std::string, std::string> data;

    static std::string trim(const std::string& s) {
        auto start = s.find_first_not_of(" \t\r\n");
        if (start == std::string::npos) return "";
        auto end = s.find_last_of(" \t\r\n");
        return s.substr(start, end - start + 1);
    }

public:
    bool LoadFile(const std::string& filePath) {
        std::ifstream file(filePath);
        if (!file.is_open()) {
            std::cout << "[ConfigParser] Không thể mở tệp: " << filePath << std::endl;
            return false;
        }

        std::string line;
        while (std::getline(file, line)) {
            line = trim(line);
            if (line.empty() || line[0] == '#') continue;

            size_t pos = line.find('=');
            if (pos != std::string::npos) {
                std::string key = trim(line.substr(0, pos));
                std::string val = trim(line.substr(pos + 1));
                data[key] = val;
            }
        }
        file.close();
        std::cout << "[ConfigParser] Nạp cấu hình VIP ULTRA thành công!" << std::endl;
        return true;
    }

    void ApplySettings(GameSettings& s) {
        if (data.count("AutoLockHead")) s.autoLockHead = (data["AutoLockHead"] == "1");
        if (data.count("HeadBoneOffset_Y")) s.headBoneOffsetY = std::stof(data["HeadBoneOffset_Y"]);
        if (data.count("StraightBulletPath")) s.straightBulletPath = (data["StraightBulletPath"] == "1");
        if (data.count("BulletSpread")) s.bulletSpread = std::stof(data["BulletSpread"]);
        if (data.count("WeaponsRecoil")) s.weaponsRecoil = std::stof(data["WeaponsRecoil"]);
        if (data.count("AimSlerpDamping")) s.aimSlerpDamping = std::stof(data["AimSlerpDamping"]);
        if (data.count("AimSensitivityMultiplier")) s.aimSensitivityMultiplier = std::stof(data["AimSensitivityMultiplier"]);
        if (data.count("HitBoxRedirect") && data["HitBoxRedirect"] == "Head") s.hitBoxRedirectHead = true;
        if (data.count("MaxFPS")) s.maxFPS = std::stoi(data["MaxFPS"]);
    }
};

class WeaponEngine {
public:
    static void ProcessShooting(const GameSettings& config, float baseDamage, const std::string& hitPart) {
        std::cout << "\n==============================================" << std::endl;
        std::cout << ">>> KÍCH HOẠT XẢ ĐẠN VIP ULTRA <<<" << std::endl;
        std::cout << "==============================================" << std::endl;

        std::cout << "[Aim Offset] Bù trục Y lên đầu: +" << config.headBoneOffsetY << "m" << std::endl;
        std::cout << "[Anti-Shake] Hệ số làm mịn chống rung: " << config.aimSlerpDamping << " (Tâm đằm tuyệt đối)" << std::endl;
        std::cout << "[Touch Boost] Hệ số nhẹ tâm: x" << config.aimSensitivityMultiplier << " (Vuốt cực nhẹ)" << std::endl;
        std::cout << "[WeaponEngine] Độ giật: " << config.weaponsRecoil << " (0% Giật súng)" << std::endl;
        std::cout << "[WeaponEngine] Độ tản đạn: " << config.bulletSpread << " (Đạn thẳng 100%)" << std::endl;

        float finalDamage = baseDamage;
        std::string finalHitPart = hitPart;

        if (config.hitBoxRedirectHead || hitPart == "Head") {
            finalHitPart = "Head (Máu Đỏ 100%)";
            finalDamage *= config.headDamageMultiplier;
        }

        std::cout << "[DamageEngine] Vị trí trúng đạn: " << finalHitPart << std::endl;
        std::cout << "[DamageEngine] Tổng sát thương: " << finalDamage << " HP" << std::endl;
        std::cout << "==============================================\n" << std::endl;
    }
};

int main() {
    GameSettings g_Settings;
    ConfigParser parser;

    std::string path = "metadata";
    if (parser.LoadFile(path)) {
        parser.ApplySettings(g_Settings);
    }

    WeaponEngine::ProcessShooting(g_Settings, 45.0f, "Chest");
    return 0;
}
