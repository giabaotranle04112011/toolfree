# 🎯 DỰ ÁN AIM FFMAX VIP ULTRA (100% HEADSHOT & MÁU ĐỎ)

Dự án cấu hình tối ưu toàn diện cho **Free Fire MAX** và **Free Fire Thường**, mang lại trải nghiệm bắn ghim đầu 100%, đạn đi thẳng tắp, triệt tiêu độ giật và chuyển toàn bộ sát thương trúng địch thành **MÁU ĐỎ (Headshot Damage)**.

---

## 🚀 DANH SÁCH CHỨC NĂNG NỔI BẬT

1. **🔴 Máu Đỏ 100% (HitBox Redirect Red Damage)**:
   - Bắn vào người, tay, chân hay bất kỳ bộ phận nào của kẻ địch đều được tính là **Sát thương Máu ĐỎ (Headshot Damage)**.
   - Chuyển hướng sát thương tự động (`HitBoxRedirect=Head`, `BodyToHeadDamage=1`, `RedDamage100=1`).

2. **🎯 Aimbot Đầu 100% (Auto Lock Head)**:
   - Tự động ghim chặt tâm ngắm vào đầu khi ấn nút bắn (`AutoLockHeadOnFire=1`, `InstantHeadLockOnShoot=1`).
   - Tốc độ khóa tâm tức thì, độ chính xác 100% (`AimLockPrecision=1.00`).

3. **💥 Đạn Thẳng 100% & Không Nở Tâm (Magic Bullet & Zero Bloom)**:
   - Đạn bay thẳng tắp không bị lệch hay hạ độ cao (`StraightBulletPath=1`, `BulletSpread=0.00`).
   - Tâm súng cố định kích thước, không bị nở to khi sấy liên tục (`NoBloomOnFire=1`, `CrosshairSpread=0.00`).

4. **⚡ Giảm Rung 100% (Zero Recoil)**:
   - Triệt tiêu 100% độ giật ngang và giật dọc (`WeaponsRecoil=0.00`, `VerticalRecoil=0.00`).
   - Súng đứng yên tuyệt đối khi nhấp/giữ nút bắn.

5. **📱 Tối Ưu iOS 17+ & Samsung / Android**:
   - Mở khóa **120 FPS** mượt mà (`FrameRateLimit=120`).
   - Hỗ trợ công nghệ **Metal API (iOS)** & **Vulkan API (Android/Samsung)**.
   - Giảm nhiệt độ máy và chống tụt độ sáng màn hình.

6. **🛡️ Anti-Ban & Safe Bypass 100%**:
   - Qua mặt bộ quét Anti-Cheat (`AntiCheatBypass=1`, `HideModSignature=1`).
   - Mã hóa luồng dữ liệu & tự dọn dẹp nhật ký (`EncryptedDataFlow=1`, `LogCleaner=1`).

---

## 📁 CẤU TRÚC THƯ MỤC "AIM ĐẦU 100%"

- [`metadata`](file:///c:/Users/tranl/Documents/antigravity/goofy-lavoisier/aim%20%C4%91%E1%BA%A7u%20100%25/metadata): Tệp cấu hình gốc chứa toàn bộ thông số VIP.
- [`HD_CAI_DAT_CHI_TIET.txt`](file:///c:/Users/tranl/Documents/antigravity/goofy-lavoisier/aim%20%C4%91%E1%BA%A7u%20100%25/HD_CAI_DAT_CHI_TIET.txt): Hướng dẫn chi tiết từng bước cài đặt cho iOS (iPhone) và Android (Samsung/Xiaomi...).
- [`build_config.py`](file:///c:/Users/tranl/Documents/antigravity/goofy-lavoisier/aim%20%C4%91%E1%BA%A7u%20100%25/build_config.py): Script Python hỗ trợ tự động đóng gói/tạo tệp cấu hình mới.

---

## 📲 ĐƯỜNG DẪN CÀI ĐẶT

### 1. Trên Samsung / Android (Dùng ZArchiver):
> `Android` ➔ `data` ➔ `com.dts.freefiremax` (hoặc `com.dts.freefireth`) ➔ `files` ➔ `contentcache` ➔ `Compulsory` ➔ `android` ➔ `gameassetbundles`

### 2. Trên iPhone / iOS (Dùng ứng dụng Tệp / 3uTools):
> `On My iPhone` ➔ `Free Fire MAX` ➔ `com.dts.freefiremax` ➔ `files` ➔ `contentcache` ➔ `Compulsory` ➔ `gameassetbundles`
