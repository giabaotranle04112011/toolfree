using UnityEngine;

namespace AIMFFMax.Scripts
{
    /// <summary>
    /// Hệ thống hỗ trợ ngắm VIP ULTRA:
    /// - Offset ghim đầu chuẩn xác (Head Target Offset Y = +1.75m)
    /// - Triệt tiêu rung tâm (Anti-Jitter Damping & Slerp Smoothing)
    /// - Hút tâm từ tính siêu mượt (Lightweight Touch Response)
    /// </summary>
    public class AimAssistSystem : MonoBehaviour
    {
        [Header("--- THÔNG SỐ OFFSET & KHÓA ĐẦU ---")]
        [Tooltip("Offset chiều cao đầu so với tâm mục tiêu")]
        public Vector3 headOffset = new Vector3(0, 1.75f, 0);
        public float searchRadius = 25f;
        public float fovAngle = 360f;
        public LayerMask enemyLayer;
        public Transform playerCamera;

        [Header("--- BỘ LỌC CHỐNG RUNG TÂM (ANTI-JITTER VITAMIN) ---")]
        [Tooltip("Hệ số làm mịn góc quay chống giật")]
        public float aimSmoothSpeed = 18.5f;
        [Tooltip("Độ đằm chống rung tâm khi bám đầu")]
        public float jitterDamping = 0.95f;

        [Header("--- HỖ TRỢ NHẸ TÂM & CẢM ỨNG (LIGHTWEIGHT FLICK) ---")]
        public float aimSensitivityMultiplier = 2.5f;
        public bool enableMagneticAim = true;
        public float magnetForce = 2.5f;

        [Header("--- THAM CHIẾU TÀI KHOẢN VIP ---")]
        public PlayerVIPData playerVIP;

        private Quaternion lastTargetRotation;
        private bool isTracking = false;

        private void Start()
        {
            if (playerCamera == null && Camera.main != null)
            {
                playerCamera = Camera.main.transform;
            }
            if (playerCamera != null)
            {
                lastTargetRotation = playerCamera.rotation;
            }
        }

        private void Update()
        {
            // Kiểm tra trạng thái VIP
            if (playerVIP == null || !playerVIP.isVIPUser) return;

            // Kích hoạt khi bấm nút bắn (Fire1) hoặc bật ngắm (Fire2)
            if (Input.GetButton("Fire1") || Input.GetButton("Fire2"))
            {
                ApplyAdvancedAimAssist();
            }
            else
            {
                isTracking = false;
            }
        }

        private void ApplyAdvancedAimAssist()
        {
            Collider[] enemies = Physics.OverlapSphere(transform.position, searchRadius, enemyLayer);
            Transform closestEnemy = null;
            float minDistance = float.MaxValue;

            foreach (var enemy in enemies)
            {
                // Tìm xương đầu hoặc vị trí gốc + Offset
                Transform headBone = enemy.transform.Find("Head") ?? enemy.transform.Find("Bip01_Head") ?? enemy.transform;
                float dist = Vector3.Distance(transform.position, headBone.position);

                if (dist < minDistance)
                {
                    minDistance = dist;
                    closestEnemy = headBone;
                }
            }

            if (closestEnemy != null && playerCamera != null)
            {
                // Tọa độ mục tiêu tính toán theo Offset ghim đầu
                Vector3 targetHeadPos = closestEnemy.position;
                if (closestEnemy.name != "Head" && closestEnemy.name != "Bip01_Head")
                {
                    targetHeadPos += headOffset;
                }

                // Tính toán hướng ngắm chuẩn xác
                Vector3 direction = (targetHeadPos - playerCamera.position).normalized;
                if (direction != Vector3.zero)
                {
                    Quaternion desiredRotation = Quaternion.LookRotation(direction);

                    // Bộ lọc làm mịn Slerp chống rung giật (Anti-Jitter Filter)
                    float currentSmooth = aimSmoothSpeed * aimSensitivityMultiplier;
                    Quaternion smoothedRotation = Quaternion.Slerp(
                        playerCamera.rotation,
                        desiredRotation,
                        Time.deltaTime * currentSmooth * jitterDamping
                    );

                    // Cố định góc quay không bị rung lắc
                    playerCamera.rotation = smoothedRotation;
                    lastTargetRotation = smoothedRotation;
                    isTracking = true;
                }
            }
        }
    }
}
