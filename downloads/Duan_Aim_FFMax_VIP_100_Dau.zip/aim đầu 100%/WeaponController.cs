using UnityEngine;

namespace AIMFFMax.Scripts
{
    /// <summary>
    /// Điều khiển vũ khí VIP ULTRA:
    /// - Triệt tiêu độ giật 100% (Zero Recoil)
    /// - Đạn đi thẳng tắp (Straight Magic Bullet Path)
    /// - Không nở tâm khi sấy liên tục (No Bloom On Fire)
    /// </summary>
    public class WeaponController : MonoBehaviour
    {
        [Header("--- THÔNG SỐ VŨ KHÍ GỐC ---")]
        public float baseRecoil = 5.0f;
        public float baseSpread = 2.5f;
        public float fireRate = 0.08f;
        public Transform firePoint;

        [Header("--- THAM CHIẾU TÀI KHOẢN VIP ---")]
        public PlayerVIPData playerVIP;

        [Header("--- HIỆU ỨNG TIA ĐẠN (MAGIC BULLET VITAMIN) ---")]
        public bool enableMagicBullet = true;
        public float bulletVelocity = 350f;

        private float nextFireTime = 0f;

        /// <summary>
        /// Độ giật vũ khí thực tế sau khi áp dụng Vitamin VIP
        /// </summary>
        public float GetCurrentRecoil()
        {
            if (playerVIP != null && playerVIP.isVIPUser)
            {
                // VIP: 0% Giật súng (Zero Recoil)
                return 0f;
            }
            return baseRecoil;
        }

        /// <summary>
        /// Độ tản đạn/nở tâm sau khi áp dụng Vitamin VIP
        /// </summary>
        public float GetCurrentSpread()
        {
            if (playerVIP != null && playerVIP.isVIPUser)
            {
                // VIP: 0% Tản đạn, tâm luôn cố định kích thước nhỏ nhất
                return 0f;
            }
            return baseSpread;
        }

        /// <summary>
        /// Kích hoạt xả đạn
        /// </summary>
        public void FireWeapon()
        {
            if (Time.time < nextFireTime) return;
            nextFireTime = Time.time + fireRate;

            float currentRecoil = GetCurrentRecoil();
            float currentSpread = GetCurrentSpread();

            // Hướng bắn thẳng tắp theo nòng súng
            Vector3 shootDirection = firePoint != null ? firePoint.forward : transform.forward;

            if (currentSpread > 0f)
            {
                shootDirection.x += Random.Range(-currentSpread, currentSpread) * 0.01f;
                shootDirection.y += Random.Range(-currentSpread, currentSpread) * 0.01f;
            }

            Debug.Log($"[VIP Weapon Engine] Xả đạn - Recoil: {currentRecoil} | Spread: {currentSpread} | Đạn thẳng 100%");
        }
    }
}
