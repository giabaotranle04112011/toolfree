using UnityEngine;

namespace AIMFFMax.Scripts
{
    /// <summary>
    /// Quản lý thông tin và cấp độ VIP của người chơi.
    /// Dữ liệu được đồng bộ từ Server khi người chơi đăng nhập.
    /// </summary>
    public class PlayerVIPData : MonoBehaviour
    {
        [Header("VIP Settings")]
        [Tooltip("Kích hoạt tài khoản VIP")]
        public bool isVIPUser = true;

        [Tooltip("Cấp độ VIP (1: Giảm giật 50%, 2: Không giật 0% + Auto Aim)")]
        public int vipLevel = 2;

        [Tooltip("Tên gói dịch vụ VIP")]
        public string vipPackageName = "VIP Ultra Pass";

        /// <summary>
        /// Đồng bộ trạng thái VIP từ Server
        /// </summary>
        public void InitializeVIPStatus(bool isVIP, int level, string packageName)
        {
            this.isVIPUser = isVIP;
            this.vipLevel = level;
            this.vipPackageName = packageName;
            Debug.Log($"[VIP System] Khởi tạo tài khoản: {packageName} | Active: {isVIP} | Level: {level}");
        }
    }
}
