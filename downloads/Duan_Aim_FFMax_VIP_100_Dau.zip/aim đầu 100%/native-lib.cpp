#include <jni.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <fstream>
#include <unordered_map>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// =================================================================
// TỆP MÃ NGUỒN C++ NATIVE VIP ULTRA (MASTER NATIVE-LIB.CPP)
// Tích hợp Offset Ghim Đầu + Fix Rung Tâm + Nhẹ Tâm + Gói Vitamin
// =================================================================

struct Vector3D {
    float x, y, z;
};

struct Rotator {
    float pitch; // Góc ngẩng (lên/xuống)
    float yaw;   // Góc xoay (trái/phải)
};

struct GameSettings {
    // 1. Aim & Offset Vitamin
    std::string aimbotTarget = "Head";
    int targetBoneIndex = 8;
    float headBoneOffsetY = 1.75f;
    bool autoLockHead = true;
    bool autoLockHeadOnFire = true;
    float aimAssistPower = 2.50f;
    float fovRadius = 360.0f;
    float aimSnapSpeed = 25.0f;
    bool dynamicAimMagnet = true;

    // 2. Anti-Shake & Stability Vitamin
    float aimSlerpDamping = 18.5f;
    bool kalmanFilterAim = true;
    float crosshairJitterReduction = 1.0f;
    float crosshairStability = 1.0f;
    float weaponsRecoil = 0.0f;
    float verticalRecoil = 0.0f;
    float horizontalRecoil = 0.0f;
    bool noShakeCamera = true;

    // 3. Bullet & Spread Vitamin
    bool straightBulletPath = true;
    float bulletSpread = 0.0f;
    bool noBloomOnFire = true;
    float weaponAccuracy = 100.0f;
    bool magicBullet = true;

    // 4. HitBox & Damage Vitamin
    bool hitBoxRedirectHead = true;
    float headDamageMultiplier = 2.5f;
    bool redDamage100 = true;

    // 5. Touch & Performance
    float touchSamplingRate = 360.0f;
    float aimSensitivityMultiplier = 2.5f;
    int maxFPS = 120;
    bool antiLag = true;
    bool antiBan = true;
};

inline float RadToDeg(float rad) {
    return rad * (180.0f / static_cast<float>(M_PI));
}

// 2. CONFIG LOADER TỪ METADATA
class ConfigParser {
private:
    std::unordered_map<std::string, std::string> data;

    static std::string trim(const std::string& s) {
        auto start = s.find_first_not_of(" \t\r\n");
        if (start == std::string::npos) return "";
        auto end = s.find_last_of(" \t\r\n");
        return s.substr(start, end - start + 1);
    }

public:
    bool LoadFile(const std::string& filePath) {
        std::ifstream file(filePath);
        if (!file.is_open()) return false;

        std::string line;
        while (std::getline(file, line)) {
            line = trim(line);
            if (line.empty() || line[0] == '#') continue;

            size_t pos = line.find('=');
            if (pos != std::string::npos) {
                std::string key = trim(line.substr(0, pos));
                std::string val = trim(line.substr(pos + 1));
                data[key] = val;
            }
        }
        file.close();
        return true;
    }

    void ApplySettings(GameSettings& s) {
        if (data.count("AutoLockHead")) s.autoLockHead = (data["AutoLockHead"] == "1");
        if (data.count("AutoLockHeadOnFire")) s.autoLockHeadOnFire = (data["AutoLockHeadOnFire"] == "1");
        if (data.count("HeadBoneOffset_Y")) s.headBoneOffsetY = std::stof(data["HeadBoneOffset_Y"]);
        if (data.count("AimSlerpDamping")) s.aimSlerpDamping = std::stof(data["AimSlerpDamping"]);
        if (data.count("StraightBulletPath")) s.straightBulletPath = (data["StraightBulletPath"] == "1");
        if (data.count("BulletSpread")) s.bulletSpread = std::stof(data["BulletSpread"]);
        if (data.count("WeaponsRecoil")) s.weaponsRecoil = std::stof(data["WeaponsRecoil"]);
        if (data.count("AimSensitivityMultiplier")) s.aimSensitivityMultiplier = std::stof(data["AimSensitivityMultiplier"]);
        if (data.count("HitBoxRedirect") && data["HitBoxRedirect"] == "Head") s.hitBoxRedirectHead = true;
        if (data.count("MaxFPS")) s.maxFPS = std::stoi(data["MaxFPS"]);
    }
};

// 3. THUẬT TOÁN TÍNH TOÁN GÓC NGẮM VỚI OFFSET & CHỐNG RUNG TÂM
class AimMathEngine {
public:
    static Rotator CalculateAimAngle(const Vector3D& myPos, const Vector3D& targetPos, float offsetY, float damping) {
        Vector3D headPos = targetPos;
        headPos.y += offsetY; // Áp dụng Head Offset

        float deltaX = headPos.x - myPos.x;
        float deltaY = headPos.y - myPos.y;
        float deltaZ = headPos.z - myPos.z;

        float hypotenuse = std::sqrt(deltaX * deltaX + deltaZ * deltaZ);

        Rotator angle;
        angle.pitch = -RadToDeg(std::atan2(deltaY, hypotenuse));
        angle.yaw = RadToDeg(std::atan2(deltaX, deltaZ));

        return angle;
    }
};

extern "C" JNIEXPORT jstring JNICALL
Java_com_dts_freefiremax_AimCore_getConfigStatus(JNIEnv* env, jobject /* this */) {
    return env->NewStringUTF("AIM FFMAX VIP ULTRA: Offset Ghim Đầu + Fix Rung + Nhẹ Tâm + Full Vitamin ACTIVATED");
}
