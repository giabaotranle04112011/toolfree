using UnityEngine;

namespace AIMFFMax.Scripts
{
    /// <summary>
    /// Hệ thống tính toán sát thương & chuyển đổi sát thương Máu Đỏ (Headshot Damage) cho tài khoản VIP.
    /// </summary>
    public class DamageCalculator : MonoBehaviour
    {
        /// <summary>
        /// Tính toán sát thương thực tế
        /// </summary>
        public static float CalculateDamage(string hitBodyPart, float baseDamage, bool isVIPUser)
        {
            float finalDamage = baseDamage;

            if (hitBodyPart == "Head")
            {
                // Bắn trúng đầu -> Nhân 2.5x sát thương Máu Đỏ
                finalDamage *= 2.5f;
            }
            else if (isVIPUser)
            {
                // Quyền lợi VIP: Bắn vào tay, chân, ngực đều chuyển thành Sát thương Máu Đỏ (Headshot)
                finalDamage *= 2.5f;
                Debug.Log($"[Damage System] VIP Trigger: Chuyển đổi trúng {hitBodyPart} -> Sát thương Máu Đỏ ({finalDamage} HP)");
            }

            return finalDamage;
        }
    }
}
