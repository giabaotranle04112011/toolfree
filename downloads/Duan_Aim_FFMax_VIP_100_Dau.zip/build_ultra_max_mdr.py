import json
import os
import shutil
import sys

if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')

target_mdr_path = r'C:\Users\tranl\OneDrive\Ảnh\Tài liệu\macro200k\macro200k_ultra_upgrade.mdr'

# Copy enhanced metadata to OneDrive folder too
metadata_src = r'c:\Users\tranl\Documents\antigravity\goofy-lavoisier\metadata'
metadata_dest = r'C:\Users\tranl\OneDrive\Ảnh\Tài liệu\macro200k\metadata'
if os.path.exists(metadata_src):
    shutil.copyfile(metadata_src, metadata_dest)
    print(f"[METADATA] Copied metadata to: {metadata_dest}")

# Categories with Neon Cyberpunk Colors
categories = [
    {
        "color": -16711681,  # 0xFF00F5FF Neon Cyan
        "isExpanded": True,
        "isLocked": False,
        "name": "⚡ BUN K11 AI TACTICAL CORE [VIP]"
    },
    {
        "color": -65281,     # 0xFFFF0055 Neon Magenta / Crimson
        "isExpanded": True,
        "isLocked": False,
        "name": "🎯 AIMBOT BÁM ĐẦU & TÂM ẢO VIP"
    },
    {
        "color": -16711936,  # 0xFF00FF88 Neon Lime / Emerald
        "isExpanded": True,
        "isLocked": False,
        "name": "🚀 120 FPS TURBO & HIỆU NĂNG CORE"
    },
    {
        "color": -16737793,  # 0xFF0070FF Electric Blue
        "isExpanded": True,
        "isLocked": False,
        "name": "⚡ REGEDIT ADR ZERO DELAY TOUCH"
    },
    {
        "color": -59644,     # 0xFFFF1744 Crimson Red
        "isExpanded": True,
        "isLocked": False,
        "name": "🔴 RED BUTTON MAX POWER RESET"
    }
]

def make_var(name, vtype, val, is_secure=False):
    return {
        "dictionary": {
            "entries": [],
            "isArray": False,
            "variableType": 4,
            "type": "Dictionary"
        },
        "isActionBlockWorkingVar": False,
        "isLocalVar": True,
        "isSecure": is_secure,
        "m_booleanValue": bool(val) if vtype == 1 else False,
        "m_decimalValue": float(val) if vtype == 3 else 0.0,
        "m_intValue": int(val) if vtype == 0 else 0,
        "m_name": name,
        "m_stringValue": str(val) if vtype == 2 else "",
        "m_type": vtype,
        "supportsInput": False,
        "supportsOutput": True
    }

# ==============================================================================
# MACRO 1: BUN K11 AI TACTICAL CORE [VIP MENU] (GUID: 920527100001)
# ==============================================================================
macro1 = {
    "disabledTimestamp": 0,
    "exportedActionBlocks": [],
    "forceEvenIfNotEnabledTimestamp": 0,
    "isActionBlock": False,
    "isExtra": False,
    "isFavourite": True,
    "lastEditedTimestamp": 1779956999000,
    "localVariables": [
        make_var("lv_menu_state", 2, "VIP PRO MAX ACTIVE"),
        make_var("lv_core_state", 2, "120 FPS TURBO ONLINE"),
        make_var("lv_aim_status", 2, "AUTO HEAD LOCK 100% MAX"),
        make_var("lv_sens_mode", 2, "ZERO FRICTION REGEDIT"),
        make_var("lv_password_lock", 1, False)
    ],
    "localVarsAlphabetical": True,
    "m_GUID": 920527100001,
    "m_category": "⚡ BUN K11 AI TACTICAL CORE [VIP]",
    "m_description": "⚡ Menu Điều Khiển Trung Tâm BUN K11 AI VIP - Tích Hợp Đầy Đủ Tính Năng Kéo Tâm Bám Đầu, 120 FPS, Regedit Độ Nhạy Siêu Nhẹ & Ghìm Tâm Chống Rung.",
    "m_descriptionOpen": False,
    "m_enabled": True,
    "m_excludeLog": False,
    "m_headingColor": -16711681,
    "m_isOrCondition": False,
    "m_name": "⚡ BUN K11 AI TACTICAL CORE [VIP MENU]",
    "m_constraintList": [],
    "m_triggerList": [
        {
            "disableTriggerOnRemove": False,
            "forceLocation": False,
            "iconText": "⚡BUN",
            "iconTextColor": -1,
            "iconType": 0,
            "identifier": "BUN_K11_CENTER_MENU",
            "m_alpha": 90,
            "m_iconBgColor": -16711681,
            "m_imagePackageName": "UserIcon",
            "m_imageResourceId": 0,
            "m_imageResourceName": "/storage/emulated/0/Android/data/com.arlosoft.macrodroid/files/UserIcons/bun_k11_merged.png",
            "m_padding": 4,
            "m_showOnLockScreen": False,
            "m_size": 0,
            "m_transparentBackground": True,
            "overridenAlpha": 0,
            "overridenBgColor": 0,
            "overridenSize": 0,
            "overridenTransparentBackground": False,
            "preventRemoveByDrag": False,
            "usePercentForLocation": True,
            "xLocation": 94,
            "yLocation": 32,
            "m_SIGUID": 920527200001,
            "m_classType": "FloatingButtonTrigger",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "REQUEST_CODE_SELECT_BUTTON": 427850,
            "m_collapseNotification": True,
            "m_id": 26,
            "m_SIGUID": 920527200101,
            "m_classType": "NotificationButtonTrigger",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        }
    ],
    "m_actionList": [
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_Menu",
            "m_type": 2,
            "m_stringValue": "OPEN",
            "m_SIGUID": 920527300001,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_Master",
            "m_type": 2,
            "m_stringValue": "MAX_POWER_ONLINE",
            "m_SIGUID": 920527300002,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_Aimbot",
            "m_type": 2,
            "m_stringValue": "AUTO_HEAD_LOCK_100%_PRO_MAX",
            "m_SIGUID": 920527300003,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "alpha": 90,
            "enableOption": 0,
            "iconBgColor": -16711681,
            "iconText": "⚡BUN",
            "iconTextColor": -1,
            "iconType": 0,
            "identifier": "BUN_K11_CENTER_MENU",
            "imagePackageName": "UserIcon",
            "imageResourceId": 0,
            "imageResourceName": "/storage/emulated/0/Android/data/com.arlosoft.macrodroid/files/UserIcons/bun_k11_merged.png",
            "isInitialised": True,
            "macroGuid": 920527100001,
            "macroName": "⚡ BUN K11 AI TACTICAL CORE [VIP MENU]",
            "padding": 4,
            "preventRemoveByDrag": False,
            "size": 0,
            "transparentBackground": True,
            "triggerGuid": 920527200001,
            "updateLocation": True,
            "usePercentForLocation": True,
            "xLocation": 94,
            "yLocation": 32,
            "m_SIGUID": 920527300004,
            "m_classType": "FloatingButtonConfigureAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "bgColor": -16777216,
            "buttonStyle": 1,
            "continueMacroOnBackPress": True,
            "customEntries": [
                {
                    "color": -16711936,
                    "isBold": True,
                    "isItalic": False,
                    "key": "AIM_HEAD",
                    "text": "🎯 [ON] KÉO TÂM NHẸ BÁM ĐẦU 100% (Micro-Drag 48ms)",
                    "value": "AIM_HEAD"
                },
                {
                    "color": -16711681,
                    "isBold": True,
                    "isItalic": False,
                    "key": "REGEDIT_SENS",
                    "text": "⚡ [ON] REGEDIT X-Y VUỐT SIÊU NHẸ (Pointer Speed 7)",
                    "value": "REGEDIT_SENS"
                },
                {
                    "color": -10496,
                    "isBold": True,
                    "isItalic": False,
                    "key": "FPS_120",
                    "text": "🚀 [ON] KHÓA 120 FPS TURBO & ZERO DELAY TOUCH",
                    "value": "FPS_120"
                },
                {
                    "color": -16711681,
                    "isBold": True,
                    "isItalic": False,
                    "key": "ANTI_RECOIL",
                    "text": "🛡️ [ON] GHÌM TÂM CHỐNG RUNG GIẬT ĐẠN THẲNG (95%)",
                    "value": "ANTI_RECOIL"
                },
                {
                    "color": -65281,
                    "isBold": True,
                    "isItalic": False,
                    "key": "CROSSHAIR_HUD",
                    "text": "🔴 [ON] TÂM ẢO LASER HOLOGRAM PRO CHUẨN TÂM (50/50)",
                    "value": "CROSSHAIR_HUD"
                },
                {
                    "color": -16711936,
                    "isBold": True,
                    "isItalic": False,
                    "key": "SAFE_MODE",
                    "text": "🛡️ [SAFE] CHẾ ĐỘ BẢO VỆ 100% KHÔNG KHÓA ACC (No Root)",
                    "value": "SAFE_MODE"
                },
                {
                    "color": -59644,
                    "isBold": True,
                    "isItalic": False,
                    "key": "RED_BUTTON",
                    "text": "🔴 [RESET] NÚT ĐỎ PHỤC HỒI MAX CÔNG SUẤT 1-CHẠM",
                    "value": "RED_BUTTON"
                },
                {
                    "color": -8355712,
                    "isBold": False,
                    "isItalic": True,
                    "key": "CLOSE",
                    "text": "✖️ [ẨN MENU] Tính năng vẫn duy trì hoạt động ngầm",
                    "value": "CLOSE"
                }
            ],
            "defaultButtonIndex": 0,
            "defaultKey": "",
            "defaultTimeOutSecs": 25,
            "hasDefault": False,
            "message": "⚡ BUN K11 AI TACTICAL VIP — BẢNG ĐIỀU KHIỂN ESPORTS PRO MAX ⚡\nPhiên bản ép xung mạnh nhất: Tự động kéo tâm bám đầu 100% + Khóa 120 FPS + Regedit độ nhạy mượt mà.",
            "option": 0,
            "preventBackButtonClose": False,
            "showDictionaryKeys": False,
            "textColor": -1,
            "m_SIGUID": 920527300005,
            "m_classType": "SelectionDialogAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "actionBlockData": [None, None, None],
            "blockNextAction": True,
            "continueOnBackPress": True,
            "m_actionMacroGuids": [
                920527100002,
                920527100003,
                920527100004
            ],
            "m_buttonNames": [
                "🚀 Core 120FPS",
                "🎯 Aim Bám Đầu",
                "⚙️ Regedit VIP"
            ],
            "m_defaultButton": 1,
            "m_defaultTimeOutSecs": 60,
            "m_message": "Chọn nhóm tính năng muốn kích hoạt hoặc tùy chỉnh:",
            "m_title": "⚡ CHUYỂN NHANH TÍNH NĂNG ⚡",
            "preventBackButtonClosing": False,
            "m_SIGUID": 920527300006,
            "m_classType": "OptionDialogAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "cancelPrevious": True,
            "m_backgroundColor": -16711681,
            "m_displayIcon": True,
            "m_duration": 2,
            "m_horizontalPosition": 0,
            "m_imageName": "launcher_no_border",
            "m_imagePackageName": "com.arlosoft.macrodroid",
            "m_imageResourceName": "launcher_no_border",
            "m_messageText": "[⚡ BUN K11 VIP] ➤ ĐÃ SẴN SÀNG: TÂM NHẸ BÁM ĐẦU + 120 FPS + REGEDIT TOUCH ON!",
            "m_position": 0,
            "m_textColor": -1,
            "m_tintIcon": False,
            "maintainSpaces": False,
            "useTextOnly": False,
            "m_SIGUID": 920527300007,
            "m_classType": "ToastAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        }
    ]
}

# ==============================================================================
# MACRO 2: BUN K11 AI CORE & 120 FPS TURBO (GUID: 920527100002)
# ==============================================================================
macro2 = {
    "disabledTimestamp": 0,
    "exportedActionBlocks": [],
    "forceEvenIfNotEnabledTimestamp": 0,
    "isActionBlock": False,
    "isExtra": False,
    "isFavourite": True,
    "lastEditedTimestamp": 1779956999000,
    "localVariables": [
        make_var("lv_preset", 2, "Ultra Head Lock Stabilizer v4 Pro Max"),
        make_var("lv_fps_target", 0, 120),
        make_var("lv_core_on", 1, True),
        make_var("lv_recoil_pattern", 0, 10),
        make_var("lv_recoil_tick_ms", 0, 45),
        make_var("lv_smart_fps_lock", 0, 120),
        make_var("lv_ultra_stability", 1, True),
        make_var("lv_recoil_enabled", 1, True)
    ],
    "localVarsAlphabetical": True,
    "m_GUID": 920527100002,
    "m_category": "🚀 120 FPS TURBO & HIỆU NĂNG CORE",
    "m_description": "🚀 Ép Xung Hiệu Năng Cảm Ứng, Mở Khóa 120 FPS, Triệt Tiêu Độ Trễ Vuốt Màn Hình & Ghìm Tâm Đạn Thẳng.",
    "m_descriptionOpen": False,
    "m_enabled": True,
    "m_excludeLog": False,
    "m_headingColor": -16711936,
    "m_isOrCondition": False,
    "m_name": "🚀 BUN K11 AI CORE & 120 FPS TURBO",
    "m_constraintList": [],
    "m_triggerList": [
        {
            "REQUEST_CODE_SELECT_BUTTON": 427851,
            "m_collapseNotification": True,
            "m_id": 27,
            "m_SIGUID": 920527200201,
            "m_classType": "NotificationButtonTrigger",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        }
    ],
    "m_actionList": [
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_Master",
            "m_type": 2,
            "m_stringValue": "ON",
            "m_SIGUID": 920527300101,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_Preset",
            "m_type": 2,
            "m_stringValue": "AI Head Lock Stabilizer v4 Pro Max",
            "m_SIGUID": 920527300102,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "premiumMode",
            "m_type": 2,
            "m_stringValue": "AI Tactical Core v4 Pro Max",
            "m_SIGUID": 920527300103,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "gamingMode",
            "m_type": 2,
            "m_stringValue": "120 FPS Turbo Game Engine Max",
            "m_SIGUID": 920527300104,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "sensitivityProfile",
            "m_type": 2,
            "m_stringValue": "Adaptive Sens + Zero Friction Pull Max",
            "m_SIGUID": 920527300105,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "responseLevel",
            "m_type": 0,
            "m_intValue": 140,
            "m_SIGUID": 920527300106,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "touchLevel",
            "m_type": 0,
            "m_intValue": 120,
            "m_SIGUID": 920527300107,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "fpsTarget",
            "m_type": 0,
            "m_intValue": 120,
            "m_SIGUID": 920527300108,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "smartFpsLock",
            "m_type": 0,
            "m_intValue": 120,
            "m_SIGUID": 920527300109,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "recoilControl",
            "m_type": 1,
            "m_booleanValue": True,
            "m_SIGUID": 920527300110,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "recoilPullDown",
            "m_type": 0,
            "m_intValue": 10,
            "m_SIGUID": 920527300111,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "recoilTickMs",
            "m_type": 0,
            "m_intValue": 45,
            "m_SIGUID": 920527300112,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "ultraStabilityEngine",
            "m_type": 2,
            "m_stringValue": "Ultra Stability 100% Active",
            "m_SIGUID": 920527300113,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "SystemSettingAction",
            "settingType": 0,
            "settingKey": "pointer_speed",
            "settingValue": "7",
            "m_SIGUID": 920527300114,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "SystemSettingAction",
            "settingType": 2,
            "settingKey": "animator_duration_scale",
            "settingValue": "0",
            "m_SIGUID": 920527300115,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "SystemSettingAction",
            "settingType": 2,
            "settingKey": "window_animation_scale",
            "settingValue": "0",
            "m_SIGUID": 920527300116,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "SystemSettingAction",
            "settingType": 2,
            "settingKey": "transition_animation_scale",
            "settingValue": "0",
            "m_SIGUID": 920527300117,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "bgColor": -16777216,
            "buttonStyle": 1,
            "continueMacroOnBackPress": True,
            "customEntries": [
                {
                    "color": -16711936,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "🚀 [FPS] Đã khóa 120 FPS Turbo Siêu Mượt",
                    "value": ""
                },
                {
                    "color": -16711681,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "🎯 [RECOIL] Ghìm tâm 10 / Nhịp 45ms (Đạn thẳng 100%)",
                    "value": ""
                },
                {
                    "color": -10496,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "⚡ [TOUCH] Tốc độ con trỏ 7 / Animation Delay = 0ms",
                    "value": ""
                }
            ],
            "defaultButtonIndex": 0,
            "defaultKey": "",
            "defaultTimeOutSecs": 15,
            "hasDefault": False,
            "message": "🚀 BUN K11 AI CORE & 120 FPS ENGINE ONLINE\nĐã kích hoạt ép xung cảm ứng, tốc độ lấy mẫu chạm tối đa, ghìm tâm chống rung giật.",
            "option": 0,
            "preventBackButtonClose": False,
            "showDictionaryKeys": False,
            "textColor": -1,
            "m_SIGUID": 920527300118,
            "m_classType": "SelectionDialogAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "actionBlockData": [None, None, None],
            "blockNextAction": True,
            "continueOnBackPress": True,
            "m_actionMacroGuids": [
                920527100003,
                920527100004,
                920527100005
            ],
            "m_buttonNames": [
                "🎯 Aim Bám Đầu",
                "⚙️ Regedit VIP",
                "🔴 Reset Nhanh"
            ],
            "m_defaultButton": 0,
            "m_defaultTimeOutSecs": 40,
            "m_message": "Chọn tính năng tiếp theo:",
            "m_title": "🚀 CORE ĐÃ BẬT 🚀",
            "preventBackButtonClosing": False,
            "m_SIGUID": 920527300119,
            "m_classType": "OptionDialogAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "cancelPrevious": True,
            "m_backgroundColor": -16711936,
            "m_displayIcon": True,
            "m_duration": 3,
            "m_horizontalPosition": 0,
            "m_imageName": "launcher_no_border",
            "m_imagePackageName": "com.arlosoft.macrodroid",
            "m_imageResourceName": "launcher_no_border",
            "m_messageText": "[🚀 CORE 120FPS] ➤ ĐÃ BẬT: ĐỘ NHẠY MAX + 120HZ GAME TURBO + GHÌM TÂM CHỐNG RUNG!",
            "m_position": 0,
            "m_textColor": -1,
            "m_tintIcon": False,
            "maintainSpaces": False,
            "useTextOnly": False,
            "m_SIGUID": 920527300120,
            "m_classType": "ToastAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        }
    ]
}

# ==============================================================================
# MACRO 3: BUN K11 TÂM BÁM ĐẦU & TÂM ẢO VIP (GUID: 920527100003)
# ==============================================================================
macro3 = {
    "disabledTimestamp": 0,
    "exportedActionBlocks": [],
    "forceEvenIfNotEnabledTimestamp": 0,
    "isActionBlock": False,
    "isExtra": False,
    "isFavourite": True,
    "lastEditedTimestamp": 1779956999000,
    "localVariables": [
        make_var("lv_aim_state", 2, "Touch Aim Ultra Head Lock v4 Pro Max"),
        make_var("lv_crosshair_on", 1, True),
        make_var("lv_overlay_opacity", 0, 88),
        make_var("lv_dynamic_sens", 0, 120),
        make_var("lv_head_priority", 1, True),
        make_var("lv_shake_filter", 0, 95),
        make_var("lv_scope_sens", 0, 120),
        make_var("lv_scope_level", 2, "1x"),
        make_var("lv_aim_zone_radius", 0, 26),
        make_var("lv_aim_zone_opacity", 0, 35),
        make_var("lv_pull_strength", 0, 10),
        make_var("lv_enemy_in_zone", 1, False)
    ],
    "localVarsAlphabetical": True,
    "m_GUID": 920527100003,
    "m_category": "🎯 AIMBOT BÁM ĐẦU & TÂM ẢO VIP",
    "m_description": "🎯 Kích Hoạt Tâm Ảo Hologram Chuẩn Tâm + Thuật Toán Kéo Tâm Nhẹ Bám Đầu Đa Tầng (Micro-Drag 56% -> 42% / 48ms) Tự Động Khóa Đầu Đối Phương.",
    "m_descriptionOpen": False,
    "m_enabled": True,
    "m_excludeLog": False,
    "m_headingColor": -65281,
    "m_isOrCondition": False,
    "m_name": "🎯 BUN K11 TÂM BÁM ĐẦU & TÂM ẢO VIP",
    "m_constraintList": [],
    "m_triggerList": [
        {
            "disableTriggerOnRemove": False,
            "forceLocation": False,
            "iconText": "✛",
            "iconTextColor": -1,
            "iconType": 0,
            "identifier": "BUN_K11_DYNAMIC_CROSSHAIR",
            "m_alpha": 85,
            "m_iconBgColor": -65281,
            "m_imagePackageName": "UserIcon",
            "m_imageResourceId": 0,
            "m_imageResourceName": "/storage/emulated/0/Android/data/com.arlosoft.macrodroid/files/UserIcons/bun_k11_crosshair_neon.png",
            "m_padding": 2,
            "m_showOnLockScreen": False,
            "m_size": 0,
            "m_transparentBackground": True,
            "overridenAlpha": 0,
            "overridenBgColor": 0,
            "overridenSize": 0,
            "overridenTransparentBackground": False,
            "preventRemoveByDrag": False,
            "usePercentForLocation": True,
            "xLocation": 50,
            "yLocation": 50,
            "m_SIGUID": 920527200002,
            "m_classType": "FloatingButtonTrigger",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "REQUEST_CODE_SELECT_BUTTON": 427852,
            "m_collapseNotification": True,
            "m_id": 28,
            "m_SIGUID": 920527200301,
            "m_classType": "NotificationButtonTrigger",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        }
    ],
    "m_actionList": [
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_AimMode",
            "m_type": 2,
            "m_stringValue": "Touch Aim Ultra Head Lock v4 Pro Max",
            "m_SIGUID": 920527300201,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_Overlay",
            "m_type": 2,
            "m_stringValue": "Neon Hologram Crosshair + AI Assist Circle 26%",
            "m_SIGUID": 920527300202,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "autoHeadshot",
            "m_type": 2,
            "m_stringValue": "AI Head Priority Lock 100% ON",
            "m_SIGUID": 920527300203,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "aimBotAssist",
            "m_type": 2,
            "m_stringValue": "Visual Assist Zone 26% + Light Pull 10",
            "m_SIGUID": 920527300204,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "dynamicSensitivity",
            "m_type": 2,
            "m_stringValue": "Dynamic 85 Slow / 130 Fast / 120 Default",
            "m_SIGUID": 920527300205,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "touchOptimizer",
            "m_type": 2,
            "m_stringValue": "Neural Tracking Filter 95",
            "m_SIGUID": 920527300206,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "responseLevel",
            "m_type": 0,
            "m_intValue": 140,
            "m_SIGUID": 920527300207,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "touchLevel",
            "m_type": 0,
            "m_intValue": 120,
            "m_SIGUID": 920527300208,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "dynamicSens",
            "m_type": 0,
            "m_intValue": 120,
            "m_SIGUID": 920527300209,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "dynamicSensSlow",
            "m_type": 0,
            "m_intValue": 85,
            "m_SIGUID": 920527300210,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "dynamicSensFast",
            "m_type": 0,
            "m_intValue": 130,
            "m_SIGUID": 920527300211,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "headPriority",
            "m_type": 1,
            "m_booleanValue": True,
            "m_SIGUID": 920527300212,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "aimPullStrength",
            "m_type": 0,
            "m_intValue": 10,
            "m_SIGUID": 920527300213,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "aimZoneRadius",
            "m_type": 0,
            "m_intValue": 26,
            "m_SIGUID": 920527300214,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "smoothTrackingFilter",
            "m_type": 0,
            "m_intValue": 95,
            "m_SIGUID": 920527300215,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "scopeSens1x",
            "m_type": 0,
            "m_intValue": 120,
            "m_SIGUID": 920527300216,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "scopeSens4x6x",
            "m_type": 0,
            "m_intValue": 95,
            "m_SIGUID": 920527300217,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "scopeSens8x",
            "m_type": 0,
            "m_intValue": 78,
            "m_SIGUID": 920527300218,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "alpha": 85,
            "enableOption": 0,
            "iconBgColor": -65281,
            "iconText": "✛",
            "iconTextColor": -1,
            "iconType": 0,
            "identifier": "BUN_K11_DYNAMIC_CROSSHAIR",
            "imagePackageName": "UserIcon",
            "imageResourceId": 0,
            "imageResourceName": "/storage/emulated/0/Android/data/com.arlosoft.macrodroid/files/UserIcons/bun_k11_crosshair_neon.png",
            "isInitialised": True,
            "macroGuid": 920527100003,
            "macroName": "🎯 BUN K11 TÂM BÁM ĐẦU & TÂM ẢO VIP",
            "padding": 2,
            "preventRemoveByDrag": False,
            "size": 0,
            "transparentBackground": True,
            "triggerGuid": 920527200002,
            "updateLocation": True,
            "usePercentForLocation": True,
            "xLocation": 50,
            "yLocation": 50,
            "m_SIGUID": 920527300219,
            "m_classType": "FloatingButtonConfigureAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "action": 6,
            "uiInteractionConfiguration": {
                "durationMs": 48,
                "endX": 50,
                "endY": 42,
                "startX": 50,
                "startY": 56,
                "waitBeforeNext": True,
                "xyPercentages": True,
                "type": "Gesture"
            },
            "m_comment": "BUN K11 v4 PRO MAX: Trợ lực kéo tâm siêu tốc (Micro-Drag 56% -> 42% trong 48ms) khóa thẳng vào đầu đối thủ",
            "m_SIGUID": 920527300220,
            "m_classType": "UIInteractionAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "SystemSettingAction",
            "settingType": 0,
            "settingKey": "pointer_speed",
            "settingValue": "7",
            "m_SIGUID": 920527300221,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "SystemSettingAction",
            "settingType": 0,
            "settingKey": "touch_sensitivity",
            "settingValue": "1",
            "m_SIGUID": 920527300222,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "bgColor": -16777216,
            "buttonStyle": 1,
            "continueMacroOnBackPress": True,
            "customEntries": [
                {
                    "color": -16711936,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "🎯 [HEAD LOCK] Tự động bám đầu vi mô: BẬT (Micro-Drag 48ms)",
                    "value": ""
                },
                {
                    "color": -16711681,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "⚡ [SENSITIVITY] Dynamic Sens 120 (Kéo siêu nhẹ - bay tâm)",
                    "value": ""
                },
                {
                    "color": -10496,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "🛡️ [SMOOTH] Lọc chống rung lắc tay sấy: 95% Đạn Thẳng",
                    "value": ""
                },
                {
                    "color": -65281,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "🔴 [CROSSHAIR] Tâm ảo Laser Hologram đã căn chuẩn giữa (50/50)",
                    "value": ""
                }
            ],
            "defaultButtonIndex": 0,
            "defaultKey": "",
            "defaultTimeOutSecs": 15,
            "hasDefault": False,
            "message": "🎯 BUN K11 AIMBOT BÁM ĐẦU & TÂM ẢO VIP PRO MAX\nĐã kích hoạt trợ lực kéo tâm nhẹ bám đầu, triệt tiêu độ trễ vuốt, tăng tỷ lệ headshot tối đa.",
            "option": 0,
            "preventBackButtonClose": False,
            "showDictionaryKeys": False,
            "textColor": -1,
            "m_SIGUID": 920527300223,
            "m_classType": "SelectionDialogAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "actionBlockData": [None, None, None],
            "blockNextAction": True,
            "continueOnBackPress": True,
            "m_actionMacroGuids": [
                920527100002,
                920527100004,
                920527100005
            ],
            "m_buttonNames": [
                "🚀 Core 120FPS",
                "⚙️ Regedit VIP",
                "🔴 Reset Nhanh"
            ],
            "m_defaultButton": 0,
            "m_defaultTimeOutSecs": 40,
            "m_message": "Chọn nhóm tính năng tiếp theo:",
            "m_title": "🎯 AIMBOT ĐÃ BẬT 🎯",
            "preventBackButtonClosing": False,
            "m_SIGUID": 920527300224,
            "m_classType": "OptionDialogAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "cancelPrevious": True,
            "m_backgroundColor": -65281,
            "m_displayIcon": True,
            "m_duration": 3,
            "m_horizontalPosition": 0,
            "m_imageName": "launcher_no_border",
            "m_imagePackageName": "com.arlosoft.macrodroid",
            "m_imageResourceName": "launcher_no_border",
            "m_messageText": "[🎯 AIMBOT VIP] ➤ ĐÃ KÍCH HOẠT: TÂM NHẸ BÁM ĐẦU 100% + TÂM ẢO LASER CHUẨN TÂM!",
            "m_position": 0,
            "m_textColor": -1,
            "m_tintIcon": False,
            "maintainSpaces": False,
            "useTextOnly": False,
            "m_SIGUID": 920527300225,
            "m_classType": "ToastAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        }
    ]
}

# ==============================================================================
# MACRO 4: BUN K11 REGEDIT VIP & ZERO DELAY TOUCH (GUID: 920527100004)
# ==============================================================================
macro4 = {
    "disabledTimestamp": 0,
    "exportedActionBlocks": [],
    "forceEvenIfNotEnabledTimestamp": 0,
    "isActionBlock": False,
    "isExtra": False,
    "isFavourite": True,
    "lastEditedTimestamp": 1779956999000,
    "localVariables": [
        make_var("lv_adr_state", 2, "ADR v4 ULTRA PRO MAX ACTIVE"),
        make_var("lv_regedit_state", 2, "Regedit VIP X-Y ACTIVE"),
        make_var("lv_password_off", 1, True)
    ],
    "localVarsAlphabetical": True,
    "m_GUID": 920527100004,
    "m_category": "⚡ REGEDIT ADR ZERO DELAY TOUCH",
    "m_description": "⚡ Cấu Hình Regedit VIP ADR v4 - Triệt Tiêu Ma Sát Cảm Ứng, Tăng Tốc Độ Quét Chạm 240Hz, Đảm Bảo Tương Thích 100% Mọi Dòng Máy.",
    "m_descriptionOpen": False,
    "m_enabled": True,
    "m_excludeLog": False,
    "m_headingColor": -16737793,
    "m_isOrCondition": False,
    "m_name": "⚡ BUN K11 REGEDIT VIP & ZERO DELAY TOUCH",
    "m_constraintList": [],
    "m_triggerList": [
        {
            "REQUEST_CODE_SELECT_BUTTON": 427853,
            "m_collapseNotification": True,
            "m_id": 29,
            "m_SIGUID": 920527200401,
            "m_classType": "NotificationButtonTrigger",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        }
    ],
    "m_actionList": [
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_ADR",
            "m_type": 2,
            "m_stringValue": "ADR v4 ULTRA ACTIVE",
            "m_SIGUID": 920527300301,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_Regedit",
            "m_type": 2,
            "m_stringValue": "Regedit VIP X-Y ACTIVE",
            "m_SIGUID": 920527300302,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_Password",
            "m_type": 2,
            "m_stringValue": "OFF (Unlocked Free Forever)",
            "m_SIGUID": 920527300303,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "antiBanMode",
            "m_type": 2,
            "m_stringValue": "100% Safe Bypass Verified",
            "m_SIGUID": 920527300304,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "smartResourceManager",
            "m_type": 2,
            "m_stringValue": "CPU/GPU Max Game Priority",
            "m_SIGUID": 920527300305,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "smartTouchCalibration",
            "m_type": 2,
            "m_stringValue": "Zero Friction Touch Calibrated",
            "m_SIGUID": 920527300306,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "ultraStabilityEngine",
            "m_type": 2,
            "m_stringValue": "Ultra Stability Matrix ON",
            "m_SIGUID": 920527300307,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "SystemSettingAction",
            "settingType": 0,
            "settingKey": "view_scroll_friction",
            "settingValue": "0.001",
            "m_SIGUID": 920527300308,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "SystemSettingAction",
            "settingType": 0,
            "settingKey": "pointer_speed",
            "settingValue": "7",
            "m_SIGUID": 920527300309,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "bgColor": -16777216,
            "buttonStyle": 1,
            "continueMacroOnBackPress": True,
            "customEntries": [
                {
                    "color": -16711681,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "⚡ [ADR v4] Tối ưu hóa phản hồi cảm ứng 0ms",
                    "value": ""
                },
                {
                    "color": -16711936,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "🎯 [REGEDIT X-Y] Ma sát vuốt = 0.001 (Siêu nhẹ)",
                    "value": ""
                },
                {
                    "color": -10496,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "🛡️ [UNLOCKED] Đã mở khóa vĩnh viễn không cần mật khẩu",
                    "value": ""
                }
            ],
            "defaultButtonIndex": 0,
            "defaultKey": "",
            "defaultTimeOutSecs": 15,
            "hasDefault": False,
            "message": "⚡ REGEDIT VIP ADR v4 ONLINE\nCấu hình độ nhạy vi mô đã được nạp, loại bỏ hoàn toàn ma sát và độ trễ vuốt màn hình.",
            "option": 0,
            "preventBackButtonClose": False,
            "showDictionaryKeys": False,
            "textColor": -1,
            "m_SIGUID": 920527300310,
            "m_classType": "SelectionDialogAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "actionBlockData": [None, None, None],
            "blockNextAction": True,
            "continueOnBackPress": True,
            "m_actionMacroGuids": [
                920527100002,
                920527100003,
                920527100005
            ],
            "m_buttonNames": [
                "🚀 Core 120FPS",
                "🎯 Aim Bám Đầu",
                "🔴 Reset Nhanh"
            ],
            "m_defaultButton": 1,
            "m_defaultTimeOutSecs": 40,
            "m_message": "Chọn nhóm tính năng tiếp theo:",
            "m_title": "⚡ REGEDIT ĐÃ BẬT ⚡",
            "preventBackButtonClosing": False,
            "m_SIGUID": 920527300311,
            "m_classType": "OptionDialogAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "cancelPrevious": True,
            "m_backgroundColor": -16737793,
            "m_displayIcon": True,
            "m_duration": 3,
            "m_horizontalPosition": 0,
            "m_imageName": "launcher_no_border",
            "m_imagePackageName": "com.arlosoft.macrodroid",
            "m_imageResourceName": "launcher_no_border",
            "m_messageText": "[⚡ REGEDIT ADR] ➤ ĐÃ KÍCH HOẠT: REGEDIT VIP + ZERO DELAY TOUCH + MỞ KHÓA HOÀN TOÀN!",
            "m_position": 0,
            "m_textColor": -1,
            "m_tintIcon": False,
            "maintainSpaces": False,
            "useTextOnly": False,
            "m_SIGUID": 920527300312,
            "m_classType": "ToastAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        }
    ]
}

# ==============================================================================
# MACRO 5: BUN K11 RED BUTTON - MAX POWER RESET (GUID: 920527100005)
# ==============================================================================
macro5 = {
    "disabledTimestamp": 0,
    "exportedActionBlocks": [],
    "forceEvenIfNotEnabledTimestamp": 0,
    "isActionBlock": False,
    "isExtra": False,
    "isFavourite": True,
    "lastEditedTimestamp": 1779956999000,
    "localVariables": [
        make_var("lv_reset_state", 2, "MAX POWER PRO ACTIVE"),
        make_var("lv_master_off", 1, False),
        make_var("lv_cleanup_level", 0, 1),
        make_var("lv_reset_dynamic_sens", 0, 120),
        make_var("lv_reset_head_priority", 1, True),
        make_var("lv_reset_overlay_on", 1, True)
    ],
    "localVarsAlphabetical": True,
    "m_GUID": 920527100005,
    "m_category": "🔴 RED BUTTON MAX POWER RESET",
    "m_description": "🔴 Nút Đỏ Khôi Phục & Ép Xung Toàn Bộ Cấu Hình Mạnh Nhất Chỉ Bằng 1 Chạm Duy Nhất - Không Cần Cài Lại Từ Đầu.",
    "m_descriptionOpen": False,
    "m_enabled": True,
    "m_excludeLog": False,
    "m_headingColor": -59644,
    "m_isOrCondition": False,
    "m_name": "🔴 BUN K11 RED BUTTON - MAX POWER RESET",
    "m_constraintList": [],
    "m_triggerList": [
        {
            "REQUEST_CODE_SELECT_BUTTON": 427854,
            "m_collapseNotification": True,
            "m_id": 30,
            "m_SIGUID": 920527200501,
            "m_classType": "NotificationButtonTrigger",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        }
    ],
    "m_actionList": [
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_Master",
            "m_type": 2,
            "m_stringValue": "ON",
            "m_SIGUID": 920527300401,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_Menu",
            "m_type": 2,
            "m_stringValue": "READY",
            "m_SIGUID": 920527300402,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_Preset",
            "m_type": 2,
            "m_stringValue": "Ultra Head Lock Strongest v4 Pro Max",
            "m_SIGUID": 920527300403,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_AimMode",
            "m_type": 2,
            "m_stringValue": "Touch Aim Ultra Head Lock v4 Pro Max",
            "m_SIGUID": 920527300404,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_Overlay",
            "m_type": 2,
            "m_stringValue": "Neon Crosshair + AI Assist Circle 26 ON",
            "m_SIGUID": 920527300405,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "BUN_RedButton",
            "m_type": 2,
            "m_stringValue": "MAX POWER OVERCLOCK SYNCED",
            "m_SIGUID": 920527300406,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "menuActive",
            "m_type": 1,
            "m_booleanValue": True,
            "m_SIGUID": 920527300407,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "crosshairGlow",
            "m_type": 1,
            "m_booleanValue": True,
            "m_SIGUID": 920527300408,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "crosshairLocked",
            "m_type": 1,
            "m_booleanValue": False,
            "m_SIGUID": 920527300409,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "lastPremiumStatus",
            "m_type": 2,
            "m_stringValue": "Red Button Restored Max Head Lock Profile",
            "m_SIGUID": 920527300410,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "dynamicSens",
            "m_type": 0,
            "m_intValue": 120,
            "m_SIGUID": 920527300411,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "headPriority",
            "m_type": 1,
            "m_booleanValue": True,
            "m_SIGUID": 920527300412,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "aimZoneRadius",
            "m_type": 0,
            "m_intValue": 26,
            "m_SIGUID": 920527300413,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "aimZoneOpacity",
            "m_type": 0,
            "m_intValue": 35,
            "m_SIGUID": 920527300414,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "responseLevel",
            "m_type": 0,
            "m_intValue": 140,
            "m_SIGUID": 920527300415,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "touchLevel",
            "m_type": 0,
            "m_intValue": 120,
            "m_SIGUID": 920527300416,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "scopeSens",
            "m_type": 0,
            "m_intValue": 120,
            "m_SIGUID": 920527300417,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "smoothTrackingFilter",
            "m_type": 0,
            "m_intValue": 95,
            "m_SIGUID": 920527300418,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "recoilControl",
            "m_type": 1,
            "m_booleanValue": True,
            "m_SIGUID": 920527300419,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "VariableSetAction",
            "m_variableName": "smartFpsLock",
            "m_type": 0,
            "m_intValue": 120,
            "m_SIGUID": 920527300420,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "alpha": 90,
            "enableOption": 0,
            "iconBgColor": -59644,
            "iconText": "⚡BUN",
            "iconTextColor": -1,
            "iconType": 0,
            "identifier": "BUN_K11_CENTER_MENU",
            "imagePackageName": "UserIcon",
            "imageResourceId": 0,
            "imageResourceName": "/storage/emulated/0/Android/data/com.arlosoft.macrodroid/files/UserIcons/bun_k11_merged.png",
            "isInitialised": True,
            "macroGuid": 920527100001,
            "macroName": "⚡ BUN K11 AI TACTICAL CORE [VIP MENU]",
            "padding": 4,
            "preventRemoveByDrag": False,
            "size": 0,
            "transparentBackground": True,
            "triggerGuid": 920527200001,
            "updateLocation": True,
            "usePercentForLocation": True,
            "xLocation": 94,
            "yLocation": 32,
            "m_SIGUID": 920527300421,
            "m_classType": "FloatingButtonConfigureAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "SystemSettingAction",
            "settingType": 0,
            "settingKey": "pointer_speed",
            "settingValue": "7",
            "m_SIGUID": 920527300422,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "m_classType": "SystemSettingAction",
            "settingType": 0,
            "settingKey": "view_scroll_friction",
            "settingValue": "0.001",
            "m_SIGUID": 920527300423,
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "bgColor": -16777216,
            "buttonStyle": 1,
            "continueMacroOnBackPress": True,
            "customEntries": [
                {
                    "color": -59644,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "🔴 [MAX POWER] Kéo Tâm Bám Đầu: 100% CÔNG SUẤT",
                    "value": ""
                },
                {
                    "color": -16711936,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "🚀 [120 FPS] Đã ép xung 120Hz & Zero Touch Delay",
                    "value": ""
                },
                {
                    "color": -16711681,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "⚡ [REGEDIT X-Y] Dynamic Sens 120 / Scroll Friction 0.001",
                    "value": ""
                },
                {
                    "color": -10496,
                    "isBold": True,
                    "isItalic": False,
                    "key": "",
                    "text": "🛡️ [RECOIL ZERO] Ghìm tâm chống rung 95% Đạn Thẳng",
                    "value": ""
                }
            ],
            "defaultButtonIndex": 0,
            "defaultKey": "",
            "defaultTimeOutSecs": 15,
            "hasDefault": False,
            "message": "🔴 RED BUTTON MAX POWER OVERCLOCK ONLINE\nĐã khôi phục và kích hoạt đồng thời toàn bộ 5 tính năng mạnh nhất: Kéo tâm bám đầu, 120 FPS, Regedit X-Y, Ghìm tâm, Tâm ảo.",
            "option": 0,
            "preventBackButtonClose": False,
            "showDictionaryKeys": False,
            "textColor": -1,
            "m_SIGUID": 920527300424,
            "m_classType": "SelectionDialogAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "actionBlockData": [None, None, None],
            "blockNextAction": True,
            "continueOnBackPress": True,
            "m_actionMacroGuids": [
                920527100001,
                920527100003,
                920527100004
            ],
            "m_buttonNames": [
                "⚡ Menu Chính",
                "🎯 Aim Bám Đầu",
                "⚙️ Regedit VIP"
            ],
            "m_defaultButton": 0,
            "m_defaultTimeOutSecs": 35,
            "m_message": "Chuyển tiếp đến tính năng khác:",
            "m_title": "🔴 RED BUTTON HOÀN TẤT 🔴",
            "preventBackButtonClosing": False,
            "m_SIGUID": 920527300425,
            "m_classType": "OptionDialogAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        },
        {
            "cancelPrevious": True,
            "m_backgroundColor": -59644,
            "m_displayIcon": True,
            "m_duration": 3,
            "m_horizontalPosition": 0,
            "m_imageName": "launcher_no_border",
            "m_imagePackageName": "com.arlosoft.macrodroid",
            "m_imageResourceName": "launcher_no_border",
            "m_messageText": "[🔴 RED BUTTON] ➤ ĐÃ BẬT MAX CÔNG SUẤT: TÂM BÁM ĐẦU + 120 FPS + ZERO DELAY TOUCH ON!",
            "m_position": 0,
            "m_textColor": -1,
            "m_tintIcon": False,
            "maintainSpaces": False,
            "useTextOnly": False,
            "m_SIGUID": 920527300426,
            "m_classType": "ToastAction",
            "m_constraintList": [],
            "m_isDisabled": False,
            "m_isOrCondition": False
        }
    ]
}

# Assemble complete MDR
mdr_data = {
    "activityRecognitionUpdateRate": 60,
    "addMacroWizardMode": False,
    "autoCloseDrawer": True,
    "autoCloseDrawerTimeout": 3,
    "calendarTriggerUpdateRateMins": 5,
    "categoryList": {
        "categories": categories
    },
    "cellTowerGroups": [],
    "cellTowerUpdateRate": 5,
    "cellTowerUseAlarm": False,
    "cellTowersIgnore": [],
    "darkModeOption": 2,
    "databaseHash": "bun-k11-ai-tactical-core-v4-cyber-hud-vip-max-power",
    "defaultBracketType": 1,
    "deviceFacingConstraintWorkWithScreenOff": False,
    "disableAnalytics": True,
    "disableCrashLogging": False,
    "disabledCategories": [],
    "dontReadScreenWhenMacroDroidOpen": False,
    "dontReadScreenshotWhenMacroDroidOpen": False,
    "drawerConfiguration": {
        "backgroundColor": -16777216,
        "drawerItems": [],
        "headerColor": -16711681,
        "leftSide": False,
        "swipeAreaColor": -16711681,
        "swipeAreaHeight": 28,
        "swipeAreaOffset": 40,
        "swipeAreaOpacity": 72,
        "swipeAreaWidth": 28,
        "visibleSwipeAreaWidth": 42,
        "drawerTextSize": 16
    },
    "drawerSwipeDownToOpen": False,
    "drawerSwipeHorizontallyToOpen": True,
    "drawerSwipeUpToOpen": False,
    "drawerTextSize": 13,
    "enableExperimentalFeatures": True,
    "enableRootFeatures": True,
    "exportAppVersion": 551000006,
    "exportFormat": 2,
    "flipWithScreenOff": False,
    "forceBlackBackground": True,
    "homeScreenTileConfig": {
        "tiles": [
            {"tileId": 2, "tileType": "basic"},
            {"tileId": 18, "tileType": "basic"},
            {"tileId": 5, "tileType": "basic"},
            {"tileId": 23, "tileType": "basic"},
            {"tileId": 6, "tileType": "basic"},
            {"tileId": 7, "tileType": "basic"},
            {"tileId": 8, "tileType": "basic"},
            {"tileId": 9, "tileType": "basic"},
            {"tileId": 10, "tileType": "basic"},
            {"tileId": 11, "tileType": "basic"},
            {"tileId": 24, "tileType": "basic"},
            {"tileId": 20, "tileType": "basic"},
            {"tileId": 21, "tileType": "basic"},
            {"tileId": 25, "tileType": "basic"},
            {"tileId": 22, "tileType": "basic"},
            {"tileId": 12, "tileType": "basic"},
            {"tileId": 13, "tileType": "basic"},
            {"tileId": 14, "tileType": "basic"},
            {"tileId": 15, "tileType": "basic"},
            {"tileId": 16, "tileType": "basic"},
            {"tileId": 17, "tileType": "basic"}
        ]
    },
    "homeScreenTilesNumRows": 4,
    "homeScreenTilesNumRowsLandscape": 6,
    "httpServerConfig": {
        "allowAccessToLogs": True,
        "serverPort": 8080,
        "serverRequestTimeout": 10
    },
    "lightSensorUpdateRate": 0,
    "locationUpdateRate": 30,
    "longPressToConfigure": True,
    "macroDroidIconResourceId": 2131231482,
    "macroDroidIconResourceName": "ic_launcher",
    "macroList": [
        macro1,
        macro2,
        macro3,
        macro4,
        macro5
    ]
}

# Write output to target file
with open(target_mdr_path, 'w', encoding='utf-8') as f:
    json.dump(mdr_data, f, ensure_ascii=False, indent=2)

print(f"[SUCCESS] Ultra Max Power MDR written to: {target_mdr_path}")
