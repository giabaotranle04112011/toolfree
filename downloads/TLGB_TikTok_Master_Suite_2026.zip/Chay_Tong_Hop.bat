@echo off
chcp 65001 >nul
title TLGB ALL-IN-ONE MULTI-TOOL MASTER HUB 2026
set PYTHONIOENCODING=utf-8

where py >nul 2>nul
if %errorlevel% equ 0 (
    set PY_EXE=py -3.12
) else (
    set PY_EXE=python
)

%PY_EXE% tonghop_tool.py
pause
