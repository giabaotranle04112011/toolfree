# -*- coding: utf-8 -*-
"""
====================================================================
           TLGB TOOL - TĂNG VIEW TIKTOK ĐA NĂNG (DUAL ENGINE)
               BẢN QUYỀN THUỘC VỀ: TRẦN LÊ GIA BẢO
====================================================================
- Tên Tool: TLGB TOOL
- Tác giả & Bản quyền: TRẦN LÊ GIA BẢO
- Chế độ 1: ⚡ Multi-Threading Direct API (Cách cũ - Siêu nhanh, không cần mở Chrome)
- Chế độ 2: 🌐 Zefoy Real Engine (Cách mới - Tự động hóa qua trình duyệt)
- Hiệu ứng Giao diện: Rainbow Gradient (Cầu Vồng Siêu Đẹp 24-bit TrueColor)
- Hệ thống Bản quyền: Xác thực Key Online qua GitHub & Admin Key ẩn
====================================================================
"""

import sys
import os
import time
import re
import json
import secrets
import random
import hashlib
import datetime
import asyncio
import aiohttp
import webbrowser
import colorsys
from typing import Optional, Tuple, Dict, List
from dataclasses import dataclass

# Thiết lập UTF-8 output cho Windows Console
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass
    os.system('')  # Kích hoạt hỗ trợ màu 24-bit TrueColor ANSI trên Windows CMD/Terminal

# Import thư viện bổ trợ
try:
    import pyperclip
    HAS_CLIPBOARD = True
except ImportError:
    HAS_CLIPBOARD = False

import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By


# ==================== CẤU HÌNH HỆ THỐNG KEY ====================
GET_KEY_URL = "https://getkeyfree24h.netlify.app/"
GITHUB_KEYS_URL = "https://raw.githubusercontent.com/giabaotranle04112011/getkey/main/keys.json"
ADMIN_KEY_HASH = "0e61c051b0e0c396221b8b7305884a9d3bd05cdf5487c8badba2ef6007978da9"
KEY_CACHE_FILE = os.path.join(os.path.expanduser("~"), ".tlgb_tool_license.json")


# ==================== MÀU SẮC & HIỆU ỨNG CẦU VỒNG ====================
class Color:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    
    PINK = "\033[38;2;255;105;180m"
    GOLD = "\033[38;2;255;215;0m"
    SKY = "\033[38;2;0;191;255m"
    LIME = "\033[38;2;50;205;50m"
    GRAY = "\033[38;2;128;128;128m"


def rainbow_text(text: str, horizontal_speed: float = 0.85, vertical_speed: float = 0.25) -> str:
    """Tạo hiệu ứng chuyển màu cầu vồng (Rainbow Gradient 24-bit TrueColor)."""
    lines = text.strip('\n').split('\n')
    result = []
    max_len = max(len(l) for l in lines) if lines else 1
    total_lines = len(lines) if lines else 1
    
    for i, line in enumerate(lines):
        row = []
        for j, ch in enumerate(line):
            if ch == ' ':
                row.append(' ')
                continue
            hue = (j / max_len * horizontal_speed + i / total_lines * vertical_speed) % 1.0
            r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.95, 1.0)]
            row.append(f"\033[38;2;{r};{g};{b}m{ch}")
        result.append("".join(row) + Color.RESET)
    return "\n".join(result)


def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")


def print_banner():
    clear_screen()
    banner_ascii = """
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃   ████████╗██╗      ██████╗ ██████╗     ████████╗ ██████╗  ██████╗ ██╗      ┃
┃   ╚══██╔══╝██║     ██╔════╝ ██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║      ┃
┃      ██║   ██║     ██║  ███╗██████╔╝       ██║   ██║   ██║██║   ██║██║      ┃
┃      ██║   ██║     ██║   ██║██╔══██╗       ██║   ██║   ██║██║   ██║██║      ┃
┃      ██║   ███████╗╚██████╔╝██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗ ┃
┃      ╚═╝   ╚══════╝ ╚═════╝ ╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝ ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
"""
    print(rainbow_text(banner_ascii, horizontal_speed=0.9, vertical_speed=0.3))
    
    title_line = "   👑 TÊN TOOL: TLGB TOOL (TIKTOK AUTO VIEW DUAL ENGINE)"
    author_line = "   ⭐️ BẢN QUYỀN THUỘC VỀ: TRẦN LÊ GIA BẢO"
    divider_line = "   ─────────────────────────────────────────────────────────────────────────"
    
    print(rainbow_text(title_line, horizontal_speed=0.7, vertical_speed=0.0))
    print(rainbow_text(author_line, horizontal_speed=0.7, vertical_speed=0.0))
    print(rainbow_text(divider_line, horizontal_speed=1.0, vertical_speed=0.0))
    print()


# ==================== MODULE QUẢN LÝ KEY ====================
class KeyManager:
    @staticmethod
    def load_cached_key() -> Optional[str]:
        try:
            if os.path.exists(KEY_CACHE_FILE):
                with open(KEY_CACHE_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return data.get("license_key")
        except Exception:
            pass
        return None

    @staticmethod
    def save_cached_key(key: str):
        try:
            with open(KEY_CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump({"license_key": key, "saved_at": int(time.time())}, f)
        except Exception:
            pass

    @staticmethod
    def verify_key(key_input: str) -> Tuple[bool, str]:
        key_input = key_input.strip()
        if not key_input:
            return False, "Key không được để trống!"

        # 1. Kiểm tra Admin Key (ẩn bằng mã băm SHA-256)
        input_hash = hashlib.sha256(key_input.encode('utf-8')).hexdigest()
        if input_hash == ADMIN_KEY_HASH:
            return True, f"{Color.GOLD}⭐ QUYỀN ADMIN - TRẦN LÊ GIA BẢO (Vĩnh Viễn){Color.RESET}"

        # 2. Kiểm tra danh sách Key Online từ GitHub
        try:
            headers = {"User-Agent": "TLGB-Tool/3.5"}
            res = requests.get(GITHUB_KEYS_URL, headers=headers, timeout=8)
            if res.status_code == 200:
                keys_db: Dict[str, int] = res.json()
                
                if key_input in keys_db:
                    expire_ts = keys_db[key_input]
                    now_ts = int(time.time())
                    expire_str = datetime.datetime.fromtimestamp(expire_ts).strftime("%d/%m/%Y %H:%M:%S")
                    
                    if now_ts < expire_ts:
                        remaining_seconds = expire_ts - now_ts
                        hours, rem = divmod(remaining_seconds, 3600)
                        minutes, _ = divmod(rem, 60)
                        time_left_str = f"{hours}h {minutes}p" if hours > 0 else f"{minutes} phút"
                        return True, f"Hợp lệ (Còn {time_left_str} - Hạn: {expire_str})"
                    else:
                        return False, f"Key đã hết hạn sử dụng vào lúc: {expire_str}"
                else:
                    return False, "Key không tồn tại trên hệ thống hoặc đã bị thu hồi!"
            else:
                return False, f"Không thể kết nối máy chủ kiểm tra Key (Mã lỗi: {res.status_code})"
        except requests.exceptions.RequestException:
            return False, "Lỗi kết nối Internet! Không thể xác thực Key với máy chủ."
        except Exception as e:
            return False, f"Lỗi xác thực: {e}"

    @classmethod
    def require_license(cls) -> bool:
        cached_key = cls.load_cached_key()
        if cached_key:
            is_valid, msg = cls.verify_key(cached_key)
            if is_valid:
                print_banner()
                print(f"{Color.GREEN}✅ ĐÃ XÁC THỰC BẢN QUYỀN TLGB TOOL TỰ ĐỘNG!{Color.RESET}")
                print(f" 🔑 {Color.BOLD}Key đang dùng:{Color.RESET} {Color.WHITE}{cached_key[:4]}****{cached_key[-4:] if len(cached_key)>8 else '****'}{Color.RESET}")
                print(f" 📋 {Color.BOLD}Trạng thái   :{Color.RESET} {Color.GREEN}{msg}{Color.RESET}")
                print(rainbow_text("─────────────────────────────────────────────────────────────────────────", horizontal_speed=1.0, vertical_speed=0.0) + "\n")
                time.sleep(1.5)
                return True

        while True:
            print_banner()
            print(f"{Color.BOLD}{Color.GOLD}╔══════════════════════════════════════════════════════════════════════╗{Color.RESET}")
            print(f"{Color.BOLD}{Color.GOLD}║           🔐 TLGB TOOL - HỆ THỐNG XÁC THỰC BẢN QUYỀN KEY             ║{Color.RESET}")
            print(f"{Color.BOLD}{Color.GOLD}╚══════════════════════════════════════════════════════════════════════╝{Color.RESET}")
            print(f"  {Color.WHITE}• Bản quyền thuộc về: {Color.BOLD}{Color.GOLD}TRẦN LÊ GIA BẢO{Color.RESET}")
            print(f"  {Color.WHITE}• Lấy Key miễn phí 24h tại trang web:{Color.RESET}")
            print(f"    👉 {Color.BOLD}{Color.SKY}{GET_KEY_URL}{Color.RESET}\n")
            print(f"{Color.GRAY}  ──────────────────────────────────────────────────────────────────{Color.RESET}")
            print(f"  {Color.GREEN}[1]{Color.RESET} Nhập Key kích hoạt")
            print(f"  {Color.CYAN}[2]{Color.RESET} Tự động mở trình duyệt để Lấy Key miễn phí 24h")
            print(f"  {Color.RED}[0]{Color.RESET} Thoát chương trình")
            print(f"{Color.GRAY}  ──────────────────────────────────────────────────────────────────{Color.RESET}")

            choice = input(f"  👉 {Color.BOLD}Lựa chọn của bạn [1/2/0]:{Color.RESET} ").strip()

            if choice == "2":
                print(f"\n{Color.SKY}🌐 Đang mở trang web lấy key trên trình duyệt...{Color.RESET}")
                webbrowser.open(GET_KEY_URL)
                time.sleep(2)
                continue

            elif choice == "0":
                print(f"\n{Color.YELLOW}👋 Tạm biệt!{Color.RESET}\n")
                return False

            elif choice == "1" or choice == "":
                clip_text = pyperclip.paste().strip() if HAS_CLIPBOARD else ""
                if clip_text and (clip_text.startswith("TLGB-") or clip_text.startswith("VIP-") or clip_text.startswith("MINH-")):
                    print(f"\n{Color.LIME}📋 Phát hiện key trong Bộ nhớ tạm (Clipboard):{Color.RESET} {Color.WHITE}{clip_text}{Color.RESET}")
                    use_clip = input(f"   👉 Nhấn {Color.BOLD}[Enter]{Color.RESET} để dùng key này, hoặc nhập key khác: ").strip()
                    user_key = clip_text if use_clip == "" else use_clip
                else:
                    user_key = input(f"\n  🔑 {Color.BOLD}{Color.YELLOW}Nhập Key bản quyền vào đây:{Color.RESET} ").strip()

                if not user_key:
                    print(f"{Color.RED}❌ Bạn chưa nhập Key!{Color.RESET}")
                    time.sleep(1.5)
                    continue

                print(f"\n{Color.SKY}⏳ Đang kiểm tra tính hợp lệ của Key trên máy chủ...{Color.RESET}", end="", flush=True)
                is_valid, msg = cls.verify_key(user_key)

                if is_valid:
                    print(f"\r{Color.GREEN}✅ XÁC THỰC THÀNH CÔNG!{Color.RESET}                                 ")
                    print(f"   📋 Trạng thái: {Color.BOLD}{msg}{Color.RESET}\n")
                    cls.save_cached_key(user_key)
                    time.sleep(2)
                    return True
                else:
                    print(f"\r{Color.RED}❌ XÁC THỰC THẤT BẠI!{Color.RESET}                                   ")
                    print(f"   ⚠️  Chi tiết: {Color.WHITE}{msg}{Color.RESET}")
                    print(f"   🔗 Bạn có thể lấy key mới tại: {Color.SKY}{GET_KEY_URL}{Color.RESET}\n")
                    input(f"   👉 Nhấn [Enter] để thử lại...")


# ==================== THIẾT BỊ & CHỮ KÝ API (CHẾ ĐỘ CŨ) ====================
@dataclass
class DeviceInfo:
    model: str
    version: str
    api_level: int

class DeviceGenerator:
    DEVICES = [
        DeviceInfo("Pixel 5", "11", 30), DeviceInfo("Pixel 6", "12", 31),
        DeviceInfo("Pixel 7", "13", 33), DeviceInfo("Pixel 8", "14", 34),
        DeviceInfo("Samsung Galaxy S21", "12", 31), DeviceInfo("Samsung Galaxy S22", "13", 33),
        DeviceInfo("Samsung Galaxy S23", "14", 34), DeviceInfo("Samsung Galaxy S24 Ultra", "14", 34),
        DeviceInfo("Xiaomi 12", "13", 33), DeviceInfo("Xiaomi 13", "14", 34),
        DeviceInfo("Redmi Note 12", "13", 33), DeviceInfo("Oppo Reno 10", "14", 34),
        DeviceInfo("Vivo V27", "14", 34), DeviceInfo("Realme GT 5", "14", 34),
        DeviceInfo("OnePlus 11", "14", 34), DeviceInfo("Asus ROG Phone 7", "13", 33),
    ]

    @classmethod
    def random_device(cls) -> DeviceInfo:
        return random.choice(cls.DEVICES)

class Signature:
    KEY = [0xDF, 0x77, 0xB9, 0x40, 0xB9, 0x9B, 0x84, 0x83, 0xD1, 0xB9,
           0xCB, 0xD1, 0xF7, 0xC2, 0xB9, 0x85, 0xC3, 0xD0, 0xFB, 0xC3]

    def __init__(self, params: str, data: str, cookies: str):
        self.params = params
        self.data = data
        self.cookies = cookies

    def _md5_hash(self, data: str) -> str:
        return hashlib.md5(data.encode()).hexdigest()

    def _reverse_byte(self, n: int) -> int:
        return int(f"{n:02x}"[1:] + f"{n:02x}"[0], 16)

    def generate(self) -> Dict[str, str]:
        g = self._md5_hash(self.params)
        g += self._md5_hash(self.data) if self.data else "0" * 32
        g += self._md5_hash(self.cookies) if self.cookies else "0" * 32
        g += "0" * 32

        unix_timestamp = int(time.time())
        payload = []

        for i in range(0, 12, 4):
            chunk = g[8 * i:8 * (i + 1)]
            for j in range(4):
                payload.append(int(chunk[j * 2:(j + 1) * 2], 16))

        payload.extend([0x0, 0x6, 0xB, 0x1C])
        payload.extend([
            (unix_timestamp & 0xFF000000) >> 24,
            (unix_timestamp & 0x00FF0000) >> 16,
            (unix_timestamp & 0x0000FF00) >> 8,
            (unix_timestamp & 0x000000FF)
        ])

        encrypted = [a ^ b for a, b in zip(payload, self.KEY)]

        for i in range(0x14):
            C = self._reverse_byte(encrypted[i])
            D = encrypted[(i + 1) % 0x14]
            F = int(bin(C ^ D)[2:].zfill(8)[::-1], 2)
            H = ((F ^ 0xFFFFFFFF) ^ 0x14) & 0xFF
            encrypted[i] = H

        signature = "".join(f"{x:02x}" for x in encrypted)

        return {
            "X-Gorgon": "840280416000" + signature,
            "X-Khronos": str(unix_timestamp)
        }


# ==================== TRỢ LÝ TIKTOK ====================
class TikTokHelper:
    @staticmethod
    def extract_full_url(input_str: str) -> Tuple[Optional[str], Optional[str]]:
        input_str = input_str.strip()
        if not input_str:
            return None, None

        if re.fullmatch(r'\d{17,21}', input_str):
            full_url = f"https://www.tiktok.com/@tiktok/video/{input_str}"
            return full_url, input_str

        match_id = re.search(r'/video/(\d{17,21})', input_str)
        if match_id:
            vid_id = match_id.group(1)
            clean_url = input_str.split('?')[0]
            return clean_url, vid_id

        if not input_str.startswith(('http://', 'https://')):
            input_str = 'https://' + input_str

        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
            res = requests.get(input_str, headers=headers, timeout=12, allow_redirects=True)
            final_url = res.url
            match_final = re.search(r'/video/(\d{17,21})', final_url)
            if match_final:
                return final_url.split('?')[0], match_final.group(1)
            
            m = re.search(r'"video":\{"id":"(\d{17,21})"', res.text)
            if m:
                vid_id = m.group(1)
                return f"https://www.tiktok.com/@tiktok/video/{vid_id}", vid_id

            return input_str, None
        except Exception:
            return input_str, None


# ==================== CHẾ ĐỘ 1: ĐA LUỒNG SIÊU TỐC (CÁCH CŨ) ====================
class FastDirectBot:
    def __init__(self, video_id: str, target_views: int = 0, workers: int = 3000):
        self.video_id = video_id
        self.target_views = target_views
        self.workers = workers
        self.count = 0
        self.successful_requests = 0
        self.failed_requests = 0
        self.start_time = 0
        self.peak_speed = 0.0
        self.is_running = False
        self.session: Optional[aiohttp.ClientSession] = None

    async def init_session(self):
        timeout = aiohttp.ClientTimeout(total=25, connect=8)
        connector = aiohttp.TCPConnector(
            limit=0, limit_per_host=0, keepalive_timeout=30,
            enable_cleanup_closed=True, ttl_dns_cache=300
        )
        self.session = aiohttp.ClientSession(
            timeout=timeout, connector=connector,
            headers={'User-Agent': 'com.ss.android.ugc.trill/400304'},
            cookie_jar=aiohttp.DummyCookieJar()
        )

    async def close_session(self):
        if self.session and not self.session.closed:
            await self.session.close()

    def generate_request_data(self) -> Tuple[str, Dict, Dict, Dict]:
        device = DeviceGenerator.random_device()
        device_id = random.randint(600000000000000, 699999999999999)
        params = (
            f"channel=googleplay&aid=1233&app_name=musical_ly&version_code=400304"
            f"&device_platform=android&device_type={device.model.replace(' ', '+')}"
            f"&os_version={device.version}&device_id={device_id}"
            f"&os_api={device.api_level}&app_language=vi&tz_name=Asia%2FHo_Chi_Minh"
        )
        url = f"https://api16-core-c-alisg.tiktokv.com/aweme/v1/aweme/stats/?{params}"
        data = {"item_id": self.video_id, "play_delta": 1, "action_time": int(time.time())}
        cookies = {"sessionid": secrets.token_hex(16)}
        headers = {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "User-Agent": "com.ss.android.ugc.trill/400304",
            "Accept-Encoding": "gzip",
            "Connection": "keep-alive"
        }
        return url, data, cookies, headers

    async def send_view_request(self, semaphore: asyncio.Semaphore) -> bool:
        async with semaphore:
            for attempt in range(2):
                try:
                    url, data, cookies, base_headers = self.generate_request_data()
                    sig = Signature(url.split('?')[1], str(data), str(cookies)).generate()
                    headers = {**base_headers, **sig}

                    async with self.session.post(url, data=data, headers=headers, cookies=cookies, ssl=False) as response:
                        if response.status == 200:
                            self.count += 1
                            self.successful_requests += 1
                            return True
                        else:
                            if attempt == 0:
                                await asyncio.sleep(0.01)
                                continue
                            self.failed_requests += 1
                            return False
                except Exception:
                    if attempt == 0:
                        await asyncio.sleep(0.01)
                        continue
                    self.failed_requests += 1
                    return False
        return False

    async def worker_loop(self, semaphore: asyncio.Semaphore):
        base_delay = 0.001
        consecutive_success = 0

        while self.is_running:
            if self.target_views > 0 and self.count >= self.target_views:
                self.is_running = False
                break

            success = await self.send_view_request(semaphore)
            if success:
                consecutive_success += 1
                delay = base_delay * 0.5 if consecutive_success > 100 else base_delay
            else:
                consecutive_success = 0
                delay = base_delay * 2

            stats = self.get_stats()
            if stats["views_per_second"] > 600:
                delay *= 1.4
            elif stats["views_per_second"] > 1000:
                delay *= 2

            await asyncio.sleep(delay + random.uniform(0, 0.002))

    def get_stats(self) -> Dict:
        elapsed = time.time() - self.start_time if self.start_time > 0 else 0.001
        views_per_second = self.count / elapsed if elapsed > 0 else 0.0
        if views_per_second > self.peak_speed:
            self.peak_speed = views_per_second

        views_per_minute = views_per_second * 60
        total_reqs = self.successful_requests + self.failed_requests
        success_rate = (self.successful_requests / total_reqs * 100) if total_reqs > 0 else 100.0

        return {
            "total_views": self.count,
            "target_views": self.target_views,
            "elapsed_time": elapsed,
            "views_per_second": views_per_second,
            "views_per_minute": views_per_minute,
            "success_rate": success_rate,
            "successful_requests": self.successful_requests,
            "failed_requests": self.failed_requests,
            "peak_speed": self.peak_speed
        }

    async def run(self):
        await self.init_session()
        self.is_running = True
        self.start_time = time.time()
        
        max_concurrent = min(1000, max(100, self.workers // 3))
        semaphore = asyncio.Semaphore(max_concurrent)
        
        tasks = []
        for _ in range(self.workers):
            t = asyncio.create_task(self.worker_loop(semaphore))
            tasks.append(t)

        try:
            while self.is_running:
                await asyncio.sleep(0.35)
                stats = self.get_stats()
                
                s = int(stats["elapsed_time"])
                m, s = divmod(s, 60)
                h, m = divmod(m, 60)
                time_str = f"{h:02d}:{m:02d}:{s:02d}"
                
                target_str = f"/{stats['target_views']:,}" if self.target_views > 0 else " (∞)"
                
                if self.target_views > 0:
                    pct = min(1.0, stats["total_views"] / self.target_views)
                    f_len = int(15 * pct)
                    bar_str = "█" * f_len + "░" * (15 - f_len)
                    pbar = f"[{rainbow_text(bar_str, 1.0, 0.0)}] {pct*100:.1f}%"
                else:
                    spinners = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
                    idx = int(time.time() * 5) % len(spinners)
                    pbar = f"{Color.CYAN}[ {spinners[idx]} Chạy liên tục ]{Color.RESET}"

                status_line = (
                    f"\r{Color.BOLD}{Color.GOLD}⚡ Views:{Color.RESET} {Color.WHITE}{stats['total_views']:,}{target_str}{Color.RESET} {pbar} | "
                    f"{Color.CYAN}Tốc độ:{Color.RESET} {stats['views_per_second']:.1f} v/s | "
                    f"{Color.GREEN}OK:{Color.RESET} {stats['successful_requests']:,} | "
                    f"{Color.RED}Lỗi:{Color.RESET} {stats['failed_requests']:,} | "
                    f"{Color.MAGENTA}Thời gian:{Color.RESET} {time_str}"
                )
                print(status_line, end="", flush=True)

                if self.target_views > 0 and self.count >= self.target_views:
                    break

        except (asyncio.CancelledError, KeyboardInterrupt):
            pass
        finally:
            self.is_running = False
            for t in tasks:
                t.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            await self.close_session()


# ==================== CHẾ ĐỘ 2: ZEFOY REAL ENGINE ====================
class ZefoyAutomationBot:
    def __init__(self, video_url: str, video_id: str, target_views: int = 0):
        self.video_url = video_url
        self.video_id = video_id
        self.target_views = target_views
        self.total_views_sent = 0
        self.total_rounds = 0
        self.start_time = 0
        self.driver: Optional[webdriver.Chrome] = None

    def init_driver(self):
        print(f"\n{Color.SKY}🌐 Đang khởi tạo trình duyệt Chrome tự động...{Color.RESET}")
        opts = Options()
        opts.add_argument("--disable-notifications")
        opts.add_argument("--disable-popup-blocking")
        opts.add_argument("--disable-infobars")
        opts.add_argument("--start-maximized")
        opts.add_argument("--log-level=3")
        opts.add_experimental_option('excludeSwitches', ['enable-logging', 'enable-automation'])
        opts.add_experimental_option('useAutomationExtension', False)
        opts.add_experimental_option("prefs", {
            "profile.default_content_setting_values.notifications": 2,
            "credentials_enable_service": False,
            "profile.password_manager_enabled": False
        })

        self.driver = webdriver.Chrome(options=opts)
        self.driver.get("https://zefoy.com")

    def wait_for_captcha(self):
        box = """
╔══════════════════════════════════════════════════════════════╗
║  👉 BƯỚC QUAN TRỌNG: GIẢI CAPTCHA TRÊN CỬA SỔ CHROME VỪA MỞ  ║
╚══════════════════════════════════════════════════════════════╝
"""
        print(rainbow_text(box, horizontal_speed=0.9, vertical_speed=0.1))
        print(f"{Color.WHITE}   • Hãy nhìn vào cửa sổ trình duyệt Chrome vừa xuất hiện.{Color.RESET}")
        print(f"{Color.WHITE}   • Nhập chữ trong ảnh Captcha và bấm dấu tích {Color.GREEN}✓{Color.RESET}{Color.WHITE} để xác nhận.{Color.RESET}")
        print(f"{Color.CYAN}   ⏳ TLGB TOOL đang tự động đợi bạn nhập xong...{Color.RESET}\n")

        while True:
            try:
                page_source = self.driver.page_source.lower()
                if "views" in page_source and "followers" in page_source:
                    print(f"{Color.GREEN}✅ Giải Captcha THÀNH CÔNG! TLGB TOOL bắt đầu chạy tự động...{Color.RESET}\n")
                    time.sleep(2)
                    break
                time.sleep(1)
            except Exception:
                time.sleep(1)

    def select_views_service(self) -> bool:
        try:
            buttons = self.driver.find_elements(By.TAG_NAME, "button")
            for b in buttons:
                txt = b.text.strip().lower()
                if "views" in txt or "view" in txt:
                    if b.is_enabled():
                        b.click()
                        time.sleep(2)
                        return True
                    else:
                        print(f"{Color.YELLOW}⚠️ Dịch vụ Views hiện đang bảo trì tạm thời trên Zefoy. Đang thử lại...{Color.RESET}")
                        return False
            
            card_btns = self.driver.find_elements(By.XPATH, "//div[contains(@class, 'card-body')]//button")
            for b in card_btns:
                if "views" in b.text.lower():
                    b.click()
                    time.sleep(2)
                    return True

            return False
        except Exception:
            return False

    def parse_timer_seconds(self, text: str) -> int:
        seconds = 0
        min_match = re.search(r'(\d+)\s*minute', text, re.IGNORECASE)
        sec_match = re.search(r'(\d+)\s*second', text, re.IGNORECASE)
        
        if min_match:
            seconds += int(min_match.group(1)) * 60
        if sec_match:
            seconds += int(sec_match.group(1))

        if seconds == 0:
            digit_match = re.findall(r'\d+', text)
            if len(digit_match) == 2:
                seconds = int(digit_match[0]) * 60 + int(digit_match[1])
            elif len(digit_match) == 1:
                seconds = int(digit_match[0])
                
        return max(5, seconds)

    def run_countdown(self, seconds: int):
        while seconds > 0:
            m, s = divmod(seconds, 60)
            time_str = f"{m:02d}:{s:02d}"
            
            pbar_len = 16
            pct = 1.0 - (seconds / 150.0)
            pct = max(0.0, min(1.0, pct))
            filled = int(pbar_len * pct)
            bar = "█" * filled + "░" * (pbar_len - filled)
            
            rainbow_bar = rainbow_text(bar, horizontal_speed=1.2, vertical_speed=0.0)
            
            status = (
                f"\r{Color.CYAN}⏳ TLGB Đang chờ đợt kế: {Color.BOLD}{Color.GOLD}{time_str}{Color.RESET} "
                f"[{rainbow_bar}] | "
                f"{Color.GREEN}Đã tăng: +{self.total_views_sent:,} views{Color.RESET} "
                f"(Đợt {self.total_rounds})"
            )
            print(status, end="", flush=True)
            time.sleep(1)
            seconds -= 1
        print("\r" + " " * 95 + "\r", end="", flush=True)

    def send_views_cycle(self) -> bool:
        try:
            input_box = None
            inputs = self.driver.find_elements(By.XPATH, "//input[@type='search' or @type='text']")
            for inp in inputs:
                placeholder = inp.get_attribute("placeholder") or ""
                if "url" in placeholder.lower() or "video" in placeholder.lower() or "link" in placeholder.lower() or placeholder == "":
                    if inp.is_displayed():
                        input_box = inp
                        break
            
            if not input_box:
                for inp in inputs:
                    if inp.is_displayed():
                        input_box = inp
                        break

            if input_box:
                input_box.clear()
                input_box.send_keys(self.video_url)
                time.sleep(0.5)

            search_btn = None
            buttons = self.driver.find_elements(By.TAG_NAME, "button")
            for b in buttons:
                if "search" in b.text.lower() and b.is_displayed():
                    search_btn = b
                    break
            
            if search_btn:
                search_btn.click()
                time.sleep(3)

            page_text = self.driver.page_source
            
            if "please wait" in page_text.lower() or "seconds for your next submit" in page_text.lower() or "an empty search" in page_text.lower():
                wait_sec = self.parse_timer_seconds(page_text)
                self.run_countdown(wait_sec)
                return True

            submit_btn = None
            after_search_btns = self.driver.find_elements(By.XPATH, "//form//button | //div[contains(@class, 'card')]//button")
            for b in after_search_btns:
                b_text = b.text.strip()
                if b.is_displayed() and ("search" not in b_text.lower()):
                    submit_btn = b
                    break

            if submit_btn:
                submit_btn.click()
                self.total_rounds += 1
                self.total_views_sent += 500
                
                success_msg = f"🎉 [TLGB TOOL - ĐỢT {self.total_rounds}] ĐÃ GỬI THÀNH CÔNG +500 ~ 1,000 VIEWS VÀO VIDEO!"
                print("\n" + rainbow_text(success_msg, horizontal_speed=0.9, vertical_speed=0.0))
                print(f"   📈 {Color.WHITE}Tổng view đã tăng dự kiến:{Color.RESET} {Color.GOLD}+{self.total_views_sent:,} views{Color.RESET}\n")
                
                time.sleep(3)
                
                new_page = self.driver.page_source
                wait_sec = self.parse_timer_seconds(new_page)
                self.run_countdown(wait_sec)
                return True
            else:
                time.sleep(2)
                return True

        except Exception:
            time.sleep(3)
            return True

    def start(self):
        self.start_time = time.time()
        self.init_driver()
        self.wait_for_captcha()
        
        print(f"{Color.SKY}👉 TLGB TOOL đang chọn dịch vụ Tăng Views...{Color.RESET}")
        self.select_views_service()

        start_header = "🚀 BẮT ĐẦU CHẾ ĐỘ AUTO BUFF VIEW LIÊN TỤC (ZEFOY REAL)!"
        print("\n" + rainbow_text(start_header, horizontal_speed=0.8, vertical_speed=0.0))
        print(f"{Color.GRAY}   (Tool sẽ tự động tìm kiếm, gửi view và đếm ngược lặp lại hoàn toàn tự động){Color.RESET}")
        print(f"{Color.YELLOW}   [Nhấn Ctrl + C để dừng bất cứ lúc nào]{Color.RESET}\n")

        try:
            while True:
                if self.target_views > 0 and self.total_views_sent >= self.target_views:
                    print(f"\n{Color.BOLD}{Color.GREEN}🎯 ĐÃ ĐẠT ĐỦ MỤC TIÊU {self.target_views:,} VIEWS!{Color.RESET}")
                    break
                
                self.send_views_cycle()
                
        except KeyboardInterrupt:
            print(f"\n\n{Color.YELLOW}⚠️ Đã nhận lệnh dừng từ người dùng.{Color.RESET}")
        finally:
            if self.driver:
                self.driver.quit()


# ==================== GIAO DIỆN CHÍNH & ĐIỀU HƯỚNG ====================
def prompt_user_input() -> Tuple[str, str, int, str]:
    print_banner()

    print(f"{Color.BOLD}{Color.YELLOW}📌 BƯỚC 1: CHỌN CHẾ ĐỘ CHẠY TĂNG VIEW{Color.RESET}")
    print(f"  {Color.GREEN}[1]{Color.RESET} {Color.BOLD}⚡ Chế độ Siêu Tốc (Cách cũ - Đa luồng API, không cần mở Chrome){Color.RESET}")
    print(f"  {Color.CYAN}[2]{Color.RESET} {Color.BOLD}🌐 Chế độ Zefoy Real (Cách mới - Tự động hóa qua trình duyệt){Color.RESET}")
    
    engine_choice = input(f"  👉 {Color.BOLD}Lựa chọn chế độ [1/2] (Mặc định: 1):{Color.RESET} ").strip()
    if engine_choice not in ["1", "2"]:
        engine_choice = "1"

    print(f"\n{Color.BOLD}{Color.YELLOW}📌 BƯỚC 2: NHẬP LINK VIDEO TIKTOK CẦN TĂNG VIEW{Color.RESET}")
    clip_url = None
    if HAS_CLIPBOARD:
        try:
            t = pyperclip.paste().strip()
            if t and ('tiktok.com' in t or re.fullmatch(r'\d{17,21}', t)):
                clip_url = t
        except Exception:
            pass

    if clip_url:
        print(f"\n{Color.LIME}📋 Phát hiện link trong Clipboard:{Color.RESET} {Color.WHITE}{clip_url}{Color.RESET}")
        choice = input(f"   👉 Nhấn {Color.BOLD}[Enter]{Color.RESET} để dùng link này, hoặc dán link mới: ").strip()
        raw_input = clip_url if choice == "" else choice
    else:
        raw_input = input(f"\n{Color.CYAN}🔗 Dán link TikTok vào đây:{Color.RESET} ").strip()

    if not raw_input:
        print(f"{Color.RED}❌ Lỗi: Bạn chưa nhập link!{Color.RESET}")
        return "", "", 0, engine_choice

    print(f"\n{Color.SKY}🔍 TLGB TOOL đang phân tích link...{Color.RESET}", end="", flush=True)
    full_url, video_id = TikTokHelper.extract_full_url(raw_input)

    if not full_url:
        print(f"\r{Color.RED}❌ Link không hợp lệ! Vui lòng kiểm tra lại.{Color.RESET}")
        return "", "", 0, engine_choice

    print(f"\r{Color.GREEN}✅ Link video chuẩn:{Color.RESET} {Color.WHITE}{full_url}{Color.RESET}")

    print(f"\n{Color.BOLD}{Color.YELLOW}📌 BƯỚC 3: THIẾT LẬP MỤC TIÊU VIEW{Color.RESET}")
    print(f"{Color.GRAY}   - Nhập số lượng view muốn tăng (VD: 2000, 5000, 10000...){Color.RESET}")
    print(f"{Color.GRAY}   - Nhấn [Enter] hoặc nhập 0 để chạy KHÔNG GIỚI HẠN (Tự động lặp lại liên tục){Color.RESET}")
    target_input = input(f"   🎯 {Color.BOLD}Mục tiêu số View (Mặc định: Vô hạn):{Color.RESET} ").strip()
    
    target_views = 0
    if target_input.isdigit():
        target_views = int(target_input)

    return full_url, video_id or "Unknown", target_views, engine_choice


def main():
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

    # 1. Bắt buộc kiểm tra bản quyền Key
    if not KeyManager.require_license():
        return

    # 2. Vòng lặp chạy tăng view
    while True:
        full_url, video_id, target_views, engine_choice = prompt_user_input()
        if not full_url:
            retry = input(f"\n👉 Bạn có muốn thử lại không? (y/n): ").strip().lower()
            if retry == 'n':
                break
            continue

        if engine_choice == "1":
            # Chế độ Siêu Tốc (Cách cũ - Đa luồng)
            cpu_cores = os.cpu_count() or 4
            workers = 3500 if cpu_cores <= 4 else 6000
            
            print(f"\n{Color.PINK}┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓{Color.RESET}")
            print(f"{Color.PINK}┃{Color.RESET} {Color.BOLD}ĐÃ SẴN SÀNG KHỞI CHẠY CHẾ ĐỘ SIÊU TỐC (ĐA LUỒNG)!{Color.RESET}")
            print(f"{Color.PINK}┃{Color.RESET} • Video ID  : {Color.WHITE}{video_id}{Color.RESET}")
            print(f"{Color.PINK}┃{Color.RESET} • Số luồng  : {Color.CYAN}{workers:,} workers{Color.RESET}")
            print(f"{Color.PINK}┃{Color.RESET} • Dừng tool : {Color.YELLOW}Bấm phím Ctrl + C bất cứ lúc nào{Color.RESET}")
            print(f"{Color.PINK}┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛{Color.RESET}\n")
            
            bot = FastDirectBot(video_id=video_id, target_views=target_views, workers=workers)
            try:
                asyncio.run(bot.run())
            except KeyboardInterrupt:
                pass
            
            stats = bot.get_stats()
            summary_header = "═" * 70 + "\n 🎉 TỔNG KẾT PHIÊN TĂNG VIEW - TLGB TOOL (CHẾ ĐỘ SIÊU TỐC)\n" + "═" * 70
            print("\n\n" + rainbow_text(summary_header, horizontal_speed=0.9, vertical_speed=0.1))
            print(f" 👑 Bản quyền   : {Color.CYAN}TRẦN LÊ GIA BẢO{Color.RESET}")
            print(f" 🎯 Video ID    : {video_id}")
            print(f" 🚀 Tổng View   : {Color.GREEN}{stats['total_views']:,}{Color.RESET} views")
            print(f" ⚡ Tốc độ đỉnh : {Color.GOLD}{stats['peak_speed']:.1f}{Color.RESET} view/s")
            print(f" ⏱️  Thời gian   : {int(stats['elapsed_time'])}s")
            print(rainbow_text("═" * 70, horizontal_speed=1.0, vertical_speed=0.0))

        else:
            # Chế độ Zefoy Real
            bot = ZefoyAutomationBot(video_url=full_url, video_id=video_id, target_views=target_views)
            bot.start()

            summary_header = "═" * 70 + "\n 🎉 TỔNG KẾT PHIÊN TĂNG VIEW - TLGB TOOL (CHẾ ĐỘ ZEFOY)\n" + "═" * 70
            print("\n" + rainbow_text(summary_header, horizontal_speed=0.9, vertical_speed=0.1))
            print(f" 👑 Bản quyền   : {Color.CYAN}TRẦN LÊ GIA BẢO{Color.RESET}")
            print(f" 🎯 Video       : {full_url}")
            print(f" 🚀 View đã tăng: {Color.GREEN}+{bot.total_views_sent:,} views{Color.RESET}")
            print(f" 🔄 Số đợt chạy : {bot.total_rounds} đợt")
            print(rainbow_text("═" * 70, horizontal_speed=1.0, vertical_speed=0.0))

        next_vid = input(f"\n👉 Bạn có muốn tăng view cho video khác không? (y/n): ").strip().lower()
        if next_vid == 'n':
            bye_msg = "✨ Cảm ơn bạn đã sử dụng TLGB TOOL! Hẹn gặp lại! 👋"
            print("\n" + rainbow_text(bye_msg, horizontal_speed=0.8, vertical_speed=0.0) + "\n")
            break


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Color.YELLOW}👋 Đã đóng TLGB TOOL. Tạm biệt!{Color.RESET}\n")
    except Exception as e:
        print(f"\n{Color.RED}💥 Lỗi: {e}{Color.RESET}\n")
