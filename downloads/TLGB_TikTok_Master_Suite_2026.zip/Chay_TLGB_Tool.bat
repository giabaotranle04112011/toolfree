@echo off
chcp 65001 >nul
title TLGB TOOL - CONSOLE CONTROL TITAN v6.5.0

where py >nul 2>nul
if %errorlevel% equ 0 (
    set PYTHON_CMD=py -3.12
) else (
    set PYTHON_CMD=python
)

if exist "%USERPROFILE%\Downloads\spam.py" (
    %PYTHON_CMD% "%USERPROFILE%\Downloads\spam.py"
) else (
    %PYTHON_CMD% "spam.py"
)

pause
