@echo off
chcp 65001 >nul
title ALL-IN-ONE VIRUS & MALWARE SURGICAL CLEANER GUI 2026 - TRAN LE GIA BAO
echo ======================================================================
echo    [+] DANG KHOI DONG VIRUS CLEANER GUI (TRAN LE GIA BAO - BUN K11)
echo ======================================================================
echo Dang kiem tra Python...

where py >nul 2>nul
if %errorlevel% equ 0 (
    py -3.12 "%~dp0virus_cleaner_gui.py"
    if %errorlevel% neq 0 py "%~dp0virus_cleaner_gui.py"
    goto end
)

where python >nul 2>nul
if %errorlevel% equ 0 (
    python "%~dp0virus_cleaner_gui.py"
    goto end
)

echo [LOI] Khong tim thay Python! Vui long cai dat Python tai python.org
pause

:end
